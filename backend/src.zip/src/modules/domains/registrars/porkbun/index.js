const axios = require("axios");
const https = require("https");
const { getRawCategory } = require("../../services/domain-settings.service");

/**
 * Porkbun API v3 base
 */
const BASE_URL = "https://api.porkbun.com/api/json/v3";

/**
 * Force IPv4 (recommended by Porkbun)
 */
const httpsAgent = new https.Agent({
  keepAlive: true,
  family: 4
});

/**
 * Load Porkbun credentials — DB first, then env var fallback
 */
async function getCredentials() {
  const db = await getRawCategory("porkbun");
  const apiKey   = db.porkbun_api_key   || process.env.PORKBUN_API_KEY;
  const secretKey = db.porkbun_secret_key || process.env.PORKBUN_SECRET_KEY;

  if (!apiKey || !secretKey) {
    throw new Error(
      "Porkbun credentials not configured. " +
      "Add them in Admin → Settings → Domains or set PORKBUN_API_KEY / PORKBUN_SECRET_KEY."
    );
  }

  return { apikey: apiKey, secretapikey: secretKey };
}

/**
 * Unified POST helper
 */
async function porkbunPost(endpoint, payload = {}) {
  const creds = await getCredentials();

  try {
    const response = await axios.post(
      `${BASE_URL}${endpoint}`,
      {
        ...creds,
        ...payload
      },
      {
        httpsAgent,
        timeout: 15000,
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "User-Agent": "WHMS-DomainService/1.0"
        }
      }
    );

    if (response.data?.status !== "SUCCESS") {
      throw new Error(response.data?.message || "Porkbun API failure");
    }

    return response.data;

  } catch (err) {
    if (err.response) {
      throw new Error(
        `Porkbun API error (${err.response.status}): ${
          typeof err.response.data === "string"
            ? err.response.data
            : JSON.stringify(err.response.data)
        }`
      );
    }

    throw new Error(`Porkbun network error: ${err.code || err.message}`);
  }
}

/**
 * Registrar Interface (WHMS-compatible)
 */
module.exports = {

  /**
   * Check domain availability
   * Endpoint: /domain/checkDomain/{domain}
   */
  async checkAvailability(domain) {
    try {
      const data = await porkbunPost(`/domain/checkDomain/${domain}`);

      const result = data.response;
      if (!result) {
        throw new Error("Invalid availability response from Porkbun");
      }

      return {
        domain,
        available: result.avail === "yes",
        premium: result.premium === "yes",
        price: result.price ? parseFloat(result.price) : null,
        regularPrice: result.regularPrice ? parseFloat(result.regularPrice) : null
      };
    } catch (err) {
      throw new Error(`Availability check failed: ${err.message}`);
    }
  },

  /**
   * Register a domain
   * NOTE: Porkbun API v3 does NOT expose domain registration via API.
   * Domain registration must be done through the web interface.
   */
  async registerDomain({ domain, years, nameservers = [] }) {
    throw new Error(
      "Domain registration is not available via Porkbun API. " +
      "Please register domains through the Porkbun web interface at https://porkbun.com"
    );
  },

  /**
   * Renew a domain
   * NOTE: Porkbun API v3 does NOT expose domain renewal via API.
   * Domain renewal must be done through the web interface.
   */
  async renewDomain({ domain, years }) {
    throw new Error(
      "Domain renewal is not available via Porkbun API. " +
      "Please renew domains through the Porkbun web interface at https://porkbun.com/account"
    );
  },

  /**
   * Transfer a domain
   * NOTE: Porkbun API v3 does NOT expose domain transfer via API.
   * Domain transfers must be initiated through the web interface.
   */
  async transferDomain({ domain, authCode }) {
    throw new Error(
      "Domain transfer is not available via Porkbun API. " +
      "Please initiate transfers through the Porkbun web interface at https://porkbun.com/transfer"
    );
  },

  /**
   * Update nameservers for a domain
   * Endpoint: /domain/updateNs/{domain}
   */
  async updateNameservers({ domain, nameservers }) {
    try {
      await porkbunPost(`/domain/updateNs/${domain}`, {
        ns: nameservers
      });

      return { success: true };
    } catch (err) {
      throw new Error(`Nameserver update failed: ${err.message}`);
    }
  },

  /**
   * Get nameservers for a domain
   * Endpoint: /domain/getNs/{domain}
   */
  async getNameservers(domain) {
    try {
      const data = await porkbunPost(`/domain/getNs/${domain}`);

      return {
        success: true,
        nameservers: data.ns || []
      };
    } catch (err) {
      throw new Error(`Get nameservers failed: ${err.message}`);
    }
  },

  /**
   * DNS sync placeholder
   * (Actual DNS CRUD handled by dns.service)
   */
  async updateDNSRecords() {
    return { success: true, synced: true };
  },

  /**
   * Sync domain status from registrar
   * Uses domain list API to get domain info
   * Endpoint: /domain/listAll
   */
  async syncDomain(domain) {
    try {
      const data = await porkbunPost("/domain/listAll");

      const domainInfo = data.domains?.find(d => d.domain === domain);
      
      if (!domainInfo) {
        throw new Error(`Domain ${domain} not found in account`);
      }

      return {
        status: domainInfo.status === "ACTIVE" ? "active" : "expired",
        expiryDate: new Date(domainInfo.expireDate),
        autoRenew: Boolean(domainInfo.autoRenew),
        locked: Boolean(domainInfo.securityLock),
        whoisPrivacy: Boolean(domainInfo.whoisPrivacy)
      };
    } catch (err) {
      throw new Error(`Domain sync failed: ${err.message}`);
    }
  },

  /**
   * Get all domains in account
   * Endpoint: /domain/listAll
   */
  async listDomains() {
    try {
      const domains = [];
      let start = 0;
      let hasMore = true;

      while (hasMore) {
        const data = await porkbunPost("/domain/listAll", { start });

        if (data.domains && data.domains.length > 0) {
          domains.push(...data.domains);
          start += 1000;

          // If we got less than 1000, we've reached the end
          if (data.domains.length < 1000) {
            hasMore = false;
          }
        } else {
          hasMore = false;
        }
      }

      return {
        success: true,
        domains: domains.map(d => ({
          domain: d.domain,
          status: d.status === "ACTIVE" ? "active" : "expired",
          expiryDate: new Date(d.expireDate),
          createDate: new Date(d.createDate),
          autoRenew: Boolean(d.autoRenew),
          locked: Boolean(d.securityLock),
          whoisPrivacy: Boolean(d.whoisPrivacy)
        }))
      };
    } catch (err) {
      throw new Error(`List domains failed: ${err.message}`);
    }
  },

  /**
   * Check if Porkbun credentials are configured
   */
  async hasCredentials() {
    try {
      const db = await getRawCategory("porkbun");
      const apiKey = db.porkbun_api_key || process.env.PORKBUN_API_KEY;
      const secretKey = db.porkbun_secret_key || process.env.PORKBUN_SECRET_KEY;
      return !!(apiKey && secretKey);
    } catch {
      return false;
    }
  }
};