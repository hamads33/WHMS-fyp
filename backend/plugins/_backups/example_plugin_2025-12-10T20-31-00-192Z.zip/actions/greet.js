module.exports.run = async ({ meta }) => {
  return {
    ok: true,
    message: `Hello from greet action!`,
    receivedMeta: meta
  };
};
