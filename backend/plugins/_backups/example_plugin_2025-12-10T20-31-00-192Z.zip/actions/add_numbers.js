module.exports.run = async ({ meta }) => {
  const x = Number(meta?.x || 0);
  const y = Number(meta?.y || 0);

  return {
    ok: true,
    result: x + y,
    formula: `${x} + ${y} = ${x + y}`
  };
};
