async function callGreet() {
  const res = await window.pluginSDK.runAction("example_plugin", "greet", {});
  document.getElementById("output").innerText = JSON.stringify(res, null, 2);
}

async function callAdd() {
  const res = await window.pluginSDK.runAction("example_plugin", "add_numbers", { x: 10, y: 20 });
  document.getElementById("output").innerText = JSON.stringify(res, null, 2);
}
