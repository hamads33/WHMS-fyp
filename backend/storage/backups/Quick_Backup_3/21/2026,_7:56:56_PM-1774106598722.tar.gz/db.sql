--
-- PostgreSQL database dump
--

\restrict pxjDAclrgLxWBpv7fnwyGOHSoh2toa6JcKKHsZqu47LfyTqaPy6eUKS1JKmCaDs

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: whms_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO whms_user;

--
-- Name: DunningAction; Type: TYPE; Schema: public; Owner: whms_user
--

CREATE TYPE public."DunningAction" AS ENUM (
    'email_reminder',
    'charge_attempt',
    'suspend'
);


ALTER TYPE public."DunningAction" OWNER TO whms_user;

--
-- Name: DunningStatus; Type: TYPE; Schema: public; Owner: whms_user
--

CREATE TYPE public."DunningStatus" AS ENUM (
    'sent',
    'failed',
    'skipped'
);


ALTER TYPE public."DunningStatus" OWNER TO whms_user;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: whms_user
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'draft',
    'unpaid',
    'paid',
    'overdue',
    'cancelled',
    'refunded'
);


ALTER TYPE public."InvoiceStatus" OWNER TO whms_user;

--
-- Name: InvoiceType; Type: TYPE; Schema: public; Owner: whms_user
--

CREATE TYPE public."InvoiceType" AS ENUM (
    'new_order',
    'renewal',
    'suspension',
    'termination',
    'manual'
);


ALTER TYPE public."InvoiceType" OWNER TO whms_user;

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: whms_user
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'pending',
    'active',
    'suspended',
    'terminated',
    'cancelled'
);


ALTER TYPE public."OrderStatus" OWNER TO whms_user;

--
-- Name: PaymentMethodType; Type: TYPE; Schema: public; Owner: whms_user
--

CREATE TYPE public."PaymentMethodType" AS ENUM (
    'card',
    'paypal',
    'bank_transfer',
    'other'
);


ALTER TYPE public."PaymentMethodType" OWNER TO whms_user;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: whms_user
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'pending',
    'completed',
    'failed',
    'refunded'
);


ALTER TYPE public."PaymentStatus" OWNER TO whms_user;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: whms_user
--

CREATE TYPE public."TransactionType" AS ENUM (
    'payment',
    'refund',
    'adjustment',
    'credit'
);


ALTER TYPE public."TransactionType" OWNER TO whms_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AdminProfile; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."AdminProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    department text,
    "staffTitle" text,
    "restrictionJson" jsonb
);


ALTER TABLE public."AdminProfile" OWNER TO whms_user;

--
-- Name: ApiKey; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ApiKey" (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    "keyHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."ApiKey" OWNER TO whms_user;

--
-- Name: ApiKeyScope; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ApiKeyScope" (
    id text NOT NULL,
    "apiKeyId" text NOT NULL,
    scope text NOT NULL
);


ALTER TABLE public."ApiKeyScope" OWNER TO whms_user;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."AuditLog" (
    "userId" text,
    action text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    data jsonb,
    entity text,
    "entityId" text,
    ip text,
    "userAgent" text,
    actor text NOT NULL,
    level text DEFAULT 'INFO'::text NOT NULL,
    meta jsonb,
    source text NOT NULL,
    id integer NOT NULL,
    "profileId" integer
);


ALTER TABLE public."AuditLog" OWNER TO whms_user;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."AuditLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AuditLog_id_seq" OWNER TO whms_user;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."AuditLog_id_seq" OWNED BY public."AuditLog".id;


--
-- Name: AutomationProfile; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."AutomationProfile" (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    cron text NOT NULL,
    enabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public."AutomationProfile" OWNER TO whms_user;

--
-- Name: AutomationProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."AutomationProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationProfile_id_seq" OWNER TO whms_user;

--
-- Name: AutomationProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."AutomationProfile_id_seq" OWNED BY public."AutomationProfile".id;


--
-- Name: AutomationRun; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."AutomationRun" (
    id integer NOT NULL,
    "profileId" integer NOT NULL,
    "taskId" integer,
    status text DEFAULT 'pending'::text NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    result jsonb,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AutomationRun" OWNER TO whms_user;

--
-- Name: AutomationRun_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."AutomationRun_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationRun_id_seq" OWNER TO whms_user;

--
-- Name: AutomationRun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."AutomationRun_id_seq" OWNED BY public."AutomationRun".id;


--
-- Name: AutomationTask; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."AutomationTask" (
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "actionMeta" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "actionType" text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "profileId" integer NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public."AutomationTask" OWNER TO whms_user;

--
-- Name: AutomationTask_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."AutomationTask_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationTask_id_seq" OWNER TO whms_user;

--
-- Name: AutomationTask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."AutomationTask_id_seq" OWNED BY public."AutomationTask".id;


--
-- Name: AutomationWorkflow; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."AutomationWorkflow" (
    id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    definition jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "eventFilter" jsonb,
    "eventType" text,
    slug text NOT NULL,
    trigger text DEFAULT 'manual'::text NOT NULL,
    type text DEFAULT 'sequential'::text NOT NULL
);


ALTER TABLE public."AutomationWorkflow" OWNER TO whms_user;

--
-- Name: Backup; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Backup" (
    id integer NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'full'::text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    "filePath" text,
    "sizeBytes" bigint,
    "errorMessage" text,
    "retentionDays" integer DEFAULT 30 NOT NULL,
    "storageConfigId" integer,
    "createdById" text NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Backup" OWNER TO whms_user;

--
-- Name: BackupStepLog; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."BackupStepLog" (
    id integer NOT NULL,
    "backupId" integer NOT NULL,
    step text NOT NULL,
    status text NOT NULL,
    message text,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."BackupStepLog" OWNER TO whms_user;

--
-- Name: BackupStepLog_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."BackupStepLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."BackupStepLog_id_seq" OWNER TO whms_user;

--
-- Name: BackupStepLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."BackupStepLog_id_seq" OWNED BY public."BackupStepLog".id;


--
-- Name: BackupVersion; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."BackupVersion" (
    id integer NOT NULL,
    "backupId" integer NOT NULL,
    version integer NOT NULL,
    "filePath" text NOT NULL,
    "sizeBytes" bigint,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."BackupVersion" OWNER TO whms_user;

--
-- Name: BackupVersion_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."BackupVersion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."BackupVersion_id_seq" OWNER TO whms_user;

--
-- Name: BackupVersion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."BackupVersion_id_seq" OWNED BY public."BackupVersion".id;


--
-- Name: Backup_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."Backup_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Backup_id_seq" OWNER TO whms_user;

--
-- Name: Backup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."Backup_id_seq" OWNED BY public."Backup".id;


--
-- Name: BillingProfile; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."BillingProfile" (
    id text NOT NULL,
    "clientId" text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "billingAddress" text,
    city text,
    country text,
    "postalCode" text,
    "taxId" text,
    "paymentMethodRef" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."BillingProfile" OWNER TO whms_user;

--
-- Name: BillingTransaction; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."BillingTransaction" (
    id text NOT NULL,
    "invoiceId" text,
    "clientId" text NOT NULL,
    type public."TransactionType" NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    description text,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."BillingTransaction" OWNER TO whms_user;

--
-- Name: ClientProfile; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ClientProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    company text,
    phone text,
    address text,
    country text,
    city text,
    postal text
);


ALTER TABLE public."ClientProfile" OWNER TO whms_user;

--
-- Name: DeveloperProfile; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."DeveloperProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "displayName" text,
    website text,
    github text,
    "payoutsEmail" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "marketplaceMeta" jsonb,
    "publicKeyPem" text,
    "storeName" text,
    "stripeAccountId" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DeveloperProfile" OWNER TO whms_user;

--
-- Name: Domain; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Domain" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    domain text NOT NULL,
    "userId" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL
);


ALTER TABLE public."Domain" OWNER TO whms_user;

--
-- Name: DunningAttempt; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."DunningAttempt" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "attemptNumber" integer NOT NULL,
    action public."DunningAction" NOT NULL,
    status public."DunningStatus" NOT NULL,
    "paymentMethodId" text,
    "amountAttempted" numeric(10,2),
    "gatewayRef" text,
    "errorMessage" text,
    "emailTemplate" text,
    "emailAddress" text,
    "attemptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DunningAttempt" OWNER TO whms_user;

--
-- Name: EmailToken; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."EmailToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    type text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL
);


ALTER TABLE public."EmailToken" OWNER TO whms_user;

--
-- Name: HostingAccount; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."HostingAccount" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "clientId" text NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    "controlPanel" text DEFAULT 'vestacp'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "suspendReason" text,
    "provisionedAt" timestamp(3) without time zone,
    "suspendedAt" timestamp(3) without time zone,
    "deletedAt" timestamp(3) without time zone,
    archived boolean DEFAULT false NOT NULL,
    "diskUsedMB" integer,
    "bandwidthUsedGB" integer,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."HostingAccount" OWNER TO whms_user;

--
-- Name: HostingDatabase; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."HostingDatabase" (
    id text NOT NULL,
    "hostingAccountId" text NOT NULL,
    name text NOT NULL,
    "dbUser" text NOT NULL,
    "dbPassword" text NOT NULL,
    type text DEFAULT 'mysql'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."HostingDatabase" OWNER TO whms_user;

--
-- Name: HostingDomain; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."HostingDomain" (
    id text NOT NULL,
    "hostingAccountId" text NOT NULL,
    domain text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "sslStatus" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."HostingDomain" OWNER TO whms_user;

--
-- Name: HostingEmail; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."HostingEmail" (
    id text NOT NULL,
    "hostingAccountId" text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    quota integer DEFAULT 100 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."HostingEmail" OWNER TO whms_user;

--
-- Name: Impersonation; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Impersonation" (
    id text NOT NULL,
    "adminId" text NOT NULL,
    "impersonatedId" text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) without time zone,
    "sessionToken" text NOT NULL,
    reason text
);


ALTER TABLE public."Impersonation" OWNER TO whms_user;

--
-- Name: IncomingWebhook; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."IncomingWebhook" (
    id text NOT NULL,
    "workflowId" text NOT NULL,
    url text NOT NULL,
    secret text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    events jsonb DEFAULT '[]'::jsonb NOT NULL,
    "retryPolicy" jsonb,
    "totalReceived" integer DEFAULT 0 NOT NULL,
    "lastReceivedAt" timestamp(3) without time zone,
    "failureCount" integer DEFAULT 0 NOT NULL,
    "lastError" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."IncomingWebhook" OWNER TO whms_user;

--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    "clientId" text NOT NULL,
    "billingProfileId" text,
    "orderId" text,
    status public."InvoiceStatus" DEFAULT 'draft'::public."InvoiceStatus" NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "taxAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "discountAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    "amountPaid" numeric(10,2) DEFAULT 0 NOT NULL,
    "amountDue" numeric(10,2) NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "issuedAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "cancelledAt" timestamp(3) without time zone,
    notes text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "invoiceType" public."InvoiceType" DEFAULT 'manual'::public."InvoiceType" NOT NULL,
    "paymentTermDays" integer DEFAULT 7 NOT NULL
);


ALTER TABLE public."Invoice" OWNER TO whms_user;

--
-- Name: InvoiceDiscount; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."InvoiceDiscount" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    type text NOT NULL,
    code text,
    description text,
    amount numeric(10,2) NOT NULL,
    "isPercent" boolean DEFAULT false NOT NULL,
    "appliedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."InvoiceDiscount" OWNER TO whms_user;

--
-- Name: InvoiceLineItem; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."InvoiceLineItem" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    total numeric(10,2) NOT NULL,
    "taxRate" numeric(5,4),
    "taxAmount" numeric(10,2),
    "serviceCode" text,
    "planName" text,
    cycle text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "snapshotId" text
);


ALTER TABLE public."InvoiceLineItem" OWNER TO whms_user;

--
-- Name: IpAccessRule; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."IpAccessRule" (
    id integer NOT NULL,
    pattern text NOT NULL,
    type text NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."IpAccessRule" OWNER TO whms_user;

--
-- Name: IpAccessRule_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."IpAccessRule_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."IpAccessRule_id_seq" OWNER TO whms_user;

--
-- Name: IpAccessRule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."IpAccessRule_id_seq" OWNED BY public."IpAccessRule".id;


--
-- Name: LoginLog; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."LoginLog" (
    id text NOT NULL,
    "userId" text,
    "userEmail" text,
    success boolean NOT NULL,
    ip text,
    "userAgent" text,
    reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoginLog" OWNER TO whms_user;

--
-- Name: MarketplaceProduct; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."MarketplaceProduct" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    category text,
    description text,
    "devId" text NOT NULL,
    name text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    rating numeric(3,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public."MarketplaceProduct" OWNER TO whms_user;

--
-- Name: MarketplacePurchase; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."MarketplacePurchase" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    data jsonb
);


ALTER TABLE public."MarketplacePurchase" OWNER TO whms_user;

--
-- Name: MarketplaceReview; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."MarketplaceReview" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    rating integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    text text,
    title text
);


ALTER TABLE public."MarketplaceReview" OWNER TO whms_user;

--
-- Name: MarketplaceSubmission; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."MarketplaceSubmission" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    json jsonb,
    name text NOT NULL,
    "userId" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL
);


ALTER TABLE public."MarketplaceSubmission" OWNER TO whms_user;

--
-- Name: Order; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    "clientId" text NOT NULL,
    "snapshotId" text,
    status public."OrderStatus" DEFAULT 'pending'::public."OrderStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "nextRenewalAt" timestamp(3) without time zone,
    "suspendedAt" timestamp(3) without time zone,
    "terminatedAt" timestamp(3) without time zone,
    "cancelledAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "provisioningError" text,
    "provisioningStatus" text
);


ALTER TABLE public."Order" OWNER TO whms_user;

--
-- Name: Payment; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "clientId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status public."PaymentStatus" DEFAULT 'pending'::public."PaymentStatus" NOT NULL,
    gateway text,
    "gatewayRef" text,
    "gatewayResponse" jsonb,
    "gatewayStatus" text,
    "paidAt" timestamp(3) without time zone,
    "failedAt" timestamp(3) without time zone,
    "failReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isAutoCharge" boolean DEFAULT false NOT NULL,
    "paymentMethodId" text
);


ALTER TABLE public."Payment" OWNER TO whms_user;

--
-- Name: PaymentMethod; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."PaymentMethod" (
    id text NOT NULL,
    "clientId" text NOT NULL,
    "billingProfileId" text,
    type public."PaymentMethodType" DEFAULT 'card'::public."PaymentMethodType" NOT NULL,
    gateway text NOT NULL,
    "gatewayRef" text NOT NULL,
    "gatewayCustomer" text,
    last4 text,
    brand text,
    "expiryMonth" integer,
    "expiryYear" integer,
    email text,
    "bankName" text,
    "isDefault" boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PaymentMethod" OWNER TO whms_user;

--
-- Name: Permission; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Permission" (
    id text NOT NULL,
    key text NOT NULL,
    description text
);


ALTER TABLE public."Permission" OWNER TO whms_user;

--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."RefreshToken" (
    id text NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RefreshToken" OWNER TO whms_user;

--
-- Name: Refund; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Refund" (
    id text NOT NULL,
    "paymentId" text NOT NULL,
    "invoiceId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    reason text,
    notes text,
    gateway text,
    "gatewayRef" text,
    "gatewayResponse" jsonb,
    "processedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Refund" OWNER TO whms_user;

--
-- Name: ResellerProfile; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ResellerProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "resellerCode" text NOT NULL,
    company text,
    phone text,
    address text
);


ALTER TABLE public."ResellerProfile" OWNER TO whms_user;

--
-- Name: Role; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public."Role" OWNER TO whms_user;

--
-- Name: RolePermission; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."RolePermission" (
    id text NOT NULL,
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL
);


ALTER TABLE public."RolePermission" OWNER TO whms_user;

--
-- Name: Service; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Service" (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    "shortDescription" text,
    "groupId" text,
    "parentServiceId" text,
    "moduleName" text,
    "moduleType" text,
    active boolean DEFAULT true NOT NULL,
    hidden boolean DEFAULT false NOT NULL,
    taxable boolean DEFAULT true NOT NULL,
    "autoSetup" boolean DEFAULT true NOT NULL,
    "autoSuspend" boolean DEFAULT true NOT NULL,
    "autoTerminate" boolean DEFAULT false NOT NULL,
    "customizeOption" text DEFAULT 'none'::text NOT NULL,
    "paymentType" text DEFAULT 'regular'::text NOT NULL,
    "requiresDomain" boolean DEFAULT false NOT NULL,
    "allowAutoRenew" boolean DEFAULT true NOT NULL,
    "billingCycles" text DEFAULT 'monthly,quarterly,semi_annually,annually'::text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Service" OWNER TO whms_user;

--
-- Name: ServiceAddon; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServiceAddon" (
    id text NOT NULL,
    "serviceId" text NOT NULL,
    name text NOT NULL,
    description text,
    code text NOT NULL,
    "setupFee" numeric(10,2) DEFAULT 0 NOT NULL,
    "monthlyPrice" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "maxQuantity" integer,
    required boolean DEFAULT false NOT NULL,
    recurring boolean DEFAULT true NOT NULL,
    "billingType" text DEFAULT 'shared'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceAddon" OWNER TO whms_user;

--
-- Name: ServiceAddonPricing; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServiceAddonPricing" (
    id text NOT NULL,
    "addonId" text NOT NULL,
    cycle text NOT NULL,
    price numeric(10,2) NOT NULL,
    "setupFee" numeric(10,2) DEFAULT 0 NOT NULL,
    "renewalPrice" numeric(10,2),
    currency text DEFAULT 'USD'::text NOT NULL
);


ALTER TABLE public."ServiceAddonPricing" OWNER TO whms_user;

--
-- Name: ServiceAutomation; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServiceAutomation" (
    id text NOT NULL,
    "serviceId" text NOT NULL,
    event text NOT NULL,
    action text NOT NULL,
    module text,
    "provisioningKey" text,
    "webhookUrl" text,
    "emailTemplate" text,
    config jsonb,
    enabled boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceAutomation" OWNER TO whms_user;

--
-- Name: ServiceConfiguration; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServiceConfiguration" (
    id text NOT NULL,
    "serviceId" text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    "valueType" text DEFAULT 'string'::text NOT NULL,
    description text
);


ALTER TABLE public."ServiceConfiguration" OWNER TO whms_user;

--
-- Name: ServiceFeature; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServiceFeature" (
    id text NOT NULL,
    "serviceId" text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    type text DEFAULT 'text'::text NOT NULL,
    unit text,
    icon text,
    category text,
    active boolean DEFAULT true NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceFeature" OWNER TO whms_user;

--
-- Name: ServiceGroup; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServiceGroup" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    icon text,
    "position" integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    hidden boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceGroup" OWNER TO whms_user;

--
-- Name: ServicePlan; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServicePlan" (
    id text NOT NULL,
    "serviceId" text NOT NULL,
    name text NOT NULL,
    summary text,
    description text,
    "paymentType" text DEFAULT 'regular'::text NOT NULL,
    "minimumBillingCycles" integer DEFAULT 1 NOT NULL,
    "maximumBillingCycles" integer,
    "allowAutoSetup" boolean DEFAULT true NOT NULL,
    "customizeOption" text DEFAULT 'none'::text NOT NULL,
    "showDomainOptions" boolean DEFAULT false NOT NULL,
    "maxClients" integer,
    "maxOrders" integer,
    "maxQuantity" integer DEFAULT 1 NOT NULL,
    "stockLimit" integer,
    active boolean DEFAULT true NOT NULL,
    hidden boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServicePlan" OWNER TO whms_user;

--
-- Name: ServicePlanAddon; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServicePlanAddon" (
    id text NOT NULL,
    "planId" text NOT NULL,
    "addonId" text NOT NULL,
    included boolean DEFAULT false NOT NULL,
    quantity integer DEFAULT 1 NOT NULL
);


ALTER TABLE public."ServicePlanAddon" OWNER TO whms_user;

--
-- Name: ServicePlanAutomation; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServicePlanAutomation" (
    id text NOT NULL,
    "planId" text NOT NULL,
    event text NOT NULL,
    action text NOT NULL,
    config jsonb,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public."ServicePlanAutomation" OWNER TO whms_user;

--
-- Name: ServicePlanConfiguration; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServicePlanConfiguration" (
    id text NOT NULL,
    "planId" text NOT NULL,
    key text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public."ServicePlanConfiguration" OWNER TO whms_user;

--
-- Name: ServicePlanFeature; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServicePlanFeature" (
    id text NOT NULL,
    "planId" text NOT NULL,
    "featureId" text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public."ServicePlanFeature" OWNER TO whms_user;

--
-- Name: ServicePlanPolicy; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServicePlanPolicy" (
    id text NOT NULL,
    "planId" text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public."ServicePlanPolicy" OWNER TO whms_user;

--
-- Name: ServicePolicy; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServicePolicy" (
    id text NOT NULL,
    "serviceId" text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    value text NOT NULL,
    "valueType" text DEFAULT 'string'::text NOT NULL,
    description text,
    enforced boolean DEFAULT true NOT NULL
);


ALTER TABLE public."ServicePolicy" OWNER TO whms_user;

--
-- Name: ServicePricing; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServicePricing" (
    id text NOT NULL,
    "planId" text NOT NULL,
    cycle text NOT NULL,
    "setupFee" numeric(10,2) DEFAULT 0 NOT NULL,
    price numeric(10,2) NOT NULL,
    "renewalPrice" numeric(10,2),
    "suspensionFee" numeric(10,2) DEFAULT 0 NOT NULL,
    "terminationFee" numeric(10,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "discountType" text,
    "discountAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "discountValidUntil" timestamp(3) without time zone,
    taxable boolean DEFAULT true NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServicePricing" OWNER TO whms_user;

--
-- Name: ServiceSnapshot; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServiceSnapshot" (
    id text NOT NULL,
    "planId" text NOT NULL,
    service jsonb NOT NULL,
    "planData" jsonb NOT NULL,
    pricing jsonb NOT NULL,
    features jsonb NOT NULL,
    addons jsonb,
    policies jsonb,
    automations jsonb,
    "capturedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceSnapshot" OWNER TO whms_user;

--
-- Name: ServiceTemplate; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServiceTemplate" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    config jsonb NOT NULL,
    plans jsonb NOT NULL,
    addons jsonb,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceTemplate" OWNER TO whms_user;

--
-- Name: ServiceUpgradePath; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."ServiceUpgradePath" (
    id text NOT NULL,
    "serviceId" text NOT NULL,
    "fromPlanId" text NOT NULL,
    "toPlanId" text NOT NULL,
    allowed boolean DEFAULT true NOT NULL,
    prorated boolean DEFAULT true NOT NULL,
    "creditUnused" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceUpgradePath" OWNER TO whms_user;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "userAgent" text,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "isImpersonation" boolean DEFAULT false NOT NULL,
    "impersonatorId" text,
    "impersonationReason" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    country text,
    "deviceHash" text,
    "lastActivity" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Session" OWNER TO whms_user;

--
-- Name: StorageConfig; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."StorageConfig" (
    id integer NOT NULL,
    name text NOT NULL,
    provider text NOT NULL,
    config jsonb NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StorageConfig" OWNER TO whms_user;

--
-- Name: StorageConfig_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."StorageConfig_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StorageConfig_id_seq" OWNER TO whms_user;

--
-- Name: StorageConfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."StorageConfig_id_seq" OWNED BY public."StorageConfig".id;


--
-- Name: TaxRule; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."TaxRule" (
    id integer NOT NULL,
    name text NOT NULL,
    rate numeric(5,4) NOT NULL,
    country text,
    region text,
    "serviceType" text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TaxRule" OWNER TO whms_user;

--
-- Name: TaxRule_id_seq; Type: SEQUENCE; Schema: public; Owner: whms_user
--

CREATE SEQUENCE public."TaxRule_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TaxRule_id_seq" OWNER TO whms_user;

--
-- Name: TaxRule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms_user
--

ALTER SEQUENCE public."TaxRule_id_seq" OWNED BY public."TaxRule".id;


--
-- Name: Ticket; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."Ticket" (
    id text NOT NULL,
    subject text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    category text,
    "closedAt" timestamp(3) without time zone,
    description text NOT NULL,
    "ticketCode" text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public."Ticket" OWNER TO whms_user;

--
-- Name: TicketReply; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."TicketReply" (
    id text NOT NULL,
    "ticketId" text NOT NULL,
    "createdBy" text NOT NULL,
    message text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."TicketReply" OWNER TO whms_user;

--
-- Name: TrustedDevice; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."TrustedDevice" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "deviceId" text NOT NULL,
    "userAgent" text,
    ip text,
    name text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastUsedAt" timestamp(3) without time zone NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public."TrustedDevice" OWNER TO whms_user;

--
-- Name: User; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "mfaBackupCodes" text[] DEFAULT ARRAY[]::text[],
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaSecret" text,
    "passwordHash" text NOT NULL,
    disabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public."User" OWNER TO whms_user;

--
-- Name: UserRole; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."UserRole" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "roleId" text NOT NULL
);


ALTER TABLE public."UserRole" OWNER TO whms_user;

--
-- Name: WebhookEvent; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."WebhookEvent" (
    id text NOT NULL,
    event text NOT NULL,
    data jsonb NOT NULL,
    processed boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WebhookEvent" OWNER TO whms_user;

--
-- Name: WorkflowRun; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."WorkflowRun" (
    id text NOT NULL,
    "workflowId" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "triggeredBy" text DEFAULT 'manual'::text NOT NULL,
    input jsonb,
    output jsonb,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    "errorMessage" text,
    "errorStack" text,
    "totalDuration" integer,
    "successCount" integer DEFAULT 0 NOT NULL,
    "failureCount" integer DEFAULT 0 NOT NULL,
    "taskCount" integer DEFAULT 0 NOT NULL,
    "skippedCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "triggerId" text
);


ALTER TABLE public."WorkflowRun" OWNER TO whms_user;

--
-- Name: WorkflowTaskRun; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."WorkflowTaskRun" (
    id text NOT NULL,
    "runId" text NOT NULL,
    "taskId" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 0 NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    duration integer,
    output jsonb,
    "errorMessage" text,
    "errorStack" text,
    "conditionResult" boolean,
    "selectedPath" text,
    "nextRetryAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WorkflowTaskRun" OWNER TO whms_user;

--
-- Name: WorkflowTriggerRule; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public."WorkflowTriggerRule" (
    id text NOT NULL,
    "workflowId" text NOT NULL,
    "eventType" text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    conditions jsonb,
    "passEventAsInput" boolean DEFAULT false NOT NULL,
    "inputMapping" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WorkflowTriggerRule" OWNER TO whms_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: whms_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO whms_user;

--
-- Name: AuditLog id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AuditLog" ALTER COLUMN id SET DEFAULT nextval('public."AuditLog_id_seq"'::regclass);


--
-- Name: AutomationProfile id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AutomationProfile" ALTER COLUMN id SET DEFAULT nextval('public."AutomationProfile_id_seq"'::regclass);


--
-- Name: AutomationRun id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AutomationRun" ALTER COLUMN id SET DEFAULT nextval('public."AutomationRun_id_seq"'::regclass);


--
-- Name: AutomationTask id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AutomationTask" ALTER COLUMN id SET DEFAULT nextval('public."AutomationTask_id_seq"'::regclass);


--
-- Name: Backup id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Backup" ALTER COLUMN id SET DEFAULT nextval('public."Backup_id_seq"'::regclass);


--
-- Name: BackupStepLog id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BackupStepLog" ALTER COLUMN id SET DEFAULT nextval('public."BackupStepLog_id_seq"'::regclass);


--
-- Name: BackupVersion id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BackupVersion" ALTER COLUMN id SET DEFAULT nextval('public."BackupVersion_id_seq"'::regclass);


--
-- Name: IpAccessRule id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."IpAccessRule" ALTER COLUMN id SET DEFAULT nextval('public."IpAccessRule_id_seq"'::regclass);


--
-- Name: StorageConfig id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."StorageConfig" ALTER COLUMN id SET DEFAULT nextval('public."StorageConfig_id_seq"'::regclass);


--
-- Name: TaxRule id; Type: DEFAULT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."TaxRule" ALTER COLUMN id SET DEFAULT nextval('public."TaxRule_id_seq"'::regclass);


--
-- Data for Name: AdminProfile; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."AdminProfile" (id, "userId", department, "staffTitle", "restrictionJson") FROM stdin;
27ed6b3e-1c3a-411c-a51d-67e774786661	ea27b74d-bb76-4789-b18b-0686c0f07a62	System	Super Administrator	\N
\.


--
-- Data for Name: ApiKey; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ApiKey" (id, "userId", name, "keyHash", "createdAt", revoked, "expiresAt") FROM stdin;
\.


--
-- Data for Name: ApiKeyScope; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ApiKeyScope" (id, "apiKeyId", scope) FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."AuditLog" ("userId", action, "createdAt", data, entity, "entityId", ip, "userAgent", actor, level, meta, source, id, "profileId") FROM stdin;
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-09 00:05:50.74	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	1	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-09 00:05:50.762	{"ip": "::1", "country": "Unknown", "userAgent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	2	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-09 00:07:33.999	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	3	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	security.new_device	2026-03-09 00:07:34.016	{"ip": "::1", "country": "Unknown", "userAgent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"}	session	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	4	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-09 01:16:51.02	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	\N	system	INFO	\N	system	5	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-09 01:16:51.035	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": null}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	\N	system	INFO	\N	system	6	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-09 01:16:51.316	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	\N	system	INFO	\N	system	7	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	security.new_device	2026-03-09 01:16:51.33	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": null}	session	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	\N	system	INFO	\N	system	8	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-09 01:25:08.382	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/1.0	system	INFO	\N	system	9	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-09 01:25:08.396	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "TestSuite/1.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/1.0	system	INFO	\N	system	10	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-09 01:25:08.666	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	TestSuite/1.0	system	INFO	\N	system	11	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	security.new_device	2026-03-09 01:25:08.68	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "TestSuite/1.0"}	session	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	TestSuite/1.0	system	INFO	\N	system	12	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-09 01:48:40.783	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	13	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-09 01:48:40.798	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "TestSuite/2.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	14	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-09 01:48:41.064	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	15	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	security.new_device	2026-03-09 01:48:41.078	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "TestSuite/2.0"}	session	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	16	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-09 01:48:41.329	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	17	\N
\N	login.failure	2026-03-09 01:48:41.36	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	18	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-16 09:16:56.753	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	19	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-16 09:16:57.216	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	20	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-16 09:16:57.634	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	21	\N
\N	login.failure	2026-03-16 09:16:57.668	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	TestSuite/2.0	system	INFO	\N	system	22	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-17 06:43:28.301	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	23	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-17 07:45:37.362	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	24	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-17 07:49:47.508	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	25	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-17 07:50:00.059	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	26	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-17 08:05:52.166	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	27	\N
\N	profile.scheduled	2026-03-21 15:03:52.482	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	241	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-17 08:06:54.543	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	28	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-17 08:26:09.817	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	29	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-18 07:49:26.154	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/3.0	system	INFO	\N	system	30	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-18 07:49:26.173	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "TestSuite/3.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/3.0	system	INFO	\N	system	31	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-18 07:49:26.622	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	TestSuite/3.0	system	INFO	\N	system	32	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	security.new_device	2026-03-18 07:49:26.637	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "TestSuite/3.0"}	session	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	TestSuite/3.0	system	INFO	\N	system	33	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-18 07:58:04.719	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/4.0	system	INFO	\N	system	34	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-18 07:58:04.735	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "TestSuite/4.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	TestSuite/4.0	system	INFO	\N	system	35	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-18 07:58:05.267	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	TestSuite/4.0	system	INFO	\N	system	36	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	security.new_device	2026-03-18 07:58:05.281	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "TestSuite/4.0"}	session	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	TestSuite/4.0	system	INFO	\N	system	37	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 04:55:10.736	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	38	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 04:56:28.39	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	39	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-19 04:56:28.404	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	40	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 05:57:02.538	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	41	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-19 05:57:02.552	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "ServiceOrderTestSuite/1.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	42	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 05:57:02.844	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	43	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	security.new_device	2026-03-19 05:57:02.858	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "ServiceOrderTestSuite/1.0"}	session	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	44	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 05:57:03.113	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	45	\N
\N	login.failure	2026-03-19 05:57:03.147	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	46	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 05:59:15.462	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	47	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:01:46.439	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	48	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:01:46.756	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	49	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:01:47.041	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	50	\N
\N	login.failure	2026-03-19 06:01:47.076	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	51	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:09:57.358	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	52	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:09:57.695	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	53	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:09:57.97	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	54	\N
\N	login.failure	2026-03-19 06:09:58	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	55	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:11:23.886	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	56	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:11:24.197	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	57	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:11:24.514	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	58	\N
\N	login.failure	2026-03-19 06:11:24.544	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	59	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:15:27.591	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	60	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:15:35.795	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	61	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:15:43.05	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	62	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:15:43.349	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	63	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:15:43.611	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	64	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:17:19.65	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	65	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-19 06:17:19.664	{"ip": "::1", "country": "Unknown", "userAgent": "curl/8.5.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	66	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:18:12.309	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	67	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:30:13.742	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	68	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:30:27.142	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	69	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:33:25.067	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	70	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:33:25.561	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	71	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:33:25.839	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	72	\N
\N	login.failure	2026-03-19 06:33:25.87	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	73	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:34:29.625	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	74	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:34:44.618	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	75	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:35:34.71	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	76	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:39:04.495	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	77	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:39:56.127	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	78	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:40:07.661	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	79	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:41:03.224	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	80	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:41:59.885	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	81	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:42:08.11	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	82	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:42:08.421	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	83	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:42:08.694	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	84	\N
\N	login.failure	2026-03-19 06:42:08.724	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	85	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:49:28.45	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	86	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:52:57.549	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	87	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:52:57.867	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	88	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:52:58.159	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	89	\N
\N	login.failure	2026-03-19 06:52:58.19	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	90	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:54:57.722	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	91	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:55:37.17	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	92	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:55:37.454	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	93	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:55:37.716	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	94	\N
\N	login.failure	2026-03-19 06:55:37.746	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	95	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:55:57.984	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	96	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:55:58.339	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	97	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 06:55:58.598	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	98	\N
\N	login.failure	2026-03-19 06:55:58.628	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	99	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:57:26.28	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	100	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 06:58:48.057	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	101	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 06:58:48.415	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	curl/8.5.0	system	INFO	\N	system	102	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	security.new_device	2026-03-19 06:58:48.429	{"ip": "::1", "country": "Unknown", "userAgent": "curl/8.5.0"}	session	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	curl/8.5.0	system	INFO	\N	system	103	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 07:00:21.606	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	104	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 07:00:21.913	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	curl/8.5.0	system	INFO	\N	system	105	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 07:07:11.523	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	106	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 07:07:11.837	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	107	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 07:07:12.143	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	108	\N
\N	login.failure	2026-03-19 07:07:12.174	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	109	\N
\N	login.failure	2026-03-19 07:08:17.34	{"email": "admin@example.com", "reason": "user_not_found"}	auth	\N	::1	curl/8.5.0	system	INFO	\N	system	110	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 07:09:33.92	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	curl/8.5.0	system	INFO	\N	system	111	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 07:09:47.05	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	112	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 07:09:47.37	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	113	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 07:09:47.654	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	114	\N
\N	login.failure	2026-03-19 07:09:47.685	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	115	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 07:11:59.227	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	116	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 07:11:59.522	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	117	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 07:11:59.797	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	118	\N
\N	login.failure	2026-03-19 07:11:59.839	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	119	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 07:28:30.48	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	120	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 07:28:31.033	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	121	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 07:28:31.448	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	122	\N
\N	login.failure	2026-03-19 07:28:31.482	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	123	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 12:56:49.259	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	124	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 12:56:49.739	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	125	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 12:56:50.13	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	126	\N
\N	login.failure	2026-03-19 12:56:50.164	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	127	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 12:59:47.388	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	128	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 12:59:47.836	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	129	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 12:59:48.21	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	130	\N
\N	login.failure	2026-03-19 12:59:48.243	{"email": "nonexistent@example.com", "reason": "user_not_found"}	auth	\N	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	system	INFO	\N	system	131	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-19 14:36:58.399	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	132	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-19 14:36:58.42	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "BillingTestSuite/1.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	133	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-19 14:36:58.858	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	134	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	security.new_device	2026-03-19 14:36:58.872	{"ip": "::ffff:127.0.0.1", "country": "Unknown", "userAgent": "BillingTestSuite/1.0"}	session	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	135	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-19 14:36:59.266	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	136	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 00:24:22.136	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	137	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-20 00:24:22.498	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	138	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-20 00:24:22.881	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	139	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 00:49:58.545	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	140	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-20 00:49:59.012	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	141	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.failure	2026-03-20 00:49:59.404	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	BillingTestSuite/1.0	system	INFO	\N	system	142	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 09:21:05.953	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	143	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 10:07:04.081	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	144	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 10:26:34.15	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	145	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 10:42:06.641	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	146	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 10:58:10.896	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	147	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 11:03:13.911	{"reason": "xxxxxxx"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	148	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-20 11:03:48.56	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	149	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-20 11:04:16.128	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	150	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 11:14:08.72	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	151	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 11:29:18.044	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	152	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 11:35:31.048	{"reason": "fahad"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	153	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 11:35:43.059	{"reason": "bb"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	154	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 11:37:50.801	{"reason": "b"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	155	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 12:15:38.721	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	156	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 12:15:57.266	{"reason": "vv"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	157	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 12:19:38.119	{"reason": "vvv"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	158	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 12:20:52.039	{"reason": "bbb"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	159	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 12:26:09.443	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	160	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 12:28:39.044	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	161	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 12:28:46.978	{"reason": "ccc"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	162	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 12:30:16.968	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	163	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 12:32:10.7	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	164	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 12:32:23.067	{"reason": "hammad"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	165	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 12:36:39.753	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	166	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 12:40:07.812	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	167	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 12:40:16.26	{"reason": "nnn"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	168	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 12:45:19.038	{"reason": "c"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	169	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 12:45:42.521	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	170	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 12:45:55.988	{"reason": "hammad"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	171	\N
\N	profile.scheduled	2026-03-21 15:03:52.482	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	242	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-20 12:53:54.368	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	172	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-20 12:54:10.686	{"reason": "hammad"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	173	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-21 12:35:09.686	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	174	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 12:44:12.358	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	175	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-21 12:46:55.816	{"reason": "b"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	176	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.failure	2026-03-21 12:48:51.316	{"email": "ihammad317@gmail.com", "reason": "invalid_password"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	177	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-21 12:49:03.22	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	178	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.stop	2026-03-21 12:49:09.121	null	Session	f2548bfd-925b-4d3c-bc86-919755e21a03	\N	\N	system	INFO	\N	system	179	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-21 12:49:38.095	{"reason": "v"}	User	61bc7bb7-12e8-42a4-bffe-f7a7d9d95254	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	180	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.stop	2026-03-21 12:49:45.051	null	Session	49929ef1-03b5-4fa0-a7c5-eed32d09f07b	\N	\N	system	INFO	\N	system	181	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-21 12:50:32.408	{"reason": "hammad"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	182	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.stop	2026-03-21 12:50:53.981	null	Session	d0a38c41-a20a-4da4-93d8-786f6cbc454b	\N	\N	system	INFO	\N	system	183	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	admin.update_user_roles	2026-03-21 12:51:39.535	{"roles": ["admin"]}	user	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	\N	system	INFO	\N	system	184	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	impersonation.start	2026-03-21 12:51:46.482	{"reason": "b"}	User	75be047c-38b6-4cfc-aa3b-3c996c67755d	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	185	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	impersonation.start	2026-03-21 12:52:33.364	{"reason": "hammad"}	User	61bc7bb7-12e8-42a4-bffe-f7a7d9d95254	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	186	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	impersonation.stop	2026-03-21 12:52:48.747	null	Session	622c8897-522e-4c64-94d0-48d72117061c	\N	\N	system	INFO	\N	system	187	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	admin.update_user_roles	2026-03-21 12:56:34.387	{"roles": ["client"]}	user	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	\N	system	INFO	\N	system	188	\N
75be047c-38b6-4cfc-aa3b-3c996c67755d	login.success	2026-03-21 12:57:18.183	{"email": "ihammad317@gmail.com", "reason": "login_success"}	auth	75be047c-38b6-4cfc-aa3b-3c996c67755d	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	system	INFO	\N	system	189	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:18:34.5	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	190	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:33:36.345	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	191	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-21 13:33:36.361	{"ip": "127.0.0.1", "country": "Local", "userAgent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	192	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:35:23.505	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	193	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:47:58.272	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	194	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	security.new_device	2026-03-21 13:47:58.287	{"ip": "192.168.100.214", "country": "Unknown", "userAgent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0"}	session	ea27b74d-bb76-4789-b18b-0686c0f07a62	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	195	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:48:04.949	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	196	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:48:06.565	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	197	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:48:24.916	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	198	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:48:26.411	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	199	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:49:31.774	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	200	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 13:53:21.086	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	201	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 14:19:38.545	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	202	\N
\N	profile.manual_run_queued	2026-03-21 14:24:16.894	null	\N	\N	\N	\N	system	INFO	{"runId": 1, "profileId": 1}	automation	203	\N
\N	profile.manual_run	2026-03-21 14:24:16.913	null	\N	\N	\N	\N	system	INFO	{"runId": 1, "profileId": 1}	automation	204	\N
\N	profile.complete	2026-03-21 14:24:16.98	null	\N	\N	\N	\N	worker	INFO	{"runId": 1, "nodeId": "worker-default", "profileId": 1}	automation	205	\N
\N	profile.scheduled	2026-03-21 14:24:40.163	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 1}	automation	206	\N
\N	profile.enable	2026-03-21 14:24:40.163	null	\N	\N	\N	\N	system	INFO	{"profileId": 1}	automation	207	\N
\N	profile.unscheduled	2026-03-21 14:24:43.312	null	\N	\N	\N	\N	system	INFO	{"profileId": 1}	automation	208	\N
\N	profile.disable	2026-03-21 14:24:43.312	null	\N	\N	\N	\N	system	INFO	{"profileId": 1}	automation	209	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 14:35:06.091	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	210	\N
\N	profile.scheduled	2026-03-21 14:45:01.939	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	211	\N
\N	profile.scheduled	2026-03-21 14:45:01.939	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	212	\N
\N	profile.scheduled	2026-03-21 14:45:01.939	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	213	\N
\N	profile.scheduled	2026-03-21 14:45:01.939	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	214	\N
\N	profile.scheduled	2026-03-21 14:49:06.569	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	215	\N
\N	profile.scheduled	2026-03-21 14:49:06.569	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	216	\N
\N	profile.scheduled	2026-03-21 14:49:06.569	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	217	\N
\N	profile.scheduled	2026-03-21 14:49:06.569	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	218	\N
\N	profile.scheduled	2026-03-21 14:54:21.657	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	219	\N
\N	profile.scheduled	2026-03-21 14:54:21.657	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	220	\N
\N	profile.scheduled	2026-03-21 14:54:21.657	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	221	\N
\N	profile.scheduled	2026-03-21 14:54:21.657	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	222	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 14:55:01.858	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	223	\N
\N	profile.manual_run_queued	2026-03-21 14:55:16.398	null	\N	\N	\N	\N	system	INFO	{"runId": 2, "profileId": 2}	automation	224	\N
\N	profile.manual_run	2026-03-21 14:55:16.413	null	\N	\N	\N	\N	system	INFO	{"runId": 2, "profileId": 2}	automation	225	\N
\N	task.failed	2026-03-21 14:55:16.505	null	\N	\N	\N	\N	worker	ERROR	{"error": "HTTP POST request failed: Request failed with status code 401", "nodeId": "worker-default", "taskId": 2, "errorCode": "http_request_failed", "profileId": 2, "actionType": "http_request"}	automation	226	\N
\N	profile.complete	2026-03-21 14:55:16.555	null	\N	\N	\N	\N	worker	INFO	{"runId": 2, "nodeId": "worker-default", "profileId": 2}	automation	227	\N
\N	profile.manual_run_queued	2026-03-21 14:55:34.418	null	\N	\N	\N	\N	system	INFO	{"runId": 4, "profileId": 2}	automation	228	\N
\N	profile.manual_run	2026-03-21 14:55:34.437	null	\N	\N	\N	\N	system	INFO	{"runId": 4, "profileId": 2}	automation	229	\N
\N	task.failed	2026-03-21 14:55:34.548	null	\N	\N	\N	\N	worker	ERROR	{"error": "HTTP POST request failed: Request failed with status code 401", "nodeId": "worker-default", "taskId": 2, "errorCode": "http_request_failed", "profileId": 2, "actionType": "http_request"}	automation	230	\N
\N	profile.complete	2026-03-21 14:55:34.577	null	\N	\N	\N	\N	worker	INFO	{"runId": 4, "nodeId": "worker-default", "profileId": 2}	automation	231	\N
\N	profile.scheduled	2026-03-21 14:55:47.303	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	232	\N
\N	profile.scheduled	2026-03-21 14:55:47.303	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	233	\N
\N	profile.scheduled	2026-03-21 14:55:47.303	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	234	\N
\N	profile.scheduled	2026-03-21 14:55:47.303	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	235	\N
\N	backup.queued	2026-03-21 14:56:57.002	null	Backup	1	\N	\N	ea27b74d-bb76-4789-b18b-0686c0f07a62	INFO	null	backup	236	\N
\N	profile.scheduled	2026-03-21 15:03:49.933	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	237	\N
\N	profile.scheduled	2026-03-21 15:03:49.933	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	238	\N
\N	profile.scheduled	2026-03-21 15:03:49.933	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	239	\N
\N	profile.scheduled	2026-03-21 15:03:49.933	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	240	\N
\N	profile.scheduled	2026-03-21 15:03:52.482	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	243	\N
\N	profile.scheduled	2026-03-21 15:03:52.482	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	244	\N
\N	profile.scheduled	2026-03-21 15:05:24.119	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	245	\N
\N	profile.scheduled	2026-03-21 15:05:24.119	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	246	\N
\N	profile.scheduled	2026-03-21 15:05:24.119	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	247	\N
\N	profile.scheduled	2026-03-21 15:05:24.119	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	248	\N
\N	profile.scheduled	2026-03-21 15:05:27.533	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	249	\N
\N	profile.scheduled	2026-03-21 15:05:27.533	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	250	\N
\N	profile.scheduled	2026-03-21 15:05:27.533	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	251	\N
\N	profile.scheduled	2026-03-21 15:05:27.534	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	252	\N
\N	task.run_now	2026-03-21 15:06:43.383	null	\N	\N	\N	\N	system	INFO	{"runId": 6, "taskId": 2, "profileId": 2, "actionType": "http_request"}	automation	253	\N
\N	task.single.failed	2026-03-21 15:06:43.486	null	\N	\N	\N	\N	worker	ERROR	{"error": "HTTP POST request failed: Request failed with status code 401", "runId": 6, "nodeId": "worker-default", "taskId": 2, "errorCode": "http_request_failed", "profileId": 2}	automation	254	\N
\N	task.single.failed	2026-03-21 15:06:44.668	null	\N	\N	\N	\N	worker	ERROR	{"error": "HTTP POST request failed: Request failed with status code 401", "runId": 6, "nodeId": "worker-default", "taskId": 2, "errorCode": "http_request_failed", "profileId": 2}	automation	255	\N
\N	task.single.failed	2026-03-21 15:06:46.742	null	\N	\N	\N	\N	worker	ERROR	{"error": "HTTP POST request failed: Request failed with status code 401", "runId": 6, "nodeId": "worker-default", "taskId": 2, "errorCode": "http_request_failed", "profileId": 2}	automation	256	\N
\N	profile.scheduled	2026-03-21 15:07:09.904	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	257	\N
\N	profile.scheduled	2026-03-21 15:07:09.904	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	258	\N
\N	profile.scheduled	2026-03-21 15:07:09.904	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	259	\N
\N	profile.scheduled	2026-03-21 15:07:09.904	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	260	\N
\N	profile.scheduled	2026-03-21 15:08:38.464	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	261	\N
\N	profile.scheduled	2026-03-21 15:08:38.464	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	262	\N
\N	profile.scheduled	2026-03-21 15:08:38.464	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	263	\N
\N	profile.scheduled	2026-03-21 15:08:38.464	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	264	\N
\N	profile.scheduled	2026-03-21 15:10:46.917	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	265	\N
\N	profile.scheduled	2026-03-21 15:10:46.917	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	266	\N
\N	profile.scheduled	2026-03-21 15:10:46.917	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	267	\N
\N	profile.scheduled	2026-03-21 15:10:46.917	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	268	\N
ea27b74d-bb76-4789-b18b-0686c0f07a62	login.success	2026-03-21 15:11:06.017	{"email": "superadmin@example.com", "reason": "login_success"}	auth	ea27b74d-bb76-4789-b18b-0686c0f07a62	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	system	INFO	\N	system	269	\N
\N	profile.scheduled	2026-03-21 15:11:15.871	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	270	\N
\N	profile.scheduled	2026-03-21 15:11:15.871	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	271	\N
\N	profile.scheduled	2026-03-21 15:11:15.871	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	272	\N
\N	profile.scheduled	2026-03-21 15:11:15.871	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	273	\N
\N	profile.scheduled	2026-03-21 15:11:49.654	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	274	\N
\N	profile.scheduled	2026-03-21 15:11:49.654	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	275	\N
\N	profile.scheduled	2026-03-21 15:11:49.654	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	276	\N
\N	profile.scheduled	2026-03-21 15:11:49.654	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	277	\N
\N	profile.scheduled	2026-03-21 15:13:08.327	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	278	\N
\N	profile.scheduled	2026-03-21 15:13:08.327	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	279	\N
\N	profile.scheduled	2026-03-21 15:13:08.327	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	280	\N
\N	profile.scheduled	2026-03-21 15:13:08.327	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	281	\N
\N	profile.manual_run_queued	2026-03-21 15:14:09.04	null	\N	\N	\N	\N	system	INFO	{"runId": 7, "profileId": 3}	automation	282	\N
\N	profile.manual_run	2026-03-21 15:14:09.061	null	\N	\N	\N	\N	system	INFO	{"runId": 7, "profileId": 3}	automation	283	\N
\N	task.failed	2026-03-21 15:14:09.206	null	\N	\N	\N	\N	worker	ERROR	{"error": "HTTP GET request failed: Request failed with status code 401", "nodeId": "worker-default", "taskId": 3, "errorCode": "http_request_failed", "profileId": 3, "actionType": "http_request"}	automation	284	\N
\N	profile.complete	2026-03-21 15:14:09.242	null	\N	\N	\N	\N	worker	INFO	{"runId": 7, "nodeId": "worker-default", "profileId": 3}	automation	285	\N
\N	profile.scheduled	2026-03-21 15:23:18.226	null	\N	\N	\N	\N	system	INFO	{"cron": "0 8 * * 1", "profileId": 3}	automation	286	\N
\N	profile.scheduled	2026-03-21 15:23:18.226	null	\N	\N	\N	\N	system	INFO	{"cron": "0 2 * * *", "profileId": 2}	automation	287	\N
\N	profile.scheduled	2026-03-21 15:23:18.226	null	\N	\N	\N	\N	system	INFO	{"cron": "0 9 1 * *", "profileId": 4}	automation	288	\N
\N	profile.scheduled	2026-03-21 15:23:18.226	null	\N	\N	\N	\N	system	INFO	{"cron": "0 3 * * *", "profileId": 5}	automation	289	\N
\N	backup.started	2026-03-21 15:23:18.417	null	Backup	1	\N	\N	ea27b74d-bb76-4789-b18b-0686c0f07a62	INFO	null	backup	290	\N
\.


--
-- Data for Name: AutomationProfile; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."AutomationProfile" (id, name, description, "createdAt", "updatedAt", cron, enabled) FROM stdin;
2	Daily Automated Backup	Triggers a full system backup every night at 2am.	2026-03-21 14:44:40.631	2026-03-21 14:44:40.631	0 2 * * *	t
3	Weekly Service Health Check	Checks all active services every Monday morning at 8am.	2026-03-21 14:44:40.66	2026-03-21 14:44:40.66	0 8 * * 1	t
4	Monthly Invoice Run	Triggers recurring billing cycle on the 1st of every month at 9am.	2026-03-21 14:44:40.688	2026-03-21 14:44:40.688	0 9 1 * *	t
5	Daily Expired Session Cleanup	Purges expired sessions and stale tokens every morning at 3am.	2026-03-21 14:44:40.716	2026-03-21 14:44:40.716	0 3 * * *	t
\.


--
-- Data for Name: AutomationRun; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."AutomationRun" (id, "profileId", "taskId", status, "startedAt", "finishedAt", result, "errorMessage", "createdAt") FROM stdin;
3	2	2	failed	2026-03-21 14:55:16.453	2026-03-21 14:55:16.49	\N	HTTP POST request failed: Request failed with status code 401	2026-03-21 14:55:16.44
2	2	\N	success	2026-03-21 14:55:16.399	2026-03-21 14:55:16.54	\N	\N	2026-03-21 14:55:16.381
5	2	2	failed	2026-03-21 14:55:34.507	2026-03-21 14:55:34.533	\N	HTTP POST request failed: Request failed with status code 401	2026-03-21 14:55:34.494
4	2	\N	success	2026-03-21 14:55:34.424	2026-03-21 14:55:34.561	\N	\N	2026-03-21 14:55:34.395
6	2	2	failed	2026-03-21 15:06:46.707	2026-03-21 15:06:46.727	\N	HTTP POST request failed: Request failed with status code 401	2026-03-21 15:06:43.346
8	3	3	failed	2026-03-21 15:14:09.159	2026-03-21 15:14:09.187	\N	HTTP GET request failed: Request failed with status code 401	2026-03-21 15:14:09.142
7	3	\N	success	2026-03-21 15:14:09.041	2026-03-21 15:14:09.223	\N	\N	2026-03-21 15:14:09.008
\.


--
-- Data for Name: AutomationTask; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."AutomationTask" ("createdAt", "actionMeta", "actionType", "order", "profileId", "updatedAt", id) FROM stdin;
2026-03-21 14:44:40.645	{"url": "http://localhost:4000/api/backups", "body": {"name": "Auto Backup", "type": "full", "provider": "local"}, "method": "POST", "headers": {"Content-Type": "application/json"}, "timeout": 30000}	http_request	1	2	2026-03-21 14:44:40.645	2
2026-03-21 14:44:40.673	{"url": "http://localhost:4000/api/admin/services", "method": "GET", "headers": {"Content-Type": "application/json"}, "timeout": 15000}	http_request	1	3	2026-03-21 14:44:40.673	3
2026-03-21 14:44:40.701	{"url": "http://localhost:4000/api/admin/billing/invoices/generate-recurring", "body": {"type": "recurring"}, "method": "POST", "headers": {"Content-Type": "application/json"}, "timeout": 60000}	http_request	1	4	2026-03-21 14:44:40.701	4
2026-03-21 14:44:40.729	{"url": "http://localhost:4000/api/auth/sessions/cleanup", "body": {"olderThanDays": 30}, "method": "POST", "headers": {"Content-Type": "application/json"}, "timeout": 15000}	http_request	1	5	2026-03-21 14:44:40.729	5
\.


--
-- Data for Name: AutomationWorkflow; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."AutomationWorkflow" (id, name, description, definition, enabled, version, "createdAt", "updatedAt", "deletedAt", "eventFilter", "eventType", slug, trigger, type) FROM stdin;
ce53083a-c32b-4947-bff8-14291cd27a9d	Order Provisioning	Automatically provisions the service when a new order is placed and payment is confirmed.	{"tasks": [{"id": "log-order", "input": {"message": "New order received — starting provisioning"}, "actionType": "echo"}, {"id": "provision-service", "url": "http://localhost:4000/api/admin/orders/{{input.orderId}}/provision", "body": {"source": "order.created", "triggeredBy": "automation"}, "retry": {"times": 3, "backoff": "exponential", "delayMs": 5000}, "method": "POST", "headers": {"Content-Type": "application/json"}, "onError": {"fallback": "notify-provision-failure"}, "timeout": 30000, "actionType": "http_request"}, {"id": "notify-provision-failure", "input": {"message": "Provisioning failed for order {{input.orderId}} — manual intervention needed"}, "actionType": "echo"}]}	t	1	2026-03-21 14:44:40.745	2026-03-21 14:44:40.745	\N	\N	order.created	order-provisioning	event	sequential
c50be1a9-d00a-4acf-b9b9-50ada3c8e3da	Payment Activation	Activates or renews a service immediately after a payment is successfully received.	{"tasks": [{"id": "check-payment", "input": {"message": "Payment received for invoice {{input.invoiceId}}"}, "actionType": "echo"}, {"id": "activate-service", "url": "http://localhost:4000/api/admin/billing/invoices/{{input.invoiceId}}/mark-paid", "body": {"automatedActivation": true}, "retry": {"times": 2, "delayMs": 3000}, "method": "POST", "headers": {"Content-Type": "application/json"}, "timeout": 15000, "actionType": "http_request"}]}	t	1	2026-03-21 14:44:40.774	2026-03-21 14:44:40.774	\N	\N	payment.received	payment-activation	event	sequential
7a17222e-f68c-488d-96a1-2bc16ee2baeb	Service Expiry Warning	Sends staged warnings (7-day and 1-day) before a service expires.	{"tasks": [{"id": "check-days", "type": "condition", "onTrue": "send-7day-warning", "onFalse": null, "condition": {"path": "input.daysRemaining", "value": 7, "operator": "lte"}}, {"id": "send-7day-warning", "input": {"message": "EXPIRY WARNING: Service {{input.serviceName}} for client {{input.clientEmail}} expires in {{input.daysRemaining}} days"}, "actionType": "echo"}]}	t	1	2026-03-21 14:44:40.803	2026-03-21 14:44:40.803	\N	\N	service.expiring	service-expiry-warning	event	sequential
9a8ffd58-6468-48dc-bcb6-23113569ed63	Failed Payment Dunning	Initiates the dunning process when a payment fails — suspends after 3 attempts.	{"tasks": [{"id": "log-failure", "input": {"message": "Payment failed for invoice {{input.invoiceId}} — attempt {{input.attemptNumber}}"}, "actionType": "echo"}, {"id": "check-attempt", "type": "condition", "onTrue": "suspend-service", "onFalse": "schedule-retry", "condition": {"path": "input.attemptNumber", "value": 3, "operator": "gte"}}, {"id": "suspend-service", "url": "http://localhost:4000/api/admin/services/{{input.serviceId}}/suspend", "body": {"reason": "non_payment", "automatedBy": "dunning-workflow"}, "method": "POST", "headers": {"Content-Type": "application/json"}, "timeout": 15000, "actionType": "http_request"}, {"id": "schedule-retry", "input": {"message": "Scheduling payment retry for invoice {{input.invoiceId}}"}, "actionType": "echo"}]}	t	1	2026-03-21 14:44:40.837	2026-03-21 14:44:40.837	\N	\N	payment.failed	failed-payment-dunning	event	sequential
16626035-2c5b-407d-8ee7-502c8a574030	Client Onboarding	Runs onboarding tasks when a new client registers: creates billing profile and sends welcome notification.	{"tasks": [{"id": "log-signup", "input": {"message": "New client registered: {{input.email}}"}, "actionType": "echo"}, {"id": "create-billing-profile", "url": "http://localhost:4000/api/admin/billing/profiles", "body": {"userId": "{{input.userId}}", "currency": "USD", "billingCycle": "monthly"}, "retry": {"times": 2, "delayMs": 2000}, "method": "POST", "headers": {"Content-Type": "application/json"}, "timeout": 10000, "actionType": "http_request"}, {"id": "welcome-log", "input": {"message": "Onboarding complete for {{input.email}}"}, "actionType": "echo"}]}	t	1	2026-03-21 14:44:40.875	2026-03-21 14:44:40.875	\N	\N	client.registered	client-onboarding	event	sequential
\.


--
-- Data for Name: Backup; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Backup" (id, name, type, status, "filePath", "sizeBytes", "errorMessage", "retentionDays", "storageConfigId", "createdById", "startedAt", "finishedAt", "createdAt", "updatedAt") FROM stdin;
1	Quick Backup 3/21/2026, 7:56:56 PM	full	running	\N	\N	\N	30	\N	ea27b74d-bb76-4789-b18b-0686c0f07a62	2026-03-21 15:23:18.374	\N	2026-03-21 14:56:56.982	2026-03-21 15:23:18.375
\.


--
-- Data for Name: BackupStepLog; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."BackupStepLog" (id, "backupId", step, status, message, meta, "createdAt") FROM stdin;
1	1	job_started	success	\N	{}	2026-03-21 15:23:18.402
2	1	provider_ready	success	\N	{"provider": "local"}	2026-03-21 15:23:18.417
3	1	db_dump_started	started	\N	{}	2026-03-21 15:23:18.431
\.


--
-- Data for Name: BackupVersion; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."BackupVersion" (id, "backupId", version, "filePath", "sizeBytes", "createdAt") FROM stdin;
\.


--
-- Data for Name: BillingProfile; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."BillingProfile" (id, "clientId", currency, "billingAddress", city, country, "postalCode", "taxId", "paymentMethodRef", "createdAt", "updatedAt") FROM stdin;
02089287-8827-4850-872f-d6698992c8b6	75be047c-38b6-4cfc-aa3b-3c996c67755d	USD	123 Test Street	Lahore	PK	54700	PK-123456	\N	2026-03-09 01:25:09.172	2026-03-20 00:50:00.698
\.


--
-- Data for Name: BillingTransaction; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."BillingTransaction" (id, "invoiceId", "clientId", type, amount, currency, description, meta, "createdAt") FROM stdin;
5a38fe64-31c1-437a-b9fe-ecd61afe97b2	7d7eac3d-e376-452b-89a8-afe60106823c	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	0.00	USD	Invoice created	\N	2026-03-09 01:25:09.212
6a4020a6-ef20-4401-a86d-b3d59df6cbde	7d7eac3d-e376-452b-89a8-afe60106823c	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	99.99	USD	Payment recorded via manual	\N	2026-03-09 01:25:09.364
0e813323-568b-44e4-97ef-b90fd457d842	aa21c76a-39b3-4c6b-82f8-e357f7bbc5a5	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	0.00	USD	Invoice created	\N	2026-03-09 01:48:41.797
0d742302-7d23-493e-9c1f-ebbb7baca43d	aa21c76a-39b3-4c6b-82f8-e357f7bbc5a5	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	99.99	USD	Payment recorded via manual	\N	2026-03-09 01:48:42.033
e4eaaad4-73e9-410c-a6ac-094e4f760146	ba611e7d-81b3-4f23-a4bd-9d4dbaa31ee2	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	0.00	USD	Invoice created	\N	2026-03-16 09:16:58.716
1fcb9419-439e-4097-89f0-00d184d2a176	ba611e7d-81b3-4f23-a4bd-9d4dbaa31ee2	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	99.99	USD	Payment recorded via manual	\N	2026-03-16 09:16:59.192
c64f7d74-79ba-4c55-b857-bcaa39a28a52	3284ae02-6de3-477b-ad9f-15173abacaae	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	0.00	USD	Invoice created	\N	2026-03-18 07:49:29.294
d081587a-2026-4a9d-81fb-ba90c50c89e5	3284ae02-6de3-477b-ad9f-15173abacaae	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	9.99	USD	Payment recorded via manual	\N	2026-03-18 07:49:29.422
7b985aa7-294a-408d-b74c-db8960331a70	95c70590-5409-4b9f-bbc4-5ef6e34a574e	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	0.00	USD	Invoice created	\N	2026-03-18 07:58:07.762
e0920fbc-fa02-4be7-8fe5-35ddf62601c2	95c70590-5409-4b9f-bbc4-5ef6e34a574e	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	9.99	USD	Payment recorded via manual	\N	2026-03-18 07:58:07.967
9509683d-e062-4020-a7fe-2e8283eb70de	68606940-0cdf-415c-9af9-7a075ccd3c1b	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	17.55	USD	Payment recorded via manual	\N	2026-03-19 14:37:07.87
5ae95543-2bee-4055-bceb-47593d436a87	68606940-0cdf-415c-9af9-7a075ccd3c1b	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	17.54	USD	Payment recorded via stripe	\N	2026-03-19 14:37:08.226
fac58e9f-37b6-48cf-8aba-2a01e0bc7a32	ab98101d-bb28-4623-a5f2-77e2eaf72b16	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	35.09	USD	Gateway payment initiated via stripe	\N	2026-03-19 14:37:08.747
565e912e-2dec-4ca9-9daf-a6ede9c62831	64265f83-a63b-4a7a-bc27-0e7918a16699	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	1035.09	USD	Payment recorded via manual	\N	2026-03-19 14:37:09.149
d6b5d8e2-2c31-4fa8-b0bd-43e8505f33e3	68606940-0cdf-415c-9af9-7a075ccd3c1b	75be047c-38b6-4cfc-aa3b-3c996c67755d	refund	5.85	USD	Refund processed: Partial service credit	\N	2026-03-19 14:37:10.222
ae03db5b-2503-418d-881d-83dc2b6b44d8	68606940-0cdf-415c-9af9-7a075ccd3c1b	75be047c-38b6-4cfc-aa3b-3c996c67755d	refund	11.69	USD	Refund processed: Full service cancellation	\N	2026-03-19 14:37:10.649
be7d205e-c261-4e43-8cd8-5dab102750c2	af7cf402-ed48-46b1-b05f-65a4f2628b65	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	35.09	USD	Payment recorded via manual	\N	2026-03-19 14:37:11.022
1f1f9400-b714-488e-a2b1-ca9c0f13dac6	94a32756-6285-447e-aeb5-999593ce2aad	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	35.09	USD	Payment recorded via manual	\N	2026-03-19 14:37:11.657
c0043f22-8db4-48be-bdc6-483310fad380	5d3eca53-5905-4aba-ac75-abb64ee9a656	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	17.55	USD	Payment recorded via manual	\N	2026-03-20 00:24:31.186
91459ee6-0ee8-48b6-82a5-db3c8a11dccd	5d3eca53-5905-4aba-ac75-abb64ee9a656	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	17.54	USD	Payment recorded via stripe	\N	2026-03-20 00:24:31.516
ab8fc679-0e9e-4ddb-a8fa-b55f55551f16	55e6ed6d-2bd4-4617-88db-44180d9be4ba	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	35.09	USD	Gateway payment initiated via stripe	\N	2026-03-20 00:24:32.011
603a29b6-e534-4586-be80-06b1adba96a7	dc4348e6-0930-4cee-97c1-efc5687de545	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	1035.09	USD	Payment recorded via manual	\N	2026-03-20 00:24:32.387
32f6c8ce-cc8a-48af-84d5-280606eac210	5d3eca53-5905-4aba-ac75-abb64ee9a656	75be047c-38b6-4cfc-aa3b-3c996c67755d	refund	5.85	USD	Refund processed: Partial service credit	\N	2026-03-20 00:24:33.426
b699bd05-9e9c-412e-ac41-8f4b8ac72c58	5d3eca53-5905-4aba-ac75-abb64ee9a656	75be047c-38b6-4cfc-aa3b-3c996c67755d	refund	11.69	USD	Refund processed: Full service cancellation	\N	2026-03-20 00:24:33.86
a8d3ac45-1741-49b3-9012-c55b681cc6c4	dfa94450-6de6-457c-9328-133668c7c575	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	35.09	USD	Payment recorded via manual	\N	2026-03-20 00:24:34.217
30d51aae-7885-40f0-9b64-9a936d4ae768	3ae54a3c-6ed2-4457-977e-63feed611fd2	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	35.09	USD	Payment recorded via manual	\N	2026-03-20 00:24:34.883
afbc0b67-49ff-4c3f-8f4f-7ffd1500339c	bb84cdef-e070-4482-b547-3cfc06a499eb	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	22.54	USD	Payment via manual - 06ce5231-d845-4677-bf2a-dd18fea17c5d	null	2026-03-20 00:50:07.905
6d62224d-5048-4d35-ba6a-2a0a52e20d06	bb84cdef-e070-4482-b547-3cfc06a499eb	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	22.54	USD	Payment via stripe - 907a28d6-31ab-4bf2-bded-b501fb78077c	null	2026-03-20 00:50:08.247
840df3b4-dde0-4a08-98b3-aa9499daaab2	bb84cdef-e070-4482-b547-3cfc06a499eb	75be047c-38b6-4cfc-aa3b-3c996c67755d	refund	7.51	USD	Refund for payment 907a28d6-31ab-4bf2-bded-b501fb78077c - Partial service credit	null	2026-03-20 00:50:10.307
c64d2aeb-bf58-4de0-a452-4abc5354eac8	bb84cdef-e070-4482-b547-3cfc06a499eb	75be047c-38b6-4cfc-aa3b-3c996c67755d	refund	15.03	USD	Refund for payment 907a28d6-31ab-4bf2-bded-b501fb78077c - Full service cancellation	null	2026-03-20 00:50:10.776
e4813961-83f4-423d-ba06-2f9e3e65c8a7	12371e0c-729c-4c8c-95c6-5b6e9d552438	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	45.08	USD	Payment via manual - 2bbe556d-560f-47fb-af6d-bebd7274eb2e	null	2026-03-20 00:50:11.173
7718804b-54bc-4612-8c61-c3c4d599e5c9	3c796640-f5e7-4be4-a252-dc5d270e427e	75be047c-38b6-4cfc-aa3b-3c996c67755d	payment	45.08	USD	Payment via manual - 88cf5267-d172-476e-97da-794298a51d4f	null	2026-03-20 00:50:11.845
\.


--
-- Data for Name: ClientProfile; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ClientProfile" (id, "userId", company, phone, address, country, city, postal) FROM stdin;
523e4735-e98d-4983-8fbb-be2d4da9a634	61bc7bb7-12e8-42a4-bffe-f7a7d9d95254	Test Client Company	\N	\N	\N	\N	\N
d853ef3b-9b11-4e5a-9cae-1385d1068c8f	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	\N	\N	\N	\N	\N
25882fb5-ac13-4923-9028-f27597c457eb	0fbbe234-25b6-45ee-857e-9c9c4745b443	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: DeveloperProfile; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."DeveloperProfile" (id, "userId", "displayName", website, github, "payoutsEmail", "createdAt", "marketplaceMeta", "publicKeyPem", "storeName", "stripeAccountId", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Domain; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Domain" (id, "createdAt", "updatedAt", domain, "userId", status) FROM stdin;
\.


--
-- Data for Name: DunningAttempt; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."DunningAttempt" (id, "invoiceId", "attemptNumber", action, status, "paymentMethodId", "amountAttempted", "gatewayRef", "errorMessage", "emailTemplate", "emailAddress", "attemptedAt") FROM stdin;
\.


--
-- Data for Name: EmailToken; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."EmailToken" (id, "userId", "tokenHash", type, "createdAt", "expiresAt", used) FROM stdin;
93282ab6-aac8-4871-b5fd-e71b653cd629	75be047c-38b6-4cfc-aa3b-3c996c67755d	c45979168ec75be03d61e0835d5ca8dce2a85c87207c7678e371dab1568adf98	verify	2026-03-09 00:06:52.704	2026-03-09 00:21:52.703	f
a651dbe1-2a24-4d2b-a0f8-ab166fdd0bff	0fbbe234-25b6-45ee-857e-9c9c4745b443	6fd86a066663d6d3e3322da41e63a114e23aed9a02209b51496f8c24ea9a7b6d	verify	2026-03-21 13:02:41.663	2026-03-21 13:17:41.662	f
\.


--
-- Data for Name: HostingAccount; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."HostingAccount" (id, "orderId", "clientId", username, password, "controlPanel", status, "suspendReason", "provisionedAt", "suspendedAt", "deletedAt", archived, "diskUsedMB", "bandwidthUsedGB", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: HostingDatabase; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."HostingDatabase" (id, "hostingAccountId", name, "dbUser", "dbPassword", type, status, "createdAt") FROM stdin;
\.


--
-- Data for Name: HostingDomain; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."HostingDomain" (id, "hostingAccountId", domain, status, "sslStatus", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: HostingEmail; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."HostingEmail" (id, "hostingAccountId", email, password, quota, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Impersonation; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Impersonation" (id, "adminId", "impersonatedId", "startedAt", "endedAt", "sessionToken", reason) FROM stdin;
\.


--
-- Data for Name: IncomingWebhook; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."IncomingWebhook" (id, "workflowId", url, secret, enabled, events, "retryPolicy", "totalReceived", "lastReceivedAt", "failureCount", "lastError", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Invoice" (id, "invoiceNumber", "clientId", "billingProfileId", "orderId", status, currency, subtotal, "taxAmount", "discountAmount", "totalAmount", "amountPaid", "amountDue", "dueDate", "issuedAt", "paidAt", "cancelledAt", notes, metadata, "createdAt", "updatedAt", "invoiceType", "paymentTermDays") FROM stdin;
7d7eac3d-e376-452b-89a8-afe60106823c	INV-2026-00001	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	ae271421-57e6-4182-acb2-745b02df72c4	paid	USD	99.99	0.00	0.00	99.99	99.99	0.00	2026-03-16 01:25:09.193	2026-03-09 01:25:09.193	2026-03-09 01:25:09.347	\N	\N	\N	2026-03-09 01:25:09.194	2026-03-09 01:25:09.348	manual	7
aa21c76a-39b3-4c6b-82f8-e357f7bbc5a5	INV-2026-00002	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	f42c3915-d6ad-44a3-8f3a-66caeedf8047	paid	USD	99.99	0.00	0.00	99.99	99.99	0.00	2026-03-16 01:48:41.779	2026-03-09 01:48:41.78	2026-03-09 01:48:42.018	\N	\N	\N	2026-03-09 01:48:41.78	2026-03-09 01:48:42.018	manual	7
ba611e7d-81b3-4f23-a4bd-9d4dbaa31ee2	INV-2026-00003	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	fbdc860d-a39d-478c-87f9-d71f24e9c961	paid	USD	99.99	0.00	0.00	99.99	99.99	0.00	2026-03-23 09:16:58.68	2026-03-16 09:16:58.68	2026-03-16 09:16:59.169	\N	\N	\N	2026-03-16 09:16:58.683	2026-03-16 09:16:59.17	manual	7
3284ae02-6de3-477b-ad9f-15173abacaae	INV-2026-00004	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	3cf9771f-0e03-4a26-a819-77b630bf9ab6	paid	USD	9.99	0.00	0.00	9.99	9.99	0.00	2026-03-25 07:49:29.253	2026-03-18 07:49:29.253	2026-03-18 07:49:29.406	\N	\N	\N	2026-03-18 07:49:29.257	2026-03-18 07:49:29.407	manual	7
95c70590-5409-4b9f-bbc4-5ef6e34a574e	INV-2026-00005	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	09c75743-1c74-418c-a0f4-5af8de1ec39f	paid	USD	9.99	0.00	0.00	9.99	9.99	0.00	2026-03-25 07:58:07.723	2026-03-18 07:58:07.724	2026-03-18 07:58:07.945	\N	\N	\N	2026-03-18 07:58:07.727	2026-03-18 07:58:07.947	manual	7
da549e8b-5400-4957-88a5-e2af1f305667	INV-2026-00007	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	7e7129ed-2dad-42f3-9284-ac4ad73e5239	draft	USD	89.97	15.29	0.00	105.26	0.00	105.26	2026-03-26 14:37:02.341	\N	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "f8450da4-0748-46b6-a5b8-48ca134bdec7", "billingCycles": 3}	2026-03-19 14:37:02.343	2026-03-19 14:37:02.343	manual	7
475add88-71e2-441d-996a-a83b19f3a96f	INV-2026-00008	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	b8c08a3c-4358-49e5-a874-5d1e6cec54a6	paid	USD	29.99	5.10	0.00	35.09	35.09	0.00	2026-03-26 14:37:03.429	2026-03-19 14:37:03.429	2026-03-19 14:37:03.535	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "b2c4197a-08ca-415f-ac6d-ccf0e33c499e", "billingCycles": 1}	2026-03-19 14:37:03.432	2026-03-19 14:37:03.538	manual	7
5a62b490-3efb-4f1a-983f-84376218837d	INV-2026-00009	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	a2e8e9b4-13e8-42b4-a6ea-48f28cb1814e	cancelled	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-26 14:37:03.754	\N	\N	2026-03-19 14:37:03.864	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "92e06ab9-0097-441f-85e1-f6aa07b8b5e4", "billingCycles": 1}	2026-03-19 14:37:03.756	2026-03-19 14:37:03.866	manual	7
64943176-0a43-4b0b-9120-3e4301da124d	INV-2026-00010	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	56b80dcf-458d-48c5-9d9d-d43d0f5baab4	cancelled	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-26 14:37:04.243	\N	\N	2026-03-19 14:37:04.353	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "6a370186-0250-4dbb-afd9-db6754249e32", "billingCycles": 1}	2026-03-19 14:37:04.245	2026-03-19 14:37:04.354	manual	7
3d09f516-5d02-4e14-893b-ca2eaf87f437	INV-2026-00016	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	draft	USD	0.00	0.00	0.00	0.00	0.00	0.00	2026-03-26 14:37:07.427	\N	\N	\N	\N	{"type": "manual"}	2026-03-19 14:37:07.429	2026-03-19 14:37:07.429	manual	7
28e99083-5083-44fa-b5bf-123c5c6f7998	INV-2026-00017	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	draft	USD	20.00	0.00	0.00	20.00	0.00	20.00	2026-03-26 14:37:07.586	\N	\N	\N	\N	{"type": "manual"}	2026-03-19 14:37:07.59	2026-03-19 14:37:07.59	manual	7
ea591fc3-6602-40a5-b23a-f9336c1d9797	INV-2026-00012	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	aba4b8ea-cd1c-41a2-9b5c-14b6b95fe807	cancelled	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-26 14:37:05.972	\N	\N	2026-03-19 14:37:06.087	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "067d83bc-ed3f-4845-9aea-2221b51b782d", "billingCycles": 1}	2026-03-19 14:37:05.976	2026-03-19 14:37:06.088	manual	7
8cdcf0b2-1e58-441a-a0b1-a594dcf6a204	INV-2026-00011	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	99b93118-7aa4-4d2d-8498-0277ddf292ba	unpaid	USD	29.99	5.10	1035.09	0.00	0.00	0.00	2026-03-26 14:37:05.14	2026-03-19 14:37:05.14	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "aad1c2a4-3c60-4160-bb6e-8923e469e9ac", "billingCycles": 1}	2026-03-19 14:37:05.142	2026-03-19 14:37:06.38	manual	7
cbd413f6-ff61-4243-b39c-a03e8db8621a	INV-2026-00013	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	71ef58f4-1d05-4d9c-9096-4ee446ece4b5	unpaid	USD	29.99	5.10	29.99	5.10	0.00	5.10	2026-03-26 14:37:06.621	2026-03-19 14:37:06.621	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "76fd7521-74db-40bf-b97b-94b6b87d2fe9", "billingCycles": 1}	2026-03-19 14:37:06.623	2026-03-19 14:37:06.763	manual	7
546135cb-93bb-41ff-9a07-c27d40714a92	INV-2026-00014	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	draft	USD	112.98	0.00	10.00	102.98	0.00	102.98	2026-04-02 14:37:06.893	\N	\N	\N	First invoice — new client onboarding package	{"type": "manual"}	2026-03-19 14:37:06.896	2026-03-19 14:37:06.896	manual	7
359882e0-d014-4553-b2ee-f3a2ff990ade	INV-2026-00015	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	unpaid	USD	75.00	0.00	0.00	75.00	0.00	75.00	2026-03-26 14:37:07.045	2026-03-19 14:37:07.045	\N	\N	\N	{"type": "manual"}	2026-03-19 14:37:07.047	2026-03-19 14:37:07.047	manual	7
64265f83-a63b-4a7a-bc27-0e7918a16699	INV-2026-00019	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	e89078a5-9c39-4fd5-8130-896208fc7c28	paid	USD	29.99	5.10	0.00	35.09	1035.09	0.00	2026-03-26 14:37:08.988	2026-03-19 14:37:08.988	2026-03-19 14:37:09.124	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "6bfed5d3-6606-4a1d-8e95-5ba40e563096", "billingCycles": 1}	2026-03-19 14:37:08.99	2026-03-19 14:37:09.13	manual	7
ab98101d-bb28-4623-a5f2-77e2eaf72b16	INV-2026-00018	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	d2ff3af1-3e50-4c63-a116-3ad6f74f479f	unpaid	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-26 14:37:08.649	2026-03-19 14:37:08.649	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "06986cf2-e8a1-481c-865e-16cdbae24bc9", "billingCycles": 1}	2026-03-19 14:37:08.652	2026-03-19 14:37:08.652	manual	7
c96ece63-d79f-4843-9d9e-c68f9dfb5e33	INV-2026-00020	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	d19e49e9-8d86-4872-9cbd-b6f900157063	cancelled	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-26 14:37:09.45	\N	\N	2026-03-19 14:37:09.56	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "00a1ee2e-841c-44e4-89aa-e16b94ec6157", "billingCycles": 1}	2026-03-19 14:37:09.452	2026-03-19 14:37:09.562	manual	7
68606940-0cdf-415c-9af9-7a075ccd3c1b	INV-2026-00006	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	b60f50ac-4704-4210-b00a-b1925ad29d28	paid	USD	29.99	5.10	0.00	35.09	17.55	17.54	2026-03-26 14:37:01.992	2026-03-19 14:37:03.116	2026-03-19 14:37:08.201	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "fe83046e-4694-4039-b65b-9762cabcd156", "billingCycles": 1}	2026-03-19 14:37:01.996	2026-03-19 14:37:10.632	manual	7
af7cf402-ed48-46b1-b05f-65a4f2628b65	INV-2026-00021	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	932b70ef-1c86-43ef-960d-2a8f5debc959	paid	USD	29.99	5.10	0.00	35.09	35.09	0.00	2026-03-26 14:37:10.877	2026-03-19 14:37:10.877	2026-03-19 14:37:10.999	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "e047b2a7-4358-4ca2-8710-f8af57e3a2f3", "billingCycles": 1}	2026-03-19 14:37:10.879	2026-03-19 14:37:11.005	manual	7
875733bf-3ad9-4c98-a596-d4e03f34de25	INV-2026-00024	ea27b74d-bb76-4789-b18b-0686c0f07a62	\N	\N	draft	USD	999.00	0.00	0.00	999.00	0.00	999.00	2026-03-26 14:37:16.17	\N	\N	\N	\N	{"type": "manual"}	2026-03-19 14:37:16.172	2026-03-19 14:37:16.172	manual	7
94a32756-6285-447e-aeb5-999593ce2aad	INV-2026-00022	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	90dff4ff-cffb-429c-afcc-f311ec44ad39	paid	USD	29.99	5.10	0.00	35.09	35.09	0.00	2026-03-26 14:37:11.513	2026-03-19 14:37:11.513	2026-03-19 14:37:11.634	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "b53c5a63-7871-4135-b871-4b5a5012afd5", "billingCycles": 1}	2026-03-19 14:37:11.515	2026-03-19 14:37:11.639	manual	7
72338b1d-425f-4d9f-8f03-154a62932aad	INV-2026-00023	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	8a724135-849f-4129-9d48-ba6928dd415b	unpaid	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-22 14:37:12.079	2026-03-19 14:37:12.079	\N	\N	Renewal for order 8a724135-849f-4129-9d48-ba6928dd415b	{"type": "renewal", "cycle": "monthly", "snapshotId": "0d0e6be4-becb-4ad2-b297-03d7650a7b94", "renewalDate": "2026-04-19T14:37:11.947Z"}	2026-03-19 14:37:12.081	2026-03-19 14:37:12.081	manual	7
83e49d15-8f76-46e3-b345-24493cd57e8e	INV-2026-00026	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	28ce0be5-e7ee-43e1-b6ad-9dac45833384	draft	USD	89.97	15.29	0.00	105.26	0.00	105.26	2026-03-27 00:24:25.861	\N	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "76c2971f-7772-4bb4-9a8f-5fb663d32dac", "billingCycles": 3}	2026-03-20 00:24:25.863	2026-03-20 00:24:25.863	manual	7
4f432e9b-0bad-4278-82c7-acc7933af4de	INV-2026-00027	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	092cb080-26d0-4e72-aa29-701159977db6	paid	USD	29.99	5.10	0.00	35.09	35.09	0.00	2026-03-27 00:24:27.046	2026-03-20 00:24:27.046	2026-03-20 00:24:27.157	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "9ecc2f41-229c-4008-b75a-e0b055eb56dc", "billingCycles": 1}	2026-03-20 00:24:27.048	2026-03-20 00:24:27.159	manual	7
e7ac281b-b56d-4458-b220-60c0d5c329f5	INV-2026-00028	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	143d4676-1eff-40c0-b466-af70fd9dc3f6	cancelled	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-27 00:24:27.388	\N	\N	2026-03-20 00:24:27.502	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "60c6dd6a-c935-4707-8652-740b5c87fedb", "billingCycles": 1}	2026-03-20 00:24:27.391	2026-03-20 00:24:27.504	manual	7
3960d200-4ccf-4400-a7e6-916d39c0769a	INV-2026-00029	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	4580e127-eedb-4f64-8aae-9fd890434c63	cancelled	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-27 00:24:27.91	\N	\N	2026-03-20 00:24:28.021	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "5ec62d4d-0d66-413e-b9ff-5f3f7b6c4443", "billingCycles": 1}	2026-03-20 00:24:27.912	2026-03-20 00:24:28.022	manual	7
94e64bdd-0423-48b0-86fa-a696f41b0049	INV-2026-00032	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	c2bb61d9-fe0c-414b-b00a-3a6fad489511	unpaid	USD	29.99	5.10	29.99	5.10	0.00	5.10	2026-03-27 00:24:30.084	2026-03-20 00:24:30.084	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "e98b2736-8e2b-4d58-90d2-2b448f603073", "billingCycles": 1}	2026-03-20 00:24:30.086	2026-03-20 00:24:30.208	manual	7
f88bce64-756d-44d5-abc3-089d1b916905	INV-2026-00033	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	draft	USD	112.98	0.00	10.00	102.98	0.00	102.98	2026-04-03 00:24:30.323	\N	\N	\N	First invoice — new client onboarding package	{"type": "manual"}	2026-03-20 00:24:30.326	2026-03-20 00:24:30.326	manual	7
e70bcf30-2c12-4e13-8d59-0dbfc00e139b	INV-2026-00031	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	f87b2928-0b9f-4776-a1f9-739bf2e30a03	cancelled	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-27 00:24:29.48	\N	\N	2026-03-20 00:24:29.58	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "4ae73a96-2d58-4e64-bb43-1857f86bbba7", "billingCycles": 1}	2026-03-20 00:24:29.482	2026-03-20 00:24:29.581	manual	7
899431c3-8041-441b-ae15-39e65542744b	INV-2026-00030	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	3a720a55-aae6-416b-9029-f7503b344a8e	unpaid	USD	29.99	5.10	1035.09	0.00	0.00	0.00	2026-03-27 00:24:28.75	2026-03-20 00:24:28.75	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "1f63de02-adad-4829-920b-95e7807d9e1a", "billingCycles": 1}	2026-03-20 00:24:28.752	2026-03-20 00:24:29.873	manual	7
40b2fcc5-34d9-49e8-834b-0cb6e2b31f93	INV-2026-00034	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	unpaid	USD	75.00	0.00	0.00	75.00	0.00	75.00	2026-03-27 00:24:30.443	2026-03-20 00:24:30.443	\N	\N	\N	{"type": "manual"}	2026-03-20 00:24:30.445	2026-03-20 00:24:30.445	manual	7
2f83fbea-0c30-45cb-80aa-e930df73862b	INV-2026-00035	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	draft	USD	0.00	0.00	0.00	0.00	0.00	0.00	2026-03-27 00:24:30.8	\N	\N	\N	\N	{"type": "manual"}	2026-03-20 00:24:30.802	2026-03-20 00:24:30.802	manual	7
b99d30be-7038-4c8f-b72f-1afaf1c879d2	INV-2026-00036	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	draft	USD	20.00	0.00	0.00	20.00	0.00	20.00	2026-03-27 00:24:30.962	\N	\N	\N	\N	{"type": "manual"}	2026-03-20 00:24:30.965	2026-03-20 00:24:30.965	manual	7
dc4348e6-0930-4cee-97c1-efc5687de545	INV-2026-00038	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	13471462-3d14-48f2-a01a-bf76219a32bb	paid	USD	29.99	5.10	0.00	35.09	1035.09	0.00	2026-03-27 00:24:32.239	2026-03-20 00:24:32.239	2026-03-20 00:24:32.362	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "760dbcc3-7f77-4e01-84bd-32ecabc132d3", "billingCycles": 1}	2026-03-20 00:24:32.241	2026-03-20 00:24:32.368	manual	7
55e6ed6d-2bd4-4617-88db-44180d9be4ba	INV-2026-00037	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	e3aa0668-c8d8-48b3-bc78-b6c2026f4173	unpaid	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-27 00:24:31.917	2026-03-20 00:24:31.917	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "d70fd980-6fee-4ec3-8e1b-8ccef163283a", "billingCycles": 1}	2026-03-20 00:24:31.919	2026-03-20 00:24:31.919	manual	7
183a006e-5703-421e-a5c2-8d50b2326f94	INV-2026-00039	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	6fd5f1f6-f14a-48b1-aa9f-7322604ea6b6	cancelled	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-27 00:24:32.686	\N	\N	2026-03-20 00:24:32.793	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "6516ec2c-1f11-4985-87d0-5d28d9b8a00d", "billingCycles": 1}	2026-03-20 00:24:32.688	2026-03-20 00:24:32.795	manual	7
5d3eca53-5905-4aba-ac75-abb64ee9a656	INV-2026-00025	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	8a1832c9-cd14-433f-93f8-9a84c6ebd60f	paid	USD	29.99	5.10	0.00	35.09	17.55	17.54	2026-03-27 00:24:25.497	2026-03-20 00:24:26.722	2026-03-20 00:24:31.492	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "6976a5ce-4e4c-46f6-a69e-5faee5d95f3b", "billingCycles": 1}	2026-03-20 00:24:25.5	2026-03-20 00:24:33.841	manual	7
dfa94450-6de6-457c-9328-133668c7c575	INV-2026-00040	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	c2528ec3-d291-47bc-bfff-ecd21564a20d	paid	USD	29.99	5.10	0.00	35.09	35.09	0.00	2026-03-27 00:24:34.072	2026-03-20 00:24:34.072	2026-03-20 00:24:34.193	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "8d0a03fa-9725-4306-ab3b-58b6c61ad680", "billingCycles": 1}	2026-03-20 00:24:34.075	2026-03-20 00:24:34.199	manual	7
3ae54a3c-6ed2-4457-977e-63feed611fd2	INV-2026-00041	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	dc185787-2235-4ca3-b3e5-1e8ad3dfc19c	paid	USD	29.99	5.10	0.00	35.09	35.09	0.00	2026-03-27 00:24:34.734	2026-03-20 00:24:34.734	2026-03-20 00:24:34.859	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "985f5d6d-7788-4a63-9760-86ad0de3c3ef", "billingCycles": 1}	2026-03-20 00:24:34.736	2026-03-20 00:24:34.865	manual	7
efa3e4f5-629c-455d-944c-ca922c361493	INV-2026-00042	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	22afc7fe-81f3-4167-9708-ee7255454d52	unpaid	USD	29.99	5.10	0.00	35.09	0.00	35.09	2026-03-23 00:24:35.303	2026-03-20 00:24:35.303	\N	\N	Renewal for order 22afc7fe-81f3-4167-9708-ee7255454d52	{"type": "renewal", "cycle": "monthly", "snapshotId": "4fac2004-ce95-4ac6-a48e-eddc853b342a", "renewalDate": "2026-04-20T00:24:35.170Z"}	2026-03-20 00:24:35.305	2026-03-20 00:24:35.305	manual	7
33122a09-a1f8-4861-8b08-4aaa7f192347	INV-2026-00043	ea27b74d-bb76-4789-b18b-0686c0f07a62	\N	\N	draft	USD	999.00	0.00	0.00	999.00	0.00	999.00	2026-03-27 00:24:39.427	\N	\N	\N	\N	{"type": "manual"}	2026-03-20 00:24:39.429	2026-03-20 00:24:39.429	manual	7
5c4a5f29-8579-4606-a9ff-04a521f7870e	INV-2026-00045	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	b86471ed-335a-4133-8659-9d066e91a6d5	draft	USD	49.96	15.08	0.00	65.04	0.00	65.04	2026-03-27 00:50:02.499	\N	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "a4373fdc-9158-4736-8c5c-bc9dbc9e56cd", "billingCycles": 1}	2026-03-20 00:50:02.502	2026-03-20 00:50:02.502	manual	7
238d64c7-8443-4236-8565-957098049a93	INV-2026-00046	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	fa23ca2c-a32e-437f-9196-0703fa51874b	draft	USD	99.96	15.29	0.00	115.25	0.00	115.25	2026-03-27 00:50:02.739	\N	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "104ee467-adc3-4cc8-81df-76a9b5918704", "billingCycles": 3}	2026-03-20 00:50:02.742	2026-03-20 00:50:02.742	manual	7
427a9a45-ce0a-4ca0-bcfb-97a18ba4706b	INV-2026-00047	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	91269c8d-ff8c-41cf-b89a-e0f9283ab946	paid	USD	39.98	5.10	0.00	45.08	45.08	0.00	2026-03-27 00:50:03.898	2026-03-20 00:50:03.898	2026-03-20 00:50:04.001	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "380683bb-49df-4bf3-8b63-8cdf048628f3", "billingCycles": 1}	2026-03-20 00:50:03.901	2026-03-20 00:50:04.003	manual	7
1c363685-11c4-4b45-9050-1fbcf1dc2af7	INV-2026-00048	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	1555ddbb-d791-462b-85a8-3276c0a7443e	cancelled	USD	39.98	5.10	0.00	45.08	0.00	45.08	2026-03-27 00:50:04.202	\N	\N	2026-03-20 00:50:04.301	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "7b02ae66-2b55-407d-b450-f8f0753cb32c", "billingCycles": 1}	2026-03-20 00:50:04.204	2026-03-20 00:50:04.303	manual	7
d8b5cd0b-17b3-4e6a-8cc2-48cfa4a3b1e7	INV-2026-00049	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	9c1ae65a-23d3-40ff-b84d-a21131c9de1e	cancelled	USD	39.98	5.10	0.00	45.08	0.00	45.08	2026-03-27 00:50:04.662	\N	\N	2026-03-20 00:50:04.761	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "1e6911ea-d348-432c-8486-1b835eeff84e", "billingCycles": 1}	2026-03-20 00:50:04.664	2026-03-20 00:50:04.762	manual	7
5ddf36d8-fd9d-49ac-a0bb-334f49c9659d	INV-2026-00053	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	draft	USD	112.98	0.00	10.00	102.98	0.00	102.98	2026-04-03 00:50:07.005	\N	\N	\N	First invoice — new client onboarding package	{"type": "manual"}	2026-03-20 00:50:07.008	2026-03-20 00:50:07.008	manual	7
42aae26c-4975-45a1-bdf0-51160122bd1d	INV-2026-00054	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	unpaid	USD	75.00	0.00	0.00	75.00	0.00	75.00	2026-03-27 00:50:07.136	2026-03-20 00:50:07.136	\N	\N	\N	{"type": "manual"}	2026-03-20 00:50:07.138	2026-03-20 00:50:07.138	manual	7
0324dfd3-b75d-4e30-938c-61dfcbe04067	INV-2026-00051	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	2df8ffdd-b5cb-4ef3-a770-72c39c595550	cancelled	USD	39.98	5.10	0.00	45.08	0.00	45.08	2026-03-27 00:50:06.131	\N	\N	2026-03-20 00:50:06.236	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "7b3ff3e4-dc00-4837-a05e-f3a1bd071f62", "billingCycles": 1}	2026-03-20 00:50:06.133	2026-03-20 00:50:06.238	manual	7
a6a0d770-8f7f-4943-9a52-1706bdcdce97	INV-2026-00050	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	b48eb7ad-7f27-469a-bed3-d0da365e3e0d	unpaid	USD	39.98	5.10	1045.08	0.00	0.00	0.00	2026-03-27 00:50:05.394	2026-03-20 00:50:05.394	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "45638f33-aa24-478e-af20-04ef7b572e0a", "billingCycles": 1}	2026-03-20 00:50:05.396	2026-03-20 00:50:06.528	manual	7
3c1aeb34-ed3e-4702-b0c9-086e31452882	INV-2026-00052	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	080227cb-656a-4839-ab3a-801a4a440099	unpaid	USD	39.98	5.10	45.08	0.00	0.00	0.00	2026-03-27 00:50:06.75	2026-03-20 00:50:06.75	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "07c116d0-53eb-4912-a048-4aa5597423c2", "billingCycles": 1}	2026-03-20 00:50:06.752	2026-03-20 00:50:06.881	manual	7
e32241f0-cea3-4b99-8b68-38d7c718bc03	INV-2026-00055	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	\N	draft	USD	20.00	0.00	0.00	20.00	0.00	20.00	2026-03-27 00:50:07.634	\N	\N	\N	\N	{"type": "manual"}	2026-03-20 00:50:07.638	2026-03-20 00:50:07.638	manual	7
4d409608-aaef-4d3e-9e60-f544467fde72	INV-2026-00058	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	3882126b-d1de-4c84-a207-b472e3814679	cancelled	USD	39.98	5.10	0.00	45.08	0.00	45.08	2026-03-27 00:50:09.42	\N	\N	2026-03-20 00:50:09.538	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "3c219ffa-396d-4f80-a7b9-51d070173b62", "billingCycles": 1}	2026-03-20 00:50:09.423	2026-03-20 00:50:09.539	manual	7
979c36ae-3245-48c3-b760-494024f37bdb	INV-2026-00056	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	8b60a549-da88-4c95-a1c0-f2c7a879b2b3	unpaid	USD	39.98	5.10	0.00	45.08	0.00	45.08	2026-03-27 00:50:08.711	2026-03-20 00:50:08.711	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "cc18c14d-2d0f-4040-a9e3-d11e9be3f2d6", "billingCycles": 1}	2026-03-20 00:50:08.713	2026-03-20 00:50:08.713	manual	7
461d2363-a3da-4c20-a4f5-b96623979828	INV-2026-00057	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	0984df4a-eaa8-498c-8da6-31aac591c637	unpaid	USD	39.98	5.10	0.00	45.08	0.00	45.08	2026-03-27 00:50:09.012	2026-03-20 00:50:09.012	\N	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "5fde667a-0d74-41c8-86d7-309fac258a05", "billingCycles": 1}	2026-03-20 00:50:09.014	2026-03-20 00:50:09.014	manual	7
bb84cdef-e070-4482-b547-3cfc06a499eb	INV-2026-00044	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	9b1117d2-33da-4384-a851-b1fc51f418f2	paid	USD	39.98	5.10	0.00	45.08	22.54	22.54	2026-03-27 00:50:02.23	2026-03-20 00:50:03.605	2026-03-20 00:50:08.203	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "1f449313-3640-405a-b849-ad7c978df159", "billingCycles": 1}	2026-03-20 00:50:02.234	2026-03-20 00:50:10.757	manual	7
12371e0c-729c-4c8c-95c6-5b6e9d552438	INV-2026-00059	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	66c91df1-c89d-4ba5-a6fd-5f5e2c2e8a50	paid	USD	39.98	5.10	0.00	45.08	45.08	0.00	2026-03-27 00:50:11.007	2026-03-20 00:50:11.007	2026-03-20 00:50:11.13	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "a44ec8d0-0c71-4b49-b3e8-01540db4cfd8", "billingCycles": 1}	2026-03-20 00:50:11.009	2026-03-20 00:50:11.154	manual	7
3c796640-f5e7-4be4-a252-dc5d270e427e	INV-2026-00060	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	be3b2449-0dcc-40b5-ab8b-a7d477c08680	paid	USD	39.98	5.10	0.00	45.08	45.08	0.00	2026-03-27 00:50:11.693	2026-03-20 00:50:11.693	2026-03-20 00:50:11.803	\N	\N	{"type": "new_order", "cycle": "monthly", "snapshotId": "8c9876d7-b17f-4b4a-b069-f1e039bc885f", "billingCycles": 1}	2026-03-20 00:50:11.695	2026-03-20 00:50:11.827	manual	7
67e44f8d-bd83-4807-bdc3-85da836a7f37	INV-2026-00061	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	d937c100-fc3e-44a6-9ad0-795da003839f	unpaid	USD	24.99	4.25	0.00	29.24	0.00	29.24	2026-03-23 00:50:12.256	2026-03-20 00:50:12.256	\N	\N	Renewal for order d937c100-fc3e-44a6-9ad0-795da003839f	{"type": "renewal", "cycle": "monthly", "snapshotId": "9b790b00-5e7b-45c8-96ed-772c5e93bcfd", "renewalDate": "2026-04-20T00:50:12.128Z"}	2026-03-20 00:50:12.258	2026-03-20 00:50:12.258	manual	7
016012e4-d86f-4b4d-b517-094cee196460	INV-2026-00062	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	d937c100-fc3e-44a6-9ad0-795da003839f	unpaid	USD	5.00	0.00	0.00	5.00	0.00	5.00	2026-03-23 00:50:13.25	2026-03-20 00:50:13.25	\N	\N	Payment overdue — suspension fee applied	{"type": "suspension", "reason": "Payment overdue — suspension fee applied", "snapshotId": "9b790b00-5e7b-45c8-96ed-772c5e93bcfd"}	2026-03-20 00:50:13.252	2026-03-20 00:50:13.252	manual	7
32b2f127-69f8-4de9-959b-8f6c87b1db3b	INV-2026-00063	75be047c-38b6-4cfc-aa3b-3c996c67755d	02089287-8827-4850-872f-d6698992c8b6	d937c100-fc3e-44a6-9ad0-795da003839f	unpaid	USD	15.00	0.00	0.00	15.00	0.00	15.00	2026-03-27 00:50:13.616	2026-03-20 00:50:13.616	\N	\N	Early termination fee	{"type": "termination", "reason": "Early termination fee", "snapshotId": "9b790b00-5e7b-45c8-96ed-772c5e93bcfd"}	2026-03-20 00:50:13.619	2026-03-20 00:50:13.619	manual	7
a466de0f-e5e5-4ab1-860e-373ecc9c35b6	INV-2026-00064	ea27b74d-bb76-4789-b18b-0686c0f07a62	\N	\N	draft	USD	999.00	0.00	0.00	999.00	0.00	999.00	2026-03-27 00:50:16.294	\N	\N	\N	\N	{"type": "manual"}	2026-03-20 00:50:16.296	2026-03-20 00:50:16.296	manual	7
\.


--
-- Data for Name: InvoiceDiscount; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."InvoiceDiscount" (id, "invoiceId", type, code, description, amount, "isPercent", "appliedAt") FROM stdin;
aa4692b5-b40b-4e59-aad7-2f80ee9316a2	8cdcf0b2-1e58-441a-a0b1-a594dcf6a204	manual	\N	Loyalty discount	5.00	f	2026-03-19 14:37:05.371
9b1385ed-b711-4c86-a164-33c6793cdfea	8cdcf0b2-1e58-441a-a0b1-a594dcf6a204	promo	WELCOME10	10% welcome discount	3.00	t	2026-03-19 14:37:05.527
95bb0bc0-9d06-4b12-9421-3cb811868fe6	8cdcf0b2-1e58-441a-a0b1-a594dcf6a204	credit	\N	\N	1027.09	f	2026-03-19 14:37:06.355
e7f2554b-7a98-481a-a087-72bb43627f2a	cbd413f6-ff61-4243-b39c-a03e8db8621a	promo	\N	\N	29.99	t	2026-03-19 14:37:06.738
45765195-d0cd-4c9f-9a8b-8b264d03a894	546135cb-93bb-41ff-9a07-c27d40714a92	manual	\N	New client discount	10.00	f	2026-03-19 14:37:06.896
67770fea-b871-44c5-a554-7b263450796e	899431c3-8041-441b-ae15-39e65542744b	manual	\N	Loyalty discount	5.00	f	2026-03-20 00:24:28.952
1f617d44-9ba3-4d34-adcd-c628584550df	899431c3-8041-441b-ae15-39e65542744b	promo	WELCOME10	10% welcome discount	3.00	t	2026-03-20 00:24:29.085
d4afce1e-cdc0-4649-bd49-dc2c0a82a61d	899431c3-8041-441b-ae15-39e65542744b	credit	\N	\N	1027.09	f	2026-03-20 00:24:29.85
8cb453ac-bc07-4ff9-bbde-ef7822b33409	94e64bdd-0423-48b0-86fa-a696f41b0049	promo	\N	\N	29.99	t	2026-03-20 00:24:30.185
d103b21f-3ccf-456c-8b3b-d33da6c5f296	f88bce64-756d-44d5-abc3-089d1b916905	manual	\N	New client discount	10.00	f	2026-03-20 00:24:30.326
9327457d-9f00-4e5f-b44d-a3087dcf42ee	a6a0d770-8f7f-4943-9a52-1706bdcdce97	manual	\N	Loyalty discount	5.00	f	2026-03-20 00:50:05.591
14ddd29b-3bde-419e-ba17-0de95a040763	a6a0d770-8f7f-4943-9a52-1706bdcdce97	promo	WELCOME10	10% welcome discount	4.51	t	2026-03-20 00:50:05.726
532fabae-0671-4ded-8e2a-4204f86c022b	a6a0d770-8f7f-4943-9a52-1706bdcdce97	credit	\N	\N	1035.57	f	2026-03-20 00:50:06.505
dcba86bc-899b-48dd-a8d3-f5975ac416e9	3c1aeb34-ed3e-4702-b0c9-086e31452882	promo	\N	\N	45.08	t	2026-03-20 00:50:06.856
ec8307ff-2214-4933-9ca5-98bb281c64ab	5ddf36d8-fd9d-49ac-a0bb-334f49c9659d	manual	\N	New client discount	10.00	f	2026-03-20 00:50:07.008
\.


--
-- Data for Name: InvoiceLineItem; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."InvoiceLineItem" (id, "invoiceId", description, quantity, "unitPrice", total, "taxRate", "taxAmount", "serviceCode", "planName", cycle, "createdAt", "snapshotId") FROM stdin;
2c378600-d675-4e3f-9ea1-5d01792289e2	7d7eac3d-e376-452b-89a8-afe60106823c	Test Hosting Service — Test Plan - 1773019508739 (monthly)	1	99.99	99.99	\N	0.00	test-hosting-1773019508695	Test Plan - 1773019508739	monthly	2026-03-09 01:25:09.194	\N
8cd2acee-2aef-49ec-97dd-3a33bf6a05dd	aa21c76a-39b3-4c6b-82f8-e357f7bbc5a5	Test Service — Test Plan (monthly)	1	99.99	99.99	\N	0.00	test-service-1773020921378	Test Plan	monthly	2026-03-09 01:48:41.78	\N
a48cb9bb-bbfb-4079-a26c-a3aba4b56f5b	ba611e7d-81b3-4f23-a4bd-9d4dbaa31ee2	Test Service — Test Plan (monthly)	1	99.99	99.99	\N	0.00	test-service-1773652617711	Test Plan	monthly	2026-03-16 09:16:58.683	\N
21fd6fce-e0ad-4108-8f56-85f12a9777b4	3284ae02-6de3-477b-ad9f-15173abacaae	Test Web Hosting Service — Starter Plan (monthly)	1	9.99	9.99	\N	0.00	test-hosting-1773820166653	Starter Plan	monthly	2026-03-18 07:49:29.257	\N
14c4dab5-b5ee-4c7f-af69-eed67be50c81	95c70590-5409-4b9f-bbc4-5ef6e34a574e	Test Web Hosting Service — Starter Plan (monthly)	1	9.99	9.99	\N	0.00	test-hosting-1773820685298	Starter Plan	monthly	2026-03-18 07:58:07.727	\N
a20087b6-a51b-43c9-a801-3b32f629e02c	68606940-0cdf-415c-9af9-7a075ccd3c1b	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:01.996	\N
7c404b5d-8869-44fc-94bb-91818b514f9c	da549e8b-5400-4957-88a5-e2af1f305667	Billing Test Hosting — Pro Plan (Monthly) × 3	3	29.99	89.97	0.1700	15.29	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:02.343	\N
805692cb-be68-4ce2-bb57-f732928f67a5	475add88-71e2-441d-996a-a83b19f3a96f	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:03.432	\N
76be7fa8-aeb9-4d81-9f60-5d8a94731a9b	5a62b490-3efb-4f1a-983f-84376218837d	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:03.756	\N
e7a2f7ea-a0ab-45a9-a320-970fd1dc2de8	64943176-0a43-4b0b-9120-3e4301da124d	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:04.245	\N
b4e40cf5-af7d-49b1-88e6-1b88ba0d4d71	8cdcf0b2-1e58-441a-a0b1-a594dcf6a204	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:05.142	\N
d7bdf593-0fdf-41a3-8658-20a5d9a15dde	ea591fc3-6602-40a5-b23a-f9336c1d9797	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:05.976	\N
f4d191bf-e92d-42b8-856a-5ac3528af687	cbd413f6-ff61-4243-b39c-a03e8db8621a	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:06.623	\N
8ead37f7-b228-41d2-a240-6a77a788c680	546135cb-93bb-41ff-9a07-c27d40714a92	Domain registration - example.com	1	12.99	12.99	\N	\N	\N	\N	\N	2026-03-19 14:37:06.896	\N
4b196bc1-5740-4078-b481-a60341af1a31	546135cb-93bb-41ff-9a07-c27d40714a92	SSL Certificate - 1 year	1	49.99	49.99	\N	\N	\N	\N	\N	2026-03-19 14:37:06.896	\N
ce815505-8ff1-4bcd-9432-eed8835902ea	546135cb-93bb-41ff-9a07-c27d40714a92	Migration service	2	25.00	50.00	\N	\N	\N	\N	\N	2026-03-19 14:37:06.896	\N
450f4e01-1bb8-4e82-b193-63c69bc6f176	359882e0-d014-4553-b2ee-f3a2ff990ade	Consultation fee	1	75.00	75.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.047	\N
fbdf217e-75b2-435b-8b2d-a5c953eb3e39	3d09f516-5d02-4e14-893b-ca2eaf87f437	Free item	1	0.00	0.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.429	\N
5c393fa3-3468-46b4-a888-156e28f6a92f	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 1	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
97d2918b-8fc4-43fd-8ae4-afc3c24138f6	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 2	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
11d405f6-cb10-4580-86f3-314bd45209fe	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 3	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
c08d8e36-bbbb-4815-9e00-dd6ca3006e48	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 4	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
2f054a44-e07a-4df1-a782-ddb9f4507852	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 5	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
5f30ec25-01f4-4d10-8b81-43f467b963e6	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 6	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
4b4231a1-fba8-43e0-9094-0ab7535b03e5	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 7	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
aee9b787-591b-4f3c-ad34-b9a9bee21a0f	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 8	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
15f1955a-b261-4540-831a-a17b251d9d7c	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 9	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
9138dc11-c23e-40e8-8894-23337bac0ec2	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 10	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
17968dad-2e60-410a-afab-47021862ed0f	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 11	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
ba409fa4-a5e9-4258-a39f-e37e60fc4a81	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 12	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
a68d8388-ed18-4314-abd9-decc8f5dcdae	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 13	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
594ca9c9-f4a9-425d-a292-27f23dbeafa0	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 14	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
9bdfdeb2-996d-409c-80c3-13418e3b8776	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 15	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
81531556-68c0-42c7-a185-22d078d73027	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 16	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
fa7db543-15bf-47b7-a3b7-69b035f2157c	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 17	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
01127219-1377-4aa7-9209-6cb14160ddfe	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 18	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
bca58ffe-2530-49c0-838d-84931ca07c1a	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 19	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
660541d8-d1a4-43e5-ae57-7df28938c6ab	28e99083-5083-44fa-b5bf-123c5c6f7998	Service item 20	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-19 14:37:07.59	\N
6d98d892-e689-43c0-ae43-0845e20d4c7f	ab98101d-bb28-4623-a5f2-77e2eaf72b16	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:08.652	\N
08ed9d52-06b9-4267-9a9b-1b08bc38f1a9	64265f83-a63b-4a7a-bc27-0e7918a16699	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:08.99	\N
3627b636-11d3-4783-b42a-5ed766053c08	c96ece63-d79f-4843-9d9e-c68f9dfb5e33	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:09.452	\N
8d46ab52-27ef-4448-b6d2-9abf3b769053	af7cf402-ed48-46b1-b05f-65a4f2628b65	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:10.879	\N
5f312566-7aa7-4dea-9050-991da85bc34c	875733bf-3ad9-4c98-a596-d4e03f34de25	Admin-only invoice	1	999.00	999.00	\N	\N	\N	\N	\N	2026-03-19 14:37:16.172	\N
3ff863b1-25af-4a2a-b5a9-56d6ce6db28e	94a32756-6285-447e-aeb5-999593ce2aad	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:11.515	\N
50eab1de-6739-47bc-9b06-f076a5c4eedc	72338b1d-425f-4d9f-8f03-154a62932aad	Billing Test Hosting — Pro Plan Renewal (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773931017931	Pro Plan	monthly	2026-03-19 14:37:12.081	\N
d27ce14a-41b9-418e-bba3-3752f8b31bd4	5d3eca53-5905-4aba-ac75-abb64ee9a656	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:25.5	\N
0a99433f-fcd2-4bae-911b-8eceeee676fa	83e49d15-8f76-46e3-b345-24493cd57e8e	Billing Test Hosting — Pro Plan (Monthly) × 3	3	29.99	89.97	0.1700	15.29	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:25.863	\N
3908bb1b-1518-4aa5-867f-a8c1fd76473a	4f432e9b-0bad-4278-82c7-acc7933af4de	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:27.048	\N
163edb80-f34f-4b95-a75d-0b7ebea26e2d	e7ac281b-b56d-4458-b220-60c0d5c329f5	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:27.391	\N
cf03658b-4de9-4044-b2a5-0a499fc0f267	3960d200-4ccf-4400-a7e6-916d39c0769a	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:27.912	\N
13d99af9-357e-4d61-b386-aa686ae8a12a	899431c3-8041-441b-ae15-39e65542744b	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:28.752	\N
5a2cabd6-8095-4dc0-938f-5cae6ef94a92	e70bcf30-2c12-4e13-8d59-0dbfc00e139b	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:29.482	\N
4d431abf-f90e-48eb-935f-5b78a2d91e1f	94e64bdd-0423-48b0-86fa-a696f41b0049	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:30.086	\N
5d411bf0-fd79-4bd5-8235-07bbf15345a1	f88bce64-756d-44d5-abc3-089d1b916905	Domain registration - example.com	1	12.99	12.99	\N	\N	\N	\N	\N	2026-03-20 00:24:30.326	\N
9188d589-9205-4867-8ab8-55b972cca3b4	f88bce64-756d-44d5-abc3-089d1b916905	SSL Certificate - 1 year	1	49.99	49.99	\N	\N	\N	\N	\N	2026-03-20 00:24:30.326	\N
8df61e43-386f-4fea-a7ad-f6782b55026e	f88bce64-756d-44d5-abc3-089d1b916905	Migration service	2	25.00	50.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.326	\N
8e21e891-f71a-4830-a091-919ad87c713a	40b2fcc5-34d9-49e8-834b-0cb6e2b31f93	Consultation fee	1	75.00	75.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.445	\N
c0b2acf3-9d7a-46b3-858b-2a3a437282db	2f83fbea-0c30-45cb-80aa-e930df73862b	Free item	1	0.00	0.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.802	\N
c01bac77-9882-4ca0-971f-45ac26793536	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 1	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
0750dbef-13f6-4ea1-9cd9-9c94a2eb05a4	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 2	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
d73d22b0-88ad-47fe-b542-3492a93badde	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 3	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
c12cb4ae-9051-4a79-9ee5-a17177fff6b2	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 4	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
f1729545-9d76-4f70-8957-8cd75ec3629e	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 5	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
bc640021-b38e-416a-b902-e690c33a41ed	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 6	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
2798896d-a4a3-4ccc-afae-7de30908035f	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 7	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
026d988b-d9e3-4362-b42e-720f75e18147	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 8	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
927fb24c-69e6-431a-9c41-87c12c9720c9	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 9	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
695d7b94-6479-4e17-b7c0-499ed37c95d9	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 10	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
770551ee-6ca1-4316-890b-d63dc54b496a	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 11	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
96ae830d-d0d1-4306-bcfd-25e6e6a4b95a	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 12	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
1a871794-1cbc-47cc-bd09-76d0d5a9937b	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 13	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
89998df1-7aa2-447e-9a31-6f3ae2f7fd4e	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 14	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
3997f24c-ea7a-42a4-b806-7d060ce6f1fb	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 15	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
341cbae0-a21f-42d7-86ae-0e4be6fd3d90	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 16	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
c723d3a8-7d9d-473c-9cc1-dc5354fce761	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 17	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
671edd66-ba5e-47d2-92e8-547f32d3d5f7	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 18	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
656a8641-6f9a-4283-b615-77e45dded678	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 19	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
6842f287-7b02-4763-bd24-d8fd0ac04b9f	b99d30be-7038-4c8f-b72f-1afaf1c879d2	Service item 20	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:24:30.965	\N
2d7ad010-027a-4d94-8674-8781204b3f98	55e6ed6d-2bd4-4617-88db-44180d9be4ba	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:31.919	\N
aa8de94b-f446-4cac-aef0-e2fa3a244996	dc4348e6-0930-4cee-97c1-efc5687de545	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:32.241	\N
46a73581-3ed7-422f-bd68-fe714492e444	183a006e-5703-421e-a5c2-8d50b2326f94	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:32.688	\N
e0a4de3d-13fd-44ad-9e96-d574a695cd19	dfa94450-6de6-457c-9328-133668c7c575	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:34.075	\N
9b7b6e1f-2224-4fca-91c4-673354cd1791	3ae54a3c-6ed2-4457-977e-63feed611fd2	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:34.736	\N
dafd70c9-b41b-426f-b67b-032ce6d16dc8	efa3e4f5-629c-455d-944c-ca922c361493	Billing Test Hosting — Pro Plan Renewal (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773966261634	Pro Plan	monthly	2026-03-20 00:24:35.305	\N
6054011e-b180-488f-852d-db495255f084	33122a09-a1f8-4861-8b08-4aaa7f192347	Admin-only invoice	1	999.00	999.00	\N	\N	\N	\N	\N	2026-03-20 00:24:39.429	\N
390c3fb3-7054-4184-b1f7-83ffffeeb9e5	bb84cdef-e070-4482-b547-3cfc06a499eb	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:02.234	\N
d79af258-78a3-404b-8ddc-38d8be1da59f	bb84cdef-e070-4482-b547-3cfc06a499eb	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:02.234	\N
9684c269-03ef-443d-923c-33969b3d1a53	5c4a5f29-8579-4606-a9ff-04a521f7870e	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:02.502	\N
b01d74ed-eaa0-4183-8164-6c1e6735fce3	5c4a5f29-8579-4606-a9ff-04a521f7870e	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:02.502	\N
6bf695a8-a644-4953-8da0-102504aa1a3a	5c4a5f29-8579-4606-a9ff-04a521f7870e	Add-on: Extra Backup (Monthly)	2	4.99	9.98	1.0000	9.98	BACKUP-1773967799791	\N	monthly	2026-03-20 00:50:02.502	\N
1b7e4e87-5eea-448f-a482-c26f04fd0d96	238d64c7-8443-4236-8565-957098049a93	Billing Test Hosting — Pro Plan (Monthly) × 3	3	29.99	89.97	0.1700	15.29	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:02.742	\N
7b0fb6ac-ee6a-4b4a-b3b4-ec569e0f369b	238d64c7-8443-4236-8565-957098049a93	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:02.742	\N
4471e3f4-16e4-4363-aebc-2a1caf3364f0	427a9a45-ce0a-4ca0-bcfb-97a18ba4706b	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:03.901	\N
0a54f5c8-8138-4acb-ab84-3af9a7e554fc	427a9a45-ce0a-4ca0-bcfb-97a18ba4706b	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:03.901	\N
8308ca81-5109-4c59-b71c-35aefb75d502	1c363685-11c4-4b45-9050-1fbcf1dc2af7	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:04.204	\N
0cbdc25d-bfa0-4945-982a-d49b349376f8	1c363685-11c4-4b45-9050-1fbcf1dc2af7	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:04.204	\N
c8f174cc-7816-453a-8acb-dba8ad0c9f11	d8b5cd0b-17b3-4e6a-8cc2-48cfa4a3b1e7	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:04.664	\N
c8bc2af2-3ebb-4ffd-b58e-61e93875529c	d8b5cd0b-17b3-4e6a-8cc2-48cfa4a3b1e7	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:04.664	\N
72d4280a-0b1d-426b-801b-98dde9004e36	a6a0d770-8f7f-4943-9a52-1706bdcdce97	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:05.396	\N
d79ddee6-28dc-4c39-a6a2-e34bcc50c786	a6a0d770-8f7f-4943-9a52-1706bdcdce97	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:05.396	\N
0a5f0538-f930-42fc-8632-f12216e8db0d	0324dfd3-b75d-4e30-938c-61dfcbe04067	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:06.133	\N
130a72d7-3860-45da-b6be-a8b2a8cf2c74	0324dfd3-b75d-4e30-938c-61dfcbe04067	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:06.133	\N
d01f67f9-f167-451e-8f10-7990a535ba88	3c1aeb34-ed3e-4702-b0c9-086e31452882	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:06.752	\N
9e9e527a-93bd-4385-b80b-2c1c58eeafb2	3c1aeb34-ed3e-4702-b0c9-086e31452882	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:06.752	\N
bdd624b9-4352-4048-b91f-1423918176f4	5ddf36d8-fd9d-49ac-a0bb-334f49c9659d	Domain registration - example.com	1	12.99	12.99	\N	\N	\N	\N	\N	2026-03-20 00:50:07.008	\N
3e3d6487-db8c-4124-a99c-e0861afafbfc	5ddf36d8-fd9d-49ac-a0bb-334f49c9659d	SSL Certificate - 1 year	1	49.99	49.99	\N	\N	\N	\N	\N	2026-03-20 00:50:07.008	\N
97728f2e-71df-4dab-849e-3256054fb3b2	5ddf36d8-fd9d-49ac-a0bb-334f49c9659d	Migration service	2	25.00	50.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.008	\N
d5db85aa-bd7c-4229-a7f6-5fb30a33430a	42aae26c-4975-45a1-bdf0-51160122bd1d	Consultation fee	1	75.00	75.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.138	\N
874fff13-d717-4a64-9784-1d26c170fa9e	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 1	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
c8e7876d-472b-413a-a4af-4c8959b994ba	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 2	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
7e977443-3b8d-49da-a871-6edbc554ea9b	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 3	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
d11eb565-b970-4af0-9102-94005e647bbc	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 4	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
0f118acc-8d08-46c6-8b14-8d761c25c71f	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 5	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
8b636ddf-f2db-4c6f-a1fe-b97255ad316d	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 6	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
ecc3d52f-1ff4-4420-afda-a42e93b9193d	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 7	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
6f43d701-157f-49dc-839b-a6a1fcaa4fa3	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 8	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
df3ebdc4-fa0a-4e2a-b08b-3f2ba53d231d	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 9	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
d21dbee9-294b-4e30-a668-9cc8b0705068	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 10	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
346adb0d-1131-4d02-968d-8d4e7113d792	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 11	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
9c257d02-4728-4dcb-a3d2-10bb2376769a	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 12	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
8649d56a-25d5-4770-964c-f11e6bc4a524	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 13	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
774f59d8-296c-4150-b215-86606f8be810	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 14	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
1212ef39-c68b-46ee-9c82-233d19ebde70	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 15	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
0629c7ea-5da2-4af9-855d-9dd99a436a61	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 16	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
bc35e7cd-1f8f-45fb-8f5a-cddae3643084	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 17	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
26f9160c-80e5-4d43-8e08-2df9cb875aa9	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 18	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
726e041d-129f-4d98-93a1-839f9ad83c1d	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 19	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
fd06a51d-c0da-444c-b456-1bdafbb6b559	e32241f0-cea3-4b99-8b68-38d7c718bc03	Service item 20	1	1.00	1.00	\N	\N	\N	\N	\N	2026-03-20 00:50:07.638	\N
bd2d168e-7133-418a-a0f2-743cf29c606b	979c36ae-3245-48c3-b760-494024f37bdb	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:08.713	\N
35c55d6c-9ec5-4209-ad92-253d3b1372b2	979c36ae-3245-48c3-b760-494024f37bdb	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:08.713	\N
8f5ea4da-0545-4334-81eb-97a67a372cea	461d2363-a3da-4c20-a4f5-b96623979828	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:09.014	\N
ae1d8007-adcc-4c68-8903-d5d78d5c507b	461d2363-a3da-4c20-a4f5-b96623979828	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:09.014	\N
3ac71f19-3d57-4a00-8f6f-6e196de4ff16	4d409608-aaef-4d3e-9e60-f544467fde72	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:09.423	\N
9aff3ab9-32a1-43d5-b656-0e91eda42633	4d409608-aaef-4d3e-9e60-f544467fde72	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:09.423	\N
1577126a-6dbe-407f-9acb-80f27740ec82	12371e0c-729c-4c8c-95c6-5b6e9d552438	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:11.009	\N
8b243d0f-b225-45d6-b8d3-058537516bee	12371e0c-729c-4c8c-95c6-5b6e9d552438	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:11.009	\N
728feb2b-5865-4c34-9b72-f40abd61533f	3c796640-f5e7-4be4-a252-dc5d270e427e	Billing Test Hosting — Pro Plan (Monthly)	1	29.99	29.99	0.1700	5.10	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:11.695	\N
24f8e134-2033-4595-bbe9-1be116c85bf7	3c796640-f5e7-4be4-a252-dc5d270e427e	Setup Fee — Billing Test Hosting (Pro Plan)	1	9.99	9.99	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:11.695	\N
f02c1dcd-a776-4fe7-a794-b98528af46fd	67e44f8d-bd83-4807-bdc3-85da836a7f37	Billing Test Hosting — Pro Plan Renewal (Monthly)	1	24.99	24.99	0.1700	4.25	BILLTEST-1773967798063	Pro Plan	monthly	2026-03-20 00:50:12.258	\N
f1558d4f-a244-496d-ba15-f7fe6866ec13	016012e4-d86f-4b4d-b517-094cee196460	Service Suspension Fee — Billing Test Hosting (Pro Plan): Payment overdue — suspension fee applied	1	5.00	5.00	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:13.252	\N
f62bf2d5-388f-4cad-b2b0-81f07fdf0390	32b2f127-69f8-4de9-959b-8f6c87b1db3b	Service Termination Fee — Billing Test Hosting (Pro Plan): Early termination fee	1	15.00	15.00	\N	\N	BILLTEST-1773967798063	Pro Plan	\N	2026-03-20 00:50:13.619	\N
fb63039e-b4e7-438c-b0ad-6cc4926415dd	a466de0f-e5e5-4ab1-860e-373ecc9c35b6	Admin-only invoice	1	999.00	999.00	\N	\N	\N	\N	\N	2026-03-20 00:50:16.296	\N
\.


--
-- Data for Name: IpAccessRule; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."IpAccessRule" (id, pattern, type, description, active, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: LoginLog; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."LoginLog" (id, "userId", "userEmail", success, ip, "userAgent", reason, "createdAt") FROM stdin;
be1cf91a-aee6-4f10-bfed-a4e31924267b	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-09 00:05:50.725
05b51a70-dc16-4dce-ac4b-091331638a90	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-09 00:07:33.984
d2d21937-9222-4f6d-8489-ebe4416041f5	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	\N	login_success	2026-03-09 01:16:51.006
e545058c-7bf5-451d-bb6c-f1b188ff09e4	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	\N	login_success	2026-03-09 01:16:51.299
c25beffe-3eb2-4860-bc45-606c083c4d21	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	TestSuite/1.0	login_success	2026-03-09 01:25:08.368
5238cc97-16a3-42cf-bcd6-cbeec65052cd	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	TestSuite/1.0	login_success	2026-03-09 01:25:08.653
98a72f36-5140-4224-b553-7c51e55c5035	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	TestSuite/2.0	login_success	2026-03-09 01:48:40.769
01b8555e-a4bd-4ce3-8d35-5c55976d81d9	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	TestSuite/2.0	login_success	2026-03-09 01:48:41.05
1fd639f7-96ba-4f35-b295-70a0dd5464df	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	TestSuite/2.0	invalid_password	2026-03-09 01:48:41.316
78366987-0335-4df9-9697-7a7b4d1eb284	\N	nonexistent@example.com	f	::ffff:127.0.0.1	TestSuite/2.0	user_not_found	2026-03-09 01:48:41.346
fed386ef-f825-475f-915a-40eac0063deb	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	TestSuite/2.0	login_success	2026-03-16 09:16:56.732
e9ceb607-569d-4925-8be6-d658bdacb96d	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	TestSuite/2.0	login_success	2026-03-16 09:16:57.201
39384b0f-a43f-413b-83f3-3bd8ecbd2187	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	TestSuite/2.0	invalid_password	2026-03-16 09:16:57.62
c589b1e9-d6f7-4b33-8054-fa8c00f77435	\N	nonexistent@example.com	f	::ffff:127.0.0.1	TestSuite/2.0	user_not_found	2026-03-16 09:16:57.654
eca54142-e66c-4df8-9a37-4f05295c8baf	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-17 06:43:28.284
c7437a5f-1311-401c-8d5a-f604de032a3c	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-17 07:45:37.339
efcc1977-e2fc-4398-b7e7-ee3b62282532	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-17 07:49:47.494
86aa4347-82e0-425f-908e-929f0dfaff41	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-17 07:50:00.045
5a895d61-b414-437a-b67a-0611d58cade0	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-17 08:05:52.152
eda0b563-5516-4eb2-92b2-9d857dcf5caa	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-17 08:06:54.53
09bad903-e8fb-4e66-aca5-78967430d72f	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-17 08:26:09.804
34b1c6bd-fdf3-43c8-a092-4cb9aa09c9cd	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	TestSuite/3.0	login_success	2026-03-18 07:49:26.138
4dc633c0-142d-4239-8410-1764b7b66b60	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	TestSuite/3.0	login_success	2026-03-18 07:49:26.608
15c59d7f-9cc0-418d-95ce-d7bcaf34d185	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	TestSuite/4.0	login_success	2026-03-18 07:58:04.704
c957d195-fef9-4217-850f-29a13176e080	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	TestSuite/4.0	login_success	2026-03-18 07:58:05.253
f845aefb-9eef-42f3-89a7-b17982262e8d	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-19 04:55:10.72
3b2bba9e-c70f-4470-978e-c01339d1722a	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-19 04:56:28.376
8714f649-17c0-49e3-a9fd-31b89201fb96	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 05:57:02.523
3ccbd628-1530-44c6-ae23-51f99bf2c1b8	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 05:57:02.83
287b549e-00b8-4580-a3d3-59909a5de1cc	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 05:57:03.099
18a8cac3-36c2-4841-a4f2-c7a103be6931	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 05:57:03.132
b3b3b872-d3a0-456a-8a31-c4be76378c28	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-19 05:59:15.448
ab1e8486-c993-4667-abed-e570bfa41afb	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:01:46.425
c3b7c28d-9d8b-4a2a-b7f6-f77731b7b14f	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:01:46.742
18452217-f6e8-4ce6-9f90-7751025be7ff	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 06:01:47.028
decafed0-7f1a-429d-a94f-77a9158200cd	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 06:01:47.059
68462776-6488-45a8-9aca-646ce55da7f0	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:09:57.344
b3df58a4-4c94-4f21-95c0-0d2a4f3afbc0	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:09:57.682
b1393340-7aa7-4473-87df-445ad1a0eef2	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 06:09:57.956
ba472428-01b4-4660-a7e1-7c4d58c6b652	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 06:09:57.987
f59c9589-2906-44a0-a110-1b36a75035f1	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:11:23.872
4805f354-b9fe-4f3e-9fb9-13333e2efd7d	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:11:24.183
65da61b6-ac7a-4cfd-a627-4f4aa7b4ab99	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 06:11:24.5
1efb4386-a408-4488-ba84-94921b572d0b	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 06:11:24.531
b3cbaa7e-acc7-4b05-8c46-d51de254ab81	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::1	curl/8.5.0	invalid_password	2026-03-19 06:15:27.577
035ce3f4-c06f-489e-b7bc-fee426647e0b	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::1	curl/8.5.0	invalid_password	2026-03-19 06:15:35.781
a71151a8-9ba9-492c-aec8-a0fdc3fc5e6f	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:15:43.037
aa50290a-17e7-4599-ab7a-a499e906a431	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:15:43.335
43d6c7e3-9981-4153-893b-063e2c8164ad	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 06:15:43.597
b3727430-880e-4f93-8bd4-d7071978ed59	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:17:19.636
b05dd9a6-285d-44cc-aa2e-1d386fa32b51	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:18:12.296
d68b279f-ac3b-4eec-a425-199b35fd2d08	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:30:13.727
7f4175d3-b033-44b8-852f-ca09b312f3e2	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:30:27.127
e9e65cb1-36ea-4a6e-8ffe-3e801d802480	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:33:25.051
07a87369-5cca-4409-9c06-82259d70644a	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:33:25.547
a623291e-d9e8-4f57-9318-8e6b41ab3031	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 06:33:25.826
3b4c6f3e-b843-46f7-8cd0-7f35fe41ba46	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 06:33:25.857
c4348739-f6ed-453d-a049-7c690f39ed7a	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:34:29.611
efe6275a-d6be-42f5-82b5-308ef8ed6b10	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:34:44.605
36579046-20ce-4ab6-b794-e51a018754bc	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:35:34.696
cf20b213-c146-45a0-8266-7132da9cd047	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-19 06:39:04.481
d6d44fa1-e6b1-4511-89d4-584584496df9	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:39:56.113
a177d137-3dc3-40e2-8642-c249195a5eb7	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:40:07.647
cd7b1d7c-8b00-469f-8332-7051801ba59d	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:41:03.211
ff3713cc-1630-4497-9bea-15bf6a3985a8	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:41:59.871
25d02092-3ab7-42c2-a624-3de1520ae631	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:42:08.096
c5911716-f023-4ee5-9e27-428b0e785ccc	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:42:08.408
68ee37b3-15b9-4fa7-a9a8-bd26c168ce36	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 06:42:08.68
cd86f5cc-5d9b-4e15-9da1-4ab952752541	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 06:42:08.711
a7f11e3b-3a49-410a-8379-ee16dfddd817	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-19 06:49:28.436
2ffca544-f270-4fd1-826f-e4d4e4db3787	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:52:57.535
d542d612-1021-47a3-b7e4-459c29e23380	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:52:57.854
c6b56fd8-d5fa-4e6e-80c9-4f9bf9b39ecd	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 06:52:58.146
78a12b75-96be-4b2a-a376-8c71d868a681	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 06:52:58.177
3674f7df-05d0-4866-bd8d-e92fe4c8889e	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:54:57.708
8034086a-03b3-4367-9477-ca8fde19339e	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:55:37.156
cd7ddd84-5e9a-4f6a-8f59-c4f47ff331dc	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:55:37.44
81c25558-a7f8-424f-bcc0-768b3644c4e4	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 06:55:37.702
29f27dec-493b-4e51-b607-6436515ca167	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 06:55:37.733
0ff84127-d6dc-46a3-bfc6-33f2cd16505b	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:55:57.971
988f359b-c9b2-4459-8051-a9e115f5904d	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 06:55:58.326
1aa74301-eb45-4689-99c2-0bd4c750910d	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 06:55:58.584
986ebd28-8cc2-4b6c-9b22-850cade09e79	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 06:55:58.615
3ef0aae3-3ed2-4b23-94f9-47b5d134ea89	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-19 06:57:26.267
e5fc0d3f-e69e-41f8-ab3e-6e549ad9f859	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:58:48.031
75dcc4a4-d99b-4649-b2b1-0c2c077ab4e7	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	curl/8.5.0	login_success	2026-03-19 06:58:48.402
92964e7e-2b62-4081-8560-b9449218814e	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 07:00:21.592
a31b0037-5072-426f-a7f5-752415cdffef	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	curl/8.5.0	login_success	2026-03-19 07:00:21.899
d2925574-47f3-4594-94ba-d2c6a1eae47f	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 07:07:11.509
c58e2e85-04dc-4000-b974-b2b43ab20847	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 07:07:11.824
cc580a36-ee58-456c-811c-63bfccd69969	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 07:07:12.129
90dda22e-d5f1-42ba-9fdb-6a08ea45f37d	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 07:07:12.161
2a3ee52d-205a-49a9-bf35-59a71b434200	\N	admin@example.com	f	::1	curl/8.5.0	user_not_found	2026-03-19 07:08:17.326
c86c49fe-2477-4e7a-8523-5005cf2ed6c2	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-03-19 07:09:33.907
a7ee2774-b8b4-4722-93b8-daca1ecd4b94	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 07:09:47.036
0b4929c6-52e3-4e90-831a-e1c99a478551	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 07:09:47.357
66d6c963-77ef-47c1-83da-2fd6f96fb2e4	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 07:09:47.641
6087644c-4a13-4b20-84f4-f5dcea2f7d78	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 07:09:47.671
145d725a-f6db-49d4-a6eb-cbe1274cd818	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 07:11:59.213
326e2719-ff4d-48e8-a619-669e9f051161	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 07:11:59.508
37b3218f-2b34-485e-825d-72afe65e6d4f	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 07:11:59.783
e75ffb2a-1745-4dd7-bff9-496f018241ce	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 07:11:59.826
0d2c973f-3a4b-4621-89c2-6aa4601d3142	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 07:28:30.442
5c504d95-158a-4ba8-ad49-80f76ced9a6e	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 07:28:31.018
62730acc-d5db-4d52-8c77-6aa9ffb110bb	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 07:28:31.434
b0626ade-ca25-4823-a881-a1c00f1c3527	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 07:28:31.468
b2a2ab80-5ce5-4136-ad48-b556927dcb64	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 12:56:49.242
bed10a74-ab88-49cb-a61a-18d17b6ea266	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 12:56:49.725
0ae908ee-46d4-45b1-bec2-ce8f0d4e9431	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 12:56:50.115
0cd59330-7907-4939-9d93-b7f0eb36bf96	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 12:56:50.15
21618c1a-6e60-41de-9d48-bff38d01cc1d	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 12:59:47.35
99b1fcc0-c32c-4d9d-aead-841ae31bb7a1	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	login_success	2026-03-19 12:59:47.821
ec486504-f66f-47cc-b810-84ec2a292aa6	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	invalid_password	2026-03-19 12:59:48.196
982c3891-3eeb-48a7-a3cc-a34eae6ee19a	\N	nonexistent@example.com	f	::ffff:127.0.0.1	ServiceOrderTestSuite/1.0	user_not_found	2026-03-19 12:59:48.229
3258dff8-084a-4043-b9d7-99590e694995	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	BillingTestSuite/1.0	login_success	2026-03-19 14:36:58.361
6bc21b09-42cc-458f-a053-c7c6c5ef146f	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	BillingTestSuite/1.0	login_success	2026-03-19 14:36:58.843
50dbf93f-5a6d-4219-afa1-87d2d9a80618	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	BillingTestSuite/1.0	invalid_password	2026-03-19 14:36:59.253
1559020c-b48d-43f3-a3e1-c1703849fefd	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	BillingTestSuite/1.0	login_success	2026-03-20 00:24:22.119
767cd0c9-0c5b-4500-9d15-0ab3dab0594a	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	BillingTestSuite/1.0	login_success	2026-03-20 00:24:22.484
f7fcedf7-913f-4767-a806-e6778f990677	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	BillingTestSuite/1.0	invalid_password	2026-03-20 00:24:22.867
ddd3cb49-0497-4233-81af-65940d36c264	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	BillingTestSuite/1.0	login_success	2026-03-20 00:49:58.507
4d52f831-f53a-450d-a03e-601a49197a5d	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::ffff:127.0.0.1	BillingTestSuite/1.0	login_success	2026-03-20 00:49:58.998
acf4b32b-3521-41bd-bac0-2a8d1a561f32	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	f	::ffff:127.0.0.1	BillingTestSuite/1.0	invalid_password	2026-03-20 00:49:59.39
7d346758-597b-4269-a203-8a6c82446488	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-20 09:21:05.935
1c40017a-4caa-43c2-be76-49115414b842	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-20 10:07:04.066
6d0d33fd-dd05-410d-a98e-e08bd180eed8	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-20 10:26:34.136
01e5ff9c-1d05-44ff-a5eb-b79b542b42c8	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-20 10:42:06.627
9200f48b-a24d-49be-be80-f8b293ebd42b	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 10:58:10.881
0170826d-d932-46e8-81ae-bce4fa8b064c	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-20 11:03:48.546
a85eeb30-a925-452b-9488-f7c4315ec085	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-20 11:04:16.115
2ea49ea5-b85b-48a3-b9c1-26a7f2095cb8	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 11:14:08.707
21a684f3-0228-4c84-b3a5-f6cbdee86133	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 11:29:18.03
d4291fbf-f997-4761-a636-4a95f8f3d99a	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 12:15:38.707
d85bcde3-e3bf-4ada-b7d8-6c0a13e8156a	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 12:26:09.428
7d1e7f31-28ae-4be3-9d52-e16604c9f5bc	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 12:28:39.027
4ca95ef4-4948-413a-b12b-136282b46b61	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 12:30:16.953
6abd9189-d6a7-4ef9-a1fc-47332edf8715	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-20 12:32:10.685
3e6550d1-9cae-4630-8aac-5b70e6b59346	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 12:36:39.739
79e0b2df-49c2-4595-b6b9-6d33a2e37dbe	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 12:40:07.798
bfb2cee7-752a-4079-97d4-8e2cc2507d1e	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-20 12:45:42.506
3f3bc8d0-6ca9-43b3-b254-6d79cf52c1d6	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-20 12:53:54.351
cde821b6-321a-4f41-910b-8c7432383044	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-21 12:35:09.667
e0df9db5-3928-4278-ae7a-667b1f745913	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 12:44:12.344
c9311bb1-6cc7-40c3-abc4-795f12c6c849	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	invalid_password	2026-03-21 12:48:51.302
a5382e80-ae68-4abf-91d0-cd012e49c422	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-21 12:49:03.203
2c872a45-a1dc-47c2-aa08-ab5e29744aca	75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	login_success	2026-03-21 12:57:18.167
3dadd80f-13aa-4383-8122-bd76f7dbcf39	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	::ffff:127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:18:34.462
e3f7cd6f-e630-4492-9d7e-075898794f4a	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:33:36.33
c986a17a-5b8c-48e6-a048-7389e60a7aa0	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:35:23.49
8766a182-7db3-432f-9445-fbd77805288d	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:47:58.257
4014c7e2-1d37-45b6-b48f-8065c81967a3	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:48:04.935
0f28bc73-e418-4c3f-8892-a2c7b9c63db0	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:48:06.551
19d984dd-7d5e-4247-a01a-df08307c7cfa	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:48:24.902
dbc9947c-ad63-46bd-9902-01cd5dae9a3e	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:48:26.397
80e28294-2793-4251-8914-46c980752f84	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	192.168.100.214	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:49:31.759
453c4d37-35dc-4420-b24e-7da0f66c2c34	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 13:53:21.071
d294165a-0903-4978-af7f-39ae976c5e6b	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 14:19:38.517
854dbe83-c998-4e38-8cf2-788bddae5f7d	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 14:35:06.077
c2c0a976-15fa-47e2-b7e9-1168c75bd766	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 14:55:01.843
a6abccb2-74ba-44c2-b176-bf7c347246bc	ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	t	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	login_success	2026-03-21 15:11:06.002
\.


--
-- Data for Name: MarketplaceProduct; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."MarketplaceProduct" (id, "createdAt", category, description, "devId", name, published, rating) FROM stdin;
\.


--
-- Data for Name: MarketplacePurchase; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."MarketplacePurchase" (id, "userId", "createdAt", data) FROM stdin;
\.


--
-- Data for Name: MarketplaceReview; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."MarketplaceReview" (id, "productId", "userId", rating, "createdAt", text, title) FROM stdin;
\.


--
-- Data for Name: MarketplaceSubmission; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."MarketplaceSubmission" (id, "createdAt", json, name, "userId", status) FROM stdin;
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Order" (id, "clientId", "snapshotId", status, "startedAt", "nextRenewalAt", "suspendedAt", "terminatedAt", "cancelledAt", "createdAt", "updatedAt", "provisioningError", "provisioningStatus") FROM stdin;
ae271421-57e6-4182-acb2-745b02df72c4	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-09 01:25:08.996	2026-04-09 01:25:08.996	\N	\N	\N	2026-03-09 01:25:08.899	2026-03-09 01:25:08.997	\N	\N
85f08533-020c-44aa-8c6f-e6cd8e5b49dc	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-09 01:25:09.053	2027-03-09 01:25:09.053	\N	\N	\N	2026-03-09 01:25:08.952	2026-03-09 01:25:09.055	\N	\N
ac5b1376-b48f-48f2-93ac-58cc29f96770	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-09 01:25:09.111	2026-03-09 01:25:09.111	\N	\N
f42c3915-d6ad-44a3-8f3a-66caeedf8047	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-09 01:48:41.631	2026-04-09 01:48:41.631	\N	\N	\N	2026-03-09 01:48:41.497	2026-03-09 01:48:41.632	\N	\N
427e3e7c-8dbb-467b-aeed-d90588dc7a8a	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-09 01:48:41.682	2026-03-09 01:48:41.682	\N	\N
f6adda86-5462-4248-ab52-2cb031a09cdd	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-09 01:48:41.846	2026-03-09 01:48:41.846	\N	\N
67def6d8-e3cb-4975-a9de-62bb5e10763d	ea27b74d-bb76-4789-b18b-0686c0f07a62	\N	pending	\N	\N	\N	\N	\N	2026-03-09 01:48:42.212	2026-03-09 01:48:42.212	\N	\N
fbdc860d-a39d-478c-87f9-d71f24e9c961	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-16 09:16:58.331	2026-04-16 09:16:58.331	\N	\N	\N	2026-03-16 09:16:58.088	2026-03-16 09:16:58.334	\N	\N
b6bb134f-5524-4479-86dd-5ff274aa946a	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-16 09:16:58.431	2026-03-16 09:16:58.431	\N	\N
975f3e1a-5128-4c96-b6e1-635fab9cff43	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-16 09:16:58.815	2026-03-16 09:16:58.815	\N	\N
7397f959-9aaf-4654-b61c-96ff85c90559	ea27b74d-bb76-4789-b18b-0686c0f07a62	\N	pending	\N	\N	\N	\N	\N	2026-03-16 09:16:59.502	2026-03-16 09:16:59.502	\N	\N
3cf9771f-0e03-4a26-a819-77b630bf9ab6	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-18 07:49:27.086	2026-04-18 07:49:27.086	\N	\N	\N	2026-03-18 07:49:26.916	2026-03-18 07:49:27.088	\N	\N
09c75743-1c74-418c-a0f4-5af8de1ec39f	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-18 07:58:05.593	2026-04-18 07:58:05.593	\N	\N	\N	2026-03-18 07:58:05.506	2026-03-18 07:58:05.595	\N	\N
799b787c-dc5f-4430-98a4-7781778cebe8	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-19 07:07:14.282	2026-05-19 07:07:14.282	\N	2026-03-19 07:07:14.503	\N	2026-03-19 07:07:13.846	2026-03-19 07:07:14.504	\N	\N
0ba017fe-e695-4b36-947b-acd4190dcda3	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 07:07:14.05	2026-03-19 07:07:14.05	\N	\N
c21f21c6-2e33-43a7-a791-b293e1a20249	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 07:07:14.556	2026-03-19 07:07:14.556	\N	\N
ac14f076-c8a1-41bd-a099-9f42e7a125c4	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 07:07:14.703	2026-04-19 07:07:14.703	\N	\N	\N	2026-03-19 07:07:14.63	2026-03-19 07:07:14.705	\N	\N
8b91209f-0d83-49a9-867f-972e0d2ce998	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 07:07:14.916	2026-06-19 07:07:14.916	\N	\N	\N	2026-03-19 07:07:14.862	2026-03-19 07:07:15.027	\N	\N
4adfb958-ba7c-44c5-8d28-d63daf392ba3	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-19 07:12:01.875	2026-05-19 07:12:01.875	\N	2026-03-19 07:12:02.17	\N	2026-03-19 07:12:01.418	2026-03-19 07:12:02.172	\N	\N
e5376412-a5d8-4c35-ae7a-9e7de675c4a7	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 07:12:01.619	2026-03-19 07:12:01.619	\N	\N
2f6732a5-8a0f-4bcb-86c8-dffe84e7ca30	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 07:12:02.233	2026-03-19 07:12:02.233	\N	\N
8c807759-c7d7-46c1-aad7-7462edead9a1	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 07:12:02.39	2026-04-19 07:12:02.39	\N	\N	\N	2026-03-19 07:12:02.305	2026-03-19 07:12:02.391	\N	\N
3607aa81-36ec-4360-bb7e-e465e803f4a7	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 07:12:02.606	2026-06-19 07:12:02.606	\N	\N	\N	2026-03-19 07:12:02.519	2026-03-19 07:12:02.807	\N	\N
5da2308f-8b10-4d52-a988-b7d0ad77899d	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-19 12:59:52.424	2026-05-19 12:59:52.424	\N	2026-03-19 12:59:52.815	\N	2026-03-19 12:59:51.264	2026-03-19 12:59:52.816	\N	\N
581a3e5b-74ad-42ab-b072-e6f3f12d2a35	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:59:51.712	2026-03-19 12:59:51.712	\N	\N
c21920e9-3302-424d-ada3-3472cbd5f31e	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:59:51.815	2026-03-19 12:59:51.815	\N	\N
f21233c1-c749-46cc-b5d3-405d7ed73671	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:59:51.957	2026-03-19 12:59:51.957	\N	\N
05553d0d-a4a1-4aa5-96ae-ede92450cc5e	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:59:52.267	2026-03-19 12:59:52.267	\N	\N
73a41257-8b35-4cf5-a3af-a2113f237049	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:59:52.905	2026-03-19 12:59:52.905	\N	\N
7676aa9b-3b70-4da6-acca-13e757a96d92	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 12:59:53.124	2026-04-19 12:59:53.124	\N	\N	\N	2026-03-19 12:59:53.029	2026-03-19 12:59:53.125	\N	\N
9801492b-49f5-484e-8c9b-53d11edc9b01	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 12:59:53.383	2026-06-19 12:59:53.383	\N	\N	\N	2026-03-19 12:59:53.288	2026-03-19 12:59:53.575	\N	\N
f6688626-8530-4d51-9d5b-80a9fde8eb7c	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-19 06:55:40.145	2026-05-19 06:55:40.145	\N	2026-03-19 06:55:40.399	\N	2026-03-19 06:55:39.655	2026-03-19 06:55:40.4	\N	\N
4279bd25-3c48-4272-adbd-9185e92dc1ec	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 06:55:39.912	2026-03-19 06:55:39.912	\N	\N
aeec155a-a2d9-49b7-b43b-6ff4045b61ae	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 06:55:40.453	2026-03-19 06:55:40.453	\N	\N
8b63dcd7-0152-4ec5-b5e3-6b856b414115	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 06:55:40.62	2026-04-19 06:55:40.62	\N	\N	\N	2026-03-19 06:55:40.527	2026-03-19 06:55:40.621	\N	\N
0ab6f321-e7ea-4f50-818c-aeb4faae3ad4	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 06:55:40.779	2026-06-19 06:55:40.779	\N	\N	\N	2026-03-19 06:55:40.726	2026-03-19 06:55:40.891	\N	\N
b60f50ac-4704-4210-b00a-b1925ad29d28	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:01.786	2026-03-19 14:37:01.786	\N	\N
7e7129ed-2dad-42f3-9284-ac4ad73e5239	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:02.221	2026-03-19 14:37:02.221	\N	\N
b8c08a3c-4358-49e5-a874-5d1e6cec54a6	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:03.3	2026-03-19 14:37:03.3	\N	\N
a2e8e9b4-13e8-42b4-a6ea-48f28cb1814e	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:03.636	2026-03-19 14:37:03.636	\N	\N
56b80dcf-458d-48c5-9d9d-d43d0f5baab4	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:04.127	2026-03-19 14:37:04.127	\N	\N
99b93118-7aa4-4d2d-8498-0277ddf292ba	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:04.987	2026-03-19 14:37:04.987	\N	\N
aba4b8ea-cd1c-41a2-9b5c-14b6b95fe807	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:05.848	2026-03-19 14:37:05.848	\N	\N
71ef58f4-1d05-4d9c-9096-4ee446ece4b5	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:06.486	2026-03-19 14:37:06.486	\N	\N
d2ff3af1-3e50-4c63-a116-3ad6f74f479f	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:08.517	2026-03-19 14:37:08.517	\N	\N
e89078a5-9c39-4fd5-8130-896208fc7c28	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:08.853	2026-03-19 14:37:08.853	\N	\N
d19e49e9-8d86-4872-9cbd-b6f900157063	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:09.327	2026-03-19 14:37:09.327	\N	\N
932b70ef-1c86-43ef-960d-2a8f5debc959	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:10.751	2026-03-19 14:37:10.751	\N	\N
90dff4ff-cffb-429c-afcc-f311ec44ad39	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 14:37:11.394	2026-03-19 14:37:11.394	\N	\N
8a724135-849f-4129-9d48-ba6928dd415b	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-19 14:37:11.947	2026-07-19 14:37:11.947	\N	2026-03-19 14:37:13.249	\N	2026-03-19 14:37:11.836	2026-03-19 14:37:13.251	\N	\N
72b01242-2bd6-4ab0-b0ac-6b800fa7d278	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	suspended	2026-03-19 14:37:13.553	2026-04-19 14:37:13.553	2026-03-19 14:37:13.661	\N	\N	2026-03-19 14:37:13.445	2026-03-19 14:37:13.663	\N	\N
20269616-43e2-462f-b298-9b5f32c9e373	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	suspended	2026-03-19 14:37:14.154	2027-03-19 14:37:14.154	2026-03-19 14:37:14.264	\N	\N	2026-03-19 14:37:14.044	2026-03-19 14:37:14.265	\N	\N
8a1832c9-cd14-433f-93f8-9a84c6ebd60f	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:25.268	2026-03-20 00:24:25.268	\N	\N
28ce0be5-e7ee-43e1-b6ad-9dac45833384	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:25.738	2026-03-20 00:24:25.738	\N	\N
092cb080-26d0-4e72-aa29-701159977db6	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:26.917	2026-03-20 00:24:26.917	\N	\N
143d4676-1eff-40c0-b466-af70fd9dc3f6	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:27.263	2026-03-20 00:24:27.263	\N	\N
4580e127-eedb-4f64-8aae-9fd890434c63	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:27.785	2026-03-20 00:24:27.785	\N	\N
3a720a55-aae6-416b-9029-f7503b344a8e	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:28.62	2026-03-20 00:24:28.62	\N	\N
f87b2928-0b9f-4776-a1f9-739bf2e30a03	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:29.37	2026-03-20 00:24:29.37	\N	\N
c2bb61d9-fe0c-414b-b00a-3a6fad489511	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:29.968	2026-03-20 00:24:29.968	\N	\N
e3aa0668-c8d8-48b3-bc78-b6c2026f4173	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:31.795	2026-03-20 00:24:31.795	\N	\N
13471462-3d14-48f2-a01a-bf76219a32bb	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:32.109	2026-03-20 00:24:32.109	\N	\N
6fd5f1f6-f14a-48b1-aa9f-7322604ea6b6	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:32.569	2026-03-20 00:24:32.569	\N	\N
c2528ec3-d291-47bc-bfff-ecd21564a20d	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:33.953	2026-03-20 00:24:33.953	\N	\N
dc185787-2235-4ca3-b3e5-1e8ad3dfc19c	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:24:34.608	2026-03-20 00:24:34.608	\N	\N
22afc7fe-81f3-4167-9708-ee7255454d52	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-20 00:24:35.17	2026-07-20 00:24:35.17	\N	2026-03-20 00:24:36.549	\N	2026-03-20 00:24:35.059	2026-03-20 00:24:36.551	\N	\N
dd9bd264-4eb6-446e-aeef-b7574e48696d	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	suspended	2026-03-20 00:24:36.846	2026-04-20 00:24:36.846	2026-03-20 00:24:36.951	\N	\N	2026-03-20 00:24:36.74	2026-03-20 00:24:36.952	\N	\N
a0e54e28-7388-491d-93a2-cfcd2f4089cb	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	suspended	2026-03-20 00:24:37.409	2027-03-20 00:24:37.409	2026-03-20 00:24:37.517	\N	\N	2026-03-20 00:24:37.303	2026-03-20 00:24:37.518	\N	\N
020041e9-b2c7-4311-b64c-ca67724432da	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-19 06:56:01.229	2026-05-19 06:56:01.229	\N	2026-03-19 06:56:01.49	\N	2026-03-19 06:56:00.717	2026-03-19 06:56:01.491	\N	\N
4f13c816-6cfe-4265-93ab-215891d324dc	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 06:56:00.995	2026-03-19 06:56:00.995	\N	\N
a769bbe9-cade-4007-8095-25bc79576392	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 06:56:01.543	2026-03-19 06:56:01.543	\N	\N
4bc39786-40ce-47ae-ae05-7290c346695c	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 06:56:01.729	2026-04-19 06:56:01.729	\N	\N	\N	2026-03-19 06:56:01.643	2026-03-19 06:56:01.73	\N	\N
c95e0674-d5bc-4e9e-b6e6-645c8f6b8cff	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 06:56:01.875	2026-06-19 06:56:01.875	\N	\N	\N	2026-03-19 06:56:01.822	2026-03-19 06:56:01.984	\N	\N
41836f9a-5559-4067-b11a-8695d34f2bf3	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-19 07:28:35.427	2026-05-19 07:28:35.427	\N	2026-03-19 07:28:35.822	\N	2026-03-19 07:28:34.61	2026-03-19 07:28:35.824	\N	\N
6795621a-9c8a-4740-afd7-6b9a425a5db9	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 07:28:34.961	2026-03-19 07:28:34.961	\N	\N
d812c705-2712-455b-859b-bccf0db14503	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 07:28:35.914	2026-03-19 07:28:35.914	\N	\N
eb46f5c9-da3a-4921-8c2e-d35c30b7b34d	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 07:28:36.132	2026-04-19 07:28:36.132	\N	\N	\N	2026-03-19 07:28:36.038	2026-03-19 07:28:36.134	\N	\N
9ab95733-46aa-4b31-973d-1ea3ed200359	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 07:28:36.395	2026-06-19 07:28:36.395	\N	\N	\N	2026-03-19 07:28:36.301	2026-03-19 07:28:36.585	\N	\N
97abf799-0fd5-4dcc-bc5a-7c20c0b75dd3	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-19 12:56:54.197	2026-05-19 12:56:54.197	\N	2026-03-19 12:56:54.468	\N	2026-03-19 12:56:53.417	2026-03-19 12:56:54.469	\N	\N
63334688-f6d5-49de-a2c9-bbbd7dc871a6	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:56:53.699	2026-03-19 12:56:53.699	\N	\N
5af590aa-f9ae-4ae4-8400-deb10f2354a0	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:56:53.771	2026-03-19 12:56:53.771	\N	\N
d558f26c-af67-4a5c-92cc-8f7b90332aea	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:56:53.866	2026-03-19 12:56:53.866	\N	\N
2f7956ca-bb8b-4f1f-a3e9-9c8af4cd1e1a	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:56:54.071	2026-03-19 12:56:54.071	\N	\N
abeb1a3f-508e-458f-8023-82b6d82d795c	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 12:56:54.529	2026-03-19 12:56:54.529	\N	\N
1acb3ca4-b1ca-43b3-816d-886b7d682bd8	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 12:56:54.681	2026-04-19 12:56:54.681	\N	\N	\N	2026-03-19 12:56:54.618	2026-03-19 12:56:54.682	\N	\N
bf78ee16-6092-429d-90ed-694a657de018	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 12:56:54.874	2026-06-19 12:56:54.874	\N	\N	\N	2026-03-19 12:56:54.811	2026-03-19 12:56:55.002	\N	\N
c4e4bda2-b9fd-41d3-80cd-2ded77fece8f	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 06:42:11.748	2026-05-19 06:42:11.748	\N	\N	\N	2026-03-19 06:42:11.125	2026-03-19 06:42:11.805	\N	\N
98a32053-bdc7-4111-9d23-56a9376134dd	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 06:42:11.403	2026-03-19 06:42:11.403	\N	\N
fb04bd30-0c10-47a9-889f-55ec716f2cf9	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 06:42:11.981	2026-03-19 06:42:11.981	\N	\N
3ce5419e-bfa8-4f0c-9065-8038b0b61f44	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 06:42:12.181	2026-04-19 06:42:12.181	\N	\N	\N	2026-03-19 06:42:12.097	2026-03-19 06:42:12.182	\N	\N
b1e14122-4d71-4ea8-8b12-45423c20c985	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 06:42:12.327	2026-06-19 06:42:12.327	\N	\N	\N	2026-03-19 06:42:12.272	2026-03-19 06:42:12.455	\N	\N
e0fd3cb5-0ef4-4f8d-9a2b-b6642af42e03	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-19 06:53:00.845	2026-05-19 06:53:00.845	\N	2026-03-19 06:53:01.122	\N	2026-03-19 06:53:00.303	2026-03-19 06:53:01.123	\N	\N
461d9caf-ae09-455f-9088-3019a9d3886a	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 06:53:00.568	2026-03-19 06:53:00.568	\N	\N
18356ce4-8e01-4e9d-92cb-7786bb605ff9	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-19 06:53:01.176	2026-03-19 06:53:01.176	\N	\N
6bd092f0-b807-4a13-8faf-c6b2d02e146e	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 06:53:01.347	2026-04-19 06:53:01.347	\N	\N	\N	2026-03-19 06:53:01.262	2026-03-19 06:53:01.349	\N	\N
8a6e4706-7b96-4265-810b-22e436744032	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	active	2026-03-19 06:53:01.559	2026-06-19 06:53:01.559	\N	\N	\N	2026-03-19 06:53:01.492	2026-03-19 06:53:01.698	\N	\N
9b1117d2-33da-4384-a851-b1fc51f418f2	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:01.952	2026-03-20 00:50:01.952	\N	\N
b86471ed-335a-4133-8659-9d066e91a6d5	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:02.077	2026-03-20 00:50:02.077	\N	\N
fa23ca2c-a32e-437f-9196-0703fa51874b	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:02.613	2026-03-20 00:50:02.613	\N	\N
91269c8d-ff8c-41cf-b89a-e0f9283ab946	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:03.786	2026-03-20 00:50:03.786	\N	\N
1555ddbb-d791-462b-85a8-3276c0a7443e	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:04.093	2026-03-20 00:50:04.093	\N	\N
9c1ae65a-23d3-40ff-b84d-a21131c9de1e	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:04.55	2026-03-20 00:50:04.55	\N	\N
b48eb7ad-7f27-469a-bed3-d0da365e3e0d	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:05.279	2026-03-20 00:50:05.279	\N	\N
2df8ffdd-b5cb-4ef3-a770-72c39c595550	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:06.016	2026-03-20 00:50:06.016	\N	\N
080227cb-656a-4839-ab3a-801a4a440099	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:06.627	2026-03-20 00:50:06.627	\N	\N
8b60a549-da88-4c95-a1c0-f2c7a879b2b3	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:08.563	2026-03-20 00:50:08.563	\N	\N
0984df4a-eaa8-498c-8da6-31aac591c637	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:08.876	2026-03-20 00:50:08.876	\N	\N
3882126b-d1de-4c84-a207-b472e3814679	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:09.297	2026-03-20 00:50:09.297	\N	\N
66c91df1-c89d-4ba5-a6fd-5f5e2c2e8a50	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:10.882	2026-03-20 00:50:10.882	\N	\N
be3b2449-0dcc-40b5-ab8b-a7d477c08680	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	pending	\N	\N	\N	\N	\N	2026-03-20 00:50:11.564	2026-03-20 00:50:11.564	\N	\N
d937c100-fc3e-44a6-9ad0-795da003839f	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	terminated	2026-03-20 00:50:12.128	2026-07-20 00:50:12.128	\N	2026-03-20 00:50:13.49	\N	2026-03-20 00:50:12.019	2026-03-20 00:50:13.493	\N	\N
c7803822-cbe5-4827-8fd0-16ab34dd2f59	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	suspended	2026-03-20 00:50:13.827	2026-04-20 00:50:13.827	2026-03-20 00:50:13.935	\N	\N	2026-03-20 00:50:13.724	2026-03-20 00:50:13.936	\N	\N
58131e80-6ac7-49ca-82d9-5a46cbd0a7ab	75be047c-38b6-4cfc-aa3b-3c996c67755d	\N	suspended	2026-03-20 00:50:14.403	2027-03-20 00:50:14.403	2026-03-20 00:50:14.509	\N	\N	2026-03-20 00:50:14.296	2026-03-20 00:50:14.511	\N	\N
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Payment" (id, "invoiceId", "clientId", amount, currency, status, gateway, "gatewayRef", "gatewayResponse", "gatewayStatus", "paidAt", "failedAt", "failReason", "createdAt", "updatedAt", "isAutoCharge", "paymentMethodId") FROM stdin;
8be18064-676a-4fe4-896b-88773db7fe34	7d7eac3d-e376-452b-89a8-afe60106823c	75be047c-38b6-4cfc-aa3b-3c996c67755d	99.99	USD	completed	manual	\N	null	\N	2026-03-09 01:25:09.332	\N	\N	2026-03-09 01:25:09.333	2026-03-09 01:25:09.333	f	\N
0d1ddded-23c9-4802-9830-9e280f4f05d8	aa21c76a-39b3-4c6b-82f8-e357f7bbc5a5	75be047c-38b6-4cfc-aa3b-3c996c67755d	99.99	USD	completed	manual	\N	null	\N	2026-03-09 01:48:42.004	\N	\N	2026-03-09 01:48:42.004	2026-03-09 01:48:42.004	f	\N
bf31b91f-6d72-4183-bdce-be98933eb7bc	ba611e7d-81b3-4f23-a4bd-9d4dbaa31ee2	75be047c-38b6-4cfc-aa3b-3c996c67755d	99.99	USD	completed	manual	\N	null	\N	2026-03-16 09:16:59.148	\N	\N	2026-03-16 09:16:59.149	2026-03-16 09:16:59.149	f	\N
8055871d-0e8b-4353-a13b-8c8491d5af81	3284ae02-6de3-477b-ad9f-15173abacaae	75be047c-38b6-4cfc-aa3b-3c996c67755d	9.99	USD	completed	manual	\N	null	\N	2026-03-18 07:49:29.389	\N	\N	2026-03-18 07:49:29.39	2026-03-18 07:49:29.39	f	\N
19e42b41-655e-4d3a-ae9b-487d5b5e4e8d	95c70590-5409-4b9f-bbc4-5ef6e34a574e	75be047c-38b6-4cfc-aa3b-3c996c67755d	9.99	USD	completed	manual	\N	null	\N	2026-03-18 07:58:07.925	\N	\N	2026-03-18 07:58:07.926	2026-03-18 07:58:07.926	f	\N
69b8aa04-8131-4e2b-9812-ade0c0286623	68606940-0cdf-415c-9af9-7a075ccd3c1b	75be047c-38b6-4cfc-aa3b-3c996c67755d	17.55	USD	completed	manual	\N	null	\N	2026-03-19 14:37:07.822	\N	\N	2026-03-19 14:37:07.824	2026-03-19 14:37:07.824	f	\N
9c16ac8d-30bf-4f2a-93ce-bb2bc7f13db6	ab98101d-bb28-4623-a5f2-77e2eaf72b16	75be047c-38b6-4cfc-aa3b-3c996c67755d	35.09	USD	pending	stripe	\N	null	\N	\N	\N	\N	2026-03-19 14:37:08.727	2026-03-19 14:37:08.727	f	\N
41d3aa46-76a1-4c32-b7b2-67fba8bfe2c1	64265f83-a63b-4a7a-bc27-0e7918a16699	75be047c-38b6-4cfc-aa3b-3c996c67755d	1035.09	USD	completed	manual	\N	null	\N	2026-03-19 14:37:09.105	\N	\N	2026-03-19 14:37:09.106	2026-03-19 14:37:09.106	f	\N
d05f440a-bff6-4423-8d41-7200ffd4ff9a	68606940-0cdf-415c-9af9-7a075ccd3c1b	75be047c-38b6-4cfc-aa3b-3c996c67755d	17.54	USD	refunded	stripe	\N	null	\N	2026-03-19 14:37:08.183	\N	\N	2026-03-19 14:37:08.184	2026-03-19 14:37:10.609	f	\N
e2968870-8ff9-4329-9680-66735395baa1	af7cf402-ed48-46b1-b05f-65a4f2628b65	75be047c-38b6-4cfc-aa3b-3c996c67755d	35.09	USD	completed	manual	\N	null	\N	2026-03-19 14:37:10.981	\N	\N	2026-03-19 14:37:10.982	2026-03-19 14:37:10.982	f	\N
30c17600-4ea9-460d-8f84-aec75ab40cc0	94a32756-6285-447e-aeb5-999593ce2aad	75be047c-38b6-4cfc-aa3b-3c996c67755d	35.09	USD	completed	manual	\N	null	\N	2026-03-19 14:37:11.617	\N	\N	2026-03-19 14:37:11.618	2026-03-19 14:37:11.618	f	\N
fab5c7ef-2c49-4c06-8abf-1f9ae39b9655	5d3eca53-5905-4aba-ac75-abb64ee9a656	75be047c-38b6-4cfc-aa3b-3c996c67755d	17.55	USD	completed	manual	\N	null	\N	2026-03-20 00:24:31.145	\N	\N	2026-03-20 00:24:31.146	2026-03-20 00:24:31.146	f	\N
ff9444e7-7ada-474e-863a-5e8f4a6ad4ca	55e6ed6d-2bd4-4617-88db-44180d9be4ba	75be047c-38b6-4cfc-aa3b-3c996c67755d	35.09	USD	pending	stripe	\N	null	\N	\N	\N	\N	2026-03-20 00:24:31.991	2026-03-20 00:24:31.991	f	\N
9116db92-aad6-43f8-913e-8eab7b13d497	dc4348e6-0930-4cee-97c1-efc5687de545	75be047c-38b6-4cfc-aa3b-3c996c67755d	1035.09	USD	completed	manual	\N	null	\N	2026-03-20 00:24:32.344	\N	\N	2026-03-20 00:24:32.346	2026-03-20 00:24:32.346	f	\N
edc6b49c-c1c0-4502-ba01-56739b49b029	5d3eca53-5905-4aba-ac75-abb64ee9a656	75be047c-38b6-4cfc-aa3b-3c996c67755d	17.54	USD	refunded	stripe	\N	null	\N	2026-03-20 00:24:31.473	\N	\N	2026-03-20 00:24:31.475	2026-03-20 00:24:33.818	f	\N
06799dba-e567-4bd2-9f57-5a0f08d59517	dfa94450-6de6-457c-9328-133668c7c575	75be047c-38b6-4cfc-aa3b-3c996c67755d	35.09	USD	completed	manual	\N	null	\N	2026-03-20 00:24:34.176	\N	\N	2026-03-20 00:24:34.177	2026-03-20 00:24:34.177	f	\N
4bd9a4c2-f21b-4629-babd-23c9c69f5e5d	3ae54a3c-6ed2-4457-977e-63feed611fd2	75be047c-38b6-4cfc-aa3b-3c996c67755d	35.09	USD	completed	manual	\N	null	\N	2026-03-20 00:24:34.841	\N	\N	2026-03-20 00:24:34.842	2026-03-20 00:24:34.842	f	\N
06ce5231-d845-4677-bf2a-dd18fea17c5d	bb84cdef-e070-4482-b547-3cfc06a499eb	75be047c-38b6-4cfc-aa3b-3c996c67755d	22.54	USD	completed	manual	\N	null	completed	2026-03-20 00:50:07.857	\N	\N	2026-03-20 00:50:07.859	2026-03-20 00:50:07.859	f	\N
907a28d6-31ab-4bf2-bded-b501fb78077c	bb84cdef-e070-4482-b547-3cfc06a499eb	75be047c-38b6-4cfc-aa3b-3c996c67755d	22.54	USD	refunded	stripe	\N	null	completed	2026-03-20 00:50:08.203	\N	\N	2026-03-20 00:50:08.205	2026-03-20 00:50:10.733	f	\N
2bbe556d-560f-47fb-af6d-bebd7274eb2e	12371e0c-729c-4c8c-95c6-5b6e9d552438	75be047c-38b6-4cfc-aa3b-3c996c67755d	45.08	USD	completed	manual	\N	null	completed	2026-03-20 00:50:11.13	\N	\N	2026-03-20 00:50:11.131	2026-03-20 00:50:11.131	f	\N
88cf5267-d172-476e-97da-794298a51d4f	3c796640-f5e7-4be4-a252-dc5d270e427e	75be047c-38b6-4cfc-aa3b-3c996c67755d	45.08	USD	completed	manual	\N	null	completed	2026-03-20 00:50:11.803	\N	\N	2026-03-20 00:50:11.805	2026-03-20 00:50:11.805	f	\N
\.


--
-- Data for Name: PaymentMethod; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."PaymentMethod" (id, "clientId", "billingProfileId", type, gateway, "gatewayRef", "gatewayCustomer", last4, brand, "expiryMonth", "expiryYear", email, "bankName", "isDefault", active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Permission" (id, key, description) FROM stdin;
3cf65c97-0fb4-4ea0-8a5a-24925bf85340	admin.access	Access admin portal
0daf6033-8dc5-43fd-b1d7-3911467100a6	admin.manage.staff	Manage admin staff accounts
5161d006-a5a6-4983-be48-9dbd60a4ffec	admin.settings.update	Update system settings
466466bc-a1c2-4922-8426-61d793fff7fb	client.area.access	Access client dashboard
1b37d03e-c83c-45f7-ba7d-d06b616bb1fe	billing.invoices.view	View invoices
2b7e6b35-2f4a-4843-850b-d844f9815c14	billing.invoices.pay	Pay invoices
e95530dd-2b03-4f8c-8720-307167cce10b	reseller.dashboard.access	Access reseller dashboard
c299ee33-75c9-4da8-b4c0-e7f241252b59	developer.console.access	Access developer console
895c0714-1718-41cf-accc-4e30b6642332	plugins.upload	Upload new plugin to marketplace
0c9e1a4f-59e3-4720-843b-2cbf5ac0b029	plugins.update	Update existing plugin versions
55ff3feb-6512-4b80-b6f9-eb2674f6b5cc	orders.create	Create a new order
08d9c870-8a2f-46eb-99dc-0e96445cb7fd	orders.read	View own orders
065ae68d-cf42-48cb-9803-11e6b5c5b780	orders.cancel	Cancel pending orders
0f55f731-dcb2-4480-a8da-6bfe7840d19b	orders.renew	Renew active orders
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."RefreshToken" (id, token, "userId", "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Refund; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Refund" (id, "paymentId", "invoiceId", amount, reason, notes, gateway, "gatewayRef", "gatewayResponse", "processedAt", "createdAt", "updatedAt") FROM stdin;
f3e8c594-4cf6-40f3-a239-5b60fe972beb	d05f440a-bff6-4423-8d41-7200ffd4ff9a	68606940-0cdf-415c-9af9-7a075ccd3c1b	5.85	Partial service credit	Prorated refund for unused period	stripe	\N	\N	2026-03-19 14:37:10.173	2026-03-19 14:37:10.175	2026-03-19 14:37:10.175
0573c3a3-39a2-407b-95f2-17d9af99582d	d05f440a-bff6-4423-8d41-7200ffd4ff9a	68606940-0cdf-415c-9af9-7a075ccd3c1b	11.69	Full service cancellation	\N	stripe	\N	\N	2026-03-19 14:37:10.592	2026-03-19 14:37:10.593	2026-03-19 14:37:10.593
bfa01fe4-109c-469f-9846-0cb5c5adc8ca	edc6b49c-c1c0-4502-ba01-56739b49b029	5d3eca53-5905-4aba-ac75-abb64ee9a656	5.85	Partial service credit	Prorated refund for unused period	stripe	\N	\N	2026-03-20 00:24:33.382	2026-03-20 00:24:33.384	2026-03-20 00:24:33.384
016bf03f-5af7-45d5-b316-3c0e23db1b0b	edc6b49c-c1c0-4502-ba01-56739b49b029	5d3eca53-5905-4aba-ac75-abb64ee9a656	11.69	Full service cancellation	\N	stripe	\N	\N	2026-03-20 00:24:33.799	2026-03-20 00:24:33.8	2026-03-20 00:24:33.8
1398a6ae-85bb-4635-8221-2de9052c5ca0	907a28d6-31ab-4bf2-bded-b501fb78077c	bb84cdef-e070-4482-b547-3cfc06a499eb	7.51	Partial service credit	Prorated refund for unused period	stripe	\N	\N	2026-03-20 00:50:10.262	2026-03-20 00:50:10.263	2026-03-20 00:50:10.263
d6d99deb-c55a-43dd-9012-7eb3c4d2a27a	907a28d6-31ab-4bf2-bded-b501fb78077c	bb84cdef-e070-4482-b547-3cfc06a499eb	15.03	Full service cancellation	\N	stripe	\N	\N	2026-03-20 00:50:10.714	2026-03-20 00:50:10.716	2026-03-20 00:50:10.716
\.


--
-- Data for Name: ResellerProfile; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ResellerProfile" (id, "userId", "resellerCode", company, phone, address) FROM stdin;
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Role" (id, name, description) FROM stdin;
ecab2330-28d0-43c0-b416-15297a2769de	superadmin	Full unrestricted access
75266cf5-41e6-464e-bcd6-38d7eda2d7d5	admin	Admin access with limited control
3679ab28-015b-468c-b0f7-f839b4b7eea2	staff	Support/billing agent
b6d94912-57ad-49f5-902f-292d3e64307d	client	Regular client account
3e9ab923-2500-4b25-89b2-1e5e031bf8e3	reseller	Reseller portal access
d60d742b-6a34-43cb-a22b-bc156595c8dc	developer	Marketplace developer
\.


--
-- Data for Name: RolePermission; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."RolePermission" (id, "roleId", "permissionId") FROM stdin;
0acdbf7c-d502-48ea-ba5d-c62d1ccbe68a	ecab2330-28d0-43c0-b416-15297a2769de	3cf65c97-0fb4-4ea0-8a5a-24925bf85340
4604d89e-bfd3-4e47-a3bb-4985c339c414	ecab2330-28d0-43c0-b416-15297a2769de	0daf6033-8dc5-43fd-b1d7-3911467100a6
ef7b7708-deff-488b-b875-e7a6133e7610	ecab2330-28d0-43c0-b416-15297a2769de	5161d006-a5a6-4983-be48-9dbd60a4ffec
45c8f4f7-4ed7-42d9-9d56-73e33d0a6f70	ecab2330-28d0-43c0-b416-15297a2769de	1b37d03e-c83c-45f7-ba7d-d06b616bb1fe
ad8550c6-55ad-4b8b-b90d-990c986c2865	ecab2330-28d0-43c0-b416-15297a2769de	2b7e6b35-2f4a-4843-850b-d844f9815c14
d2e97bbf-1d37-4a13-ac4a-30ad86d37995	ecab2330-28d0-43c0-b416-15297a2769de	e95530dd-2b03-4f8c-8720-307167cce10b
3871166f-e75f-4780-b5df-64a05f2ed105	ecab2330-28d0-43c0-b416-15297a2769de	c299ee33-75c9-4da8-b4c0-e7f241252b59
862aba45-aced-4cf4-a49f-53cf5970c8f9	ecab2330-28d0-43c0-b416-15297a2769de	895c0714-1718-41cf-accc-4e30b6642332
ec833295-4030-48b5-b3e7-4e1eaf7d435f	ecab2330-28d0-43c0-b416-15297a2769de	0c9e1a4f-59e3-4720-843b-2cbf5ac0b029
a2e5d889-ba11-4cba-9043-4b47f9575b6a	ecab2330-28d0-43c0-b416-15297a2769de	466466bc-a1c2-4922-8426-61d793fff7fb
ec2a05fc-7d07-4034-9ee6-d6dbf1b13119	75266cf5-41e6-464e-bcd6-38d7eda2d7d5	3cf65c97-0fb4-4ea0-8a5a-24925bf85340
e852c7fd-416f-4aba-addf-b1d8abb9364b	75266cf5-41e6-464e-bcd6-38d7eda2d7d5	1b37d03e-c83c-45f7-ba7d-d06b616bb1fe
d8e2e6af-84e5-4a5d-aa24-ee5f32cec9eb	75266cf5-41e6-464e-bcd6-38d7eda2d7d5	2b7e6b35-2f4a-4843-850b-d844f9815c14
517aac59-dfcf-4722-97b9-bd565d355b72	75266cf5-41e6-464e-bcd6-38d7eda2d7d5	466466bc-a1c2-4922-8426-61d793fff7fb
7a9e3c42-a8d8-4930-a9b0-2dafcc2ad814	3679ab28-015b-468c-b0f7-f839b4b7eea2	3cf65c97-0fb4-4ea0-8a5a-24925bf85340
021681c0-5546-4e0e-b4b4-d63b337c9865	3679ab28-015b-468c-b0f7-f839b4b7eea2	1b37d03e-c83c-45f7-ba7d-d06b616bb1fe
f2e6a90b-5141-4dc8-ab4e-eb738c879b8f	b6d94912-57ad-49f5-902f-292d3e64307d	466466bc-a1c2-4922-8426-61d793fff7fb
4fc208c4-bad9-460b-8bf9-e021498a279a	b6d94912-57ad-49f5-902f-292d3e64307d	1b37d03e-c83c-45f7-ba7d-d06b616bb1fe
74d0ed37-f96e-43e8-9549-9f36de7ea8fc	b6d94912-57ad-49f5-902f-292d3e64307d	2b7e6b35-2f4a-4843-850b-d844f9815c14
9a7bf31f-7907-46c3-988f-616e4b9b3746	b6d94912-57ad-49f5-902f-292d3e64307d	55ff3feb-6512-4b80-b6f9-eb2674f6b5cc
5e7089cf-958a-4e02-a31a-535a76d51214	b6d94912-57ad-49f5-902f-292d3e64307d	08d9c870-8a2f-46eb-99dc-0e96445cb7fd
5935a10a-0f94-4b3c-9708-6fc913e06ee8	b6d94912-57ad-49f5-902f-292d3e64307d	065ae68d-cf42-48cb-9803-11e6b5c5b780
4a336515-e2c7-4317-a135-8187d727b37d	b6d94912-57ad-49f5-902f-292d3e64307d	0f55f731-dcb2-4480-a8da-6bfe7840d19b
9f04a7c6-ced5-4882-b861-e572925ff2e1	3e9ab923-2500-4b25-89b2-1e5e031bf8e3	e95530dd-2b03-4f8c-8720-307167cce10b
da7e825d-4d94-48f0-bc80-b627c90c2d7e	3e9ab923-2500-4b25-89b2-1e5e031bf8e3	1b37d03e-c83c-45f7-ba7d-d06b616bb1fe
f5051f80-e2a0-4bd0-bdde-b5571f4f97ad	3e9ab923-2500-4b25-89b2-1e5e031bf8e3	2b7e6b35-2f4a-4843-850b-d844f9815c14
0adbf73e-2ff5-43d1-9641-dc9078983e66	d60d742b-6a34-43cb-a22b-bc156595c8dc	c299ee33-75c9-4da8-b4c0-e7f241252b59
c16af902-ae7a-400d-b3df-e32a5e161a4d	d60d742b-6a34-43cb-a22b-bc156595c8dc	895c0714-1718-41cf-accc-4e30b6642332
7c66ebfc-7c84-409e-ab02-677e319fbbb9	d60d742b-6a34-43cb-a22b-bc156595c8dc	0c9e1a4f-59e3-4720-843b-2cbf5ac0b029
d52322b7-4b2a-4dec-b735-af125876da5b	ecab2330-28d0-43c0-b416-15297a2769de	55ff3feb-6512-4b80-b6f9-eb2674f6b5cc
87280981-2fc5-4805-b656-ccd2bc792e46	ecab2330-28d0-43c0-b416-15297a2769de	08d9c870-8a2f-46eb-99dc-0e96445cb7fd
7cf2e568-1f98-4968-a92d-6ec0a37a6544	ecab2330-28d0-43c0-b416-15297a2769de	065ae68d-cf42-48cb-9803-11e6b5c5b780
7499208f-e52c-477f-8077-b1f8d7ca3383	ecab2330-28d0-43c0-b416-15297a2769de	0f55f731-dcb2-4480-a8da-6bfe7840d19b
\.


--
-- Data for Name: Service; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Service" (id, code, name, description, "shortDescription", "groupId", "parentServiceId", "moduleName", "moduleType", active, hidden, taxable, "autoSetup", "autoSuspend", "autoTerminate", "customizeOption", "paymentType", "requiresDomain", "allowAutoRenew", "billingCycles", "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceAddon; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServiceAddon" (id, "serviceId", name, description, code, "setupFee", "monthlyPrice", currency, "maxQuantity", required, recurring, "billingType", active, "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceAddonPricing; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServiceAddonPricing" (id, "addonId", cycle, price, "setupFee", "renewalPrice", currency) FROM stdin;
\.


--
-- Data for Name: ServiceAutomation; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServiceAutomation" (id, "serviceId", event, action, module, "provisioningKey", "webhookUrl", "emailTemplate", config, enabled, priority, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceConfiguration; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServiceConfiguration" (id, "serviceId", key, value, "valueType", description) FROM stdin;
\.


--
-- Data for Name: ServiceFeature; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServiceFeature" (id, "serviceId", key, name, description, type, unit, icon, category, active, "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceGroup; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServiceGroup" (id, name, slug, description, icon, "position", active, hidden, "createdAt", "updatedAt") FROM stdin;
12ab8584-9a11-4471-b851-02ef881e6cff	hammad	hammad	\N	\N	0	t	f	2026-03-20 11:29:35.463	2026-03-20 11:29:35.463
\.


--
-- Data for Name: ServicePlan; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServicePlan" (id, "serviceId", name, summary, description, "paymentType", "minimumBillingCycles", "maximumBillingCycles", "allowAutoSetup", "customizeOption", "showDomainOptions", "maxClients", "maxOrders", "maxQuantity", "stockLimit", active, hidden, "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServicePlanAddon; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServicePlanAddon" (id, "planId", "addonId", included, quantity) FROM stdin;
\.


--
-- Data for Name: ServicePlanAutomation; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServicePlanAutomation" (id, "planId", event, action, config, enabled) FROM stdin;
\.


--
-- Data for Name: ServicePlanConfiguration; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServicePlanConfiguration" (id, "planId", key, value) FROM stdin;
\.


--
-- Data for Name: ServicePlanFeature; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServicePlanFeature" (id, "planId", "featureId", value) FROM stdin;
\.


--
-- Data for Name: ServicePlanPolicy; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServicePlanPolicy" (id, "planId", key, name, value) FROM stdin;
\.


--
-- Data for Name: ServicePolicy; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServicePolicy" (id, "serviceId", key, name, value, "valueType", description, enforced) FROM stdin;
\.


--
-- Data for Name: ServicePricing; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServicePricing" (id, "planId", cycle, "setupFee", price, "renewalPrice", "suspensionFee", "terminationFee", currency, "discountType", "discountAmount", "discountValidUntil", taxable, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceSnapshot; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServiceSnapshot" (id, "planId", service, "planData", pricing, features, addons, policies, automations, "capturedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceTemplate; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServiceTemplate" (id, name, description, category, config, plans, addons, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceUpgradePath; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."ServiceUpgradePath" (id, "serviceId", "fromPlanId", "toPlanId", allowed, prorated, "creditUnused", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Session" (id, "userId", token, "userAgent", ip, "createdAt", "expiresAt", "isImpersonation", "impersonatorId", "impersonationReason", "updatedAt", country, "deviceHash", "lastActivity") FROM stdin;
25cc4fa9-f1e3-469d-8e61-32ac0a54e022	61bc7bb7-12e8-42a4-bffe-f7a7d9d95254	5c93ab34ffce91eb34a9d1e44980dbc6de85ab5c9e78f62174acb55eb313c98c46eae6fadf4c27ad3f4d07c1481a60df	seed.client.js	127.0.0.1	2026-03-09 00:04:59.84	2026-03-10 00:04:59.838	f	\N	\N	2026-03-09 00:04:59.84	\N	\N	2026-03-09 00:04:59.84
21c72c93-a7cc-4c6a-861b-f2753a46846b	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpYXQiOjE3NzMwMTk1MDgsImV4cCI6MTc3MzAyMDQwOH0.Kn43oSNxhq4FkvcHzaOwa-UOC4yIYJfZStFhED9Kvz8	TestSuite/1.0	::ffff:127.0.0.1	2026-03-09 01:25:08.639	2026-03-10 01:25:08.638	f	\N	\N	2026-03-09 01:25:09.467	Unknown	6ddd5b8f238ef8aa9e1ae7326185e8f4eddf06ac296642d001835e546d408bf8	2026-03-09 01:25:09.466
875ddef1-4283-46e5-9c29-e611bda72e41	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpYXQiOjE3NzM5MjUxODcsImV4cCI6MTc3MzkyNjA4N30.obkqwysPP5ygMIxsCAQXx5bYV5sbjM-qsTJ2w6eDjy4	ServiceOrderTestSuite/1.0	::ffff:127.0.0.1	2026-03-19 12:59:47.806	2026-03-20 12:59:47.806	f	\N	\N	2026-03-19 12:59:53.956	Unknown	f859f34f80f967e0e71b7d1e2732ae31b3e4c9235cb1848a18f56c3d17979397	2026-03-19 12:59:53.955
7c39b19e-b4ae-49ae-b2f4-7ae7c8cc7d14	ea27b74d-bb76-4789-b18b-0686c0f07a62	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJlYTI3Yjc0ZC1iYjc2LTQ3ODktYjE4Yi0wNjg2YzBmMDdhNjIiLCJpYXQiOjE3NzQxMDA5NzEsImV4cCI6MTc3NDEwMTg3MX0.YwD03tgr_1eFE5qXK3OmOsvpPHSzVN4aHPlq4SQPzCM	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	192.168.100.214	2026-03-21 13:49:31.744	2026-03-22 13:49:31.743	f	\N	\N	2026-03-21 13:49:31.744	Unknown	1a73d2a5935b4e8f34795bad3f2d3294640e93ae85a8ab345296a3415d0f00ff	2026-03-21 13:49:31.743
695bf21a-ef6e-4a20-bb69-889238118ec2	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpYXQiOjE3NzMwMTkwMTEsImV4cCI6MTc3MzAxOTkxMX0.-z0HLxnwX4I7B7hKv15d7EHDiJ7iuvlrRMJti_fvMTY	\N	::ffff:127.0.0.1	2026-03-09 01:16:51.286	2026-03-10 01:16:51.285	f	\N	\N	2026-03-09 01:16:51.286	Unknown	5704edd074e9c212893f0aacd3ccb4ea052539cb69bd3f923d88aab5ed5844f1	2026-03-09 01:16:51.285
6d364e2c-2239-4e4a-9e24-627be83ae1dd	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpYXQiOjE3NzM2NTI2MTcsImV4cCI6MTc3MzY1MzUxN30.Aa9t4GzI4_k6LLlaBY7cznyBUQ_OvIVQAJ2p_rlHeaI	TestSuite/2.0	::ffff:127.0.0.1	2026-03-16 09:16:57.187	2026-03-17 09:16:57.186	f	\N	\N	2026-03-16 09:16:58.754	Unknown	14030ef2e42764166e08bc2a371b934e9a54fa3821b6a2fc08f27ae779bee57e	2026-03-16 09:16:58.752
0963c27c-d0d9-4a72-a3cb-995e513ee466	ea27b74d-bb76-4789-b18b-0686c0f07a62	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJlYTI3Yjc0ZC1iYjc2LTQ3ODktYjE4Yi0wNjg2YzBmMDdhNjIiLCJpYXQiOjE3NzQxMDU4NjUsImV4cCI6MTc3NDEwNjc2NX0.w6SByzXOb2ktAVN3XcT_YVx7EbSiXomEWoEiqO36Z5I	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	127.0.0.1	2026-03-21 15:11:05.987	2026-03-22 15:11:05.986	f	\N	\N	2026-03-21 15:20:16.841	Local	17929705fd7e37f979c0812c25319b69a808fbc971d477ebed0c4a9d7f31457c	2026-03-21 15:20:16.84
f1f76343-da1d-42e5-9765-f230cbabc0b9	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDA5NzUwNiwiZXhwIjoxNzc0MDk4NDA2fQ.oqWvOrhUssau_9lCyRv1y5GfluitakJBoD_EApjqqUE	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-21 12:51:46.463	2026-03-21 13:51:46.462	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	b	2026-03-21 12:52:33.301	\N	\N	2026-03-21 12:52:33.3
16cdde32-9ca3-4f8b-a908-bd980643401e	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAwNjY3MCwiZXhwIjoxNzc0NjExNDcwfQ.L8GhqGQCeOnxgHCVMLNmBaERhNmfaavccCJuBjN4yv4	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 11:37:50.787	2026-03-20 12:37:50.786	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	b	2026-03-20 11:37:50.787	\N	\N	2026-03-20 11:37:50.787
f1f5c828-bff9-4eaa-8789-315febc13944	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAwOTcyNiwiZXhwIjoxNzc0MDEwNjI2fQ.7DvpJtdcUWqKDEhbaL3_Jor0p8a5M8jdWbNq9cwLJVs	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 12:28:46.96	2026-03-20 13:28:46.957	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	ccc	2026-03-20 12:30:18.359	\N	\N	2026-03-20 12:30:18.358
913c26b3-627e-4e23-846b-37425400cc51	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAwNDU5MywiZXhwIjoxNzc0NjA5MzkzfQ.EuThLemT7G3HPBHGUKRjrI4c7cU_116i6AjVpIoBWcY	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 11:03:13.897	2026-03-20 12:03:13.896	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	xxxxxxx	2026-03-20 11:03:13.897	\N	\N	2026-03-20 11:03:13.897
f1404b3a-1937-4c3a-86c1-a4a0ffd9a9a8	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpYXQiOjE3NzM5MDM2MjEsImV4cCI6MTc3MzkwNDUyMX0.kwP5Nfjs_pAvmduCD7i-nLZPI59DDXJbITozazGhmW0	curl/8.5.0	::1	2026-03-19 07:00:21.886	2026-03-20 07:00:21.885	f	\N	\N	2026-03-19 07:00:22.28	Unknown	a5f8a0759cab09873b4d361c6434b5ec3ba3036ae022c2681626f834f924934f	2026-03-19 07:00:22.279
8301e612-c5b1-4642-b2f6-8766a28118ee	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAwOTk0MywiZXhwIjoxNzc0MDEwODQzfQ.CIjhtuIWd-x4y6Qcpqoa-MaD_QLOcsKEx3zH8AvDGKg	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	::1	2026-03-20 12:32:23.049	2026-03-20 13:32:23.047	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	hammad	2026-03-20 12:32:29.215	\N	\N	2026-03-20 12:32:29.214
e3635940-e9ac-45ec-ba45-9956c6540edc	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpYXQiOjE3NzM5Njc3OTgsImV4cCI6MTc3Mzk2ODY5OH0.RSAu7Bgygf1xZlhcfgYvGUHbPlGScmgx-Z98CY9pMJg	BillingTestSuite/1.0	::ffff:127.0.0.1	2026-03-20 00:49:58.983	2026-03-21 00:49:58.982	f	\N	\N	2026-03-20 00:50:16.571	Unknown	75bbed52eded75bb135ed3865e81162b5bf0cc4dff551ff572e98f6b5949b6fe	2026-03-20 00:50:16.57
13f6c019-82fc-46cd-b14a-cf8ff2c39094	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpYXQiOjE3NzQwOTc4MzgsImV4cCI6MTc3NDA5ODczOH0.7mFKRelWfBy6heFU5AUfHj53VuxRico4RhTyGepKRO8	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	::1	2026-03-21 12:57:18.152	2026-03-22 12:57:18.151	f	\N	\N	2026-03-21 12:59:11.513	Unknown	0a4f5f6fae3d91a962a6094c4a24f4be23afec356d3ea6d622f08c3ac352ddb6	2026-03-21 12:59:11.512
4e04a8eb-499e-450f-ba8c-4ad601b245e4	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAwODk1NywiZXhwIjoxNzc0NjEzNzU3fQ.xwB9ElQ-aJNFE96A14srmPJQMMegNjPysXp6nSXDwaA	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 12:15:57.251	2026-03-20 13:15:57.25	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	vv	2026-03-20 12:15:57.251	\N	\N	2026-03-20 12:15:57.251
faf03757-32a6-4ada-943b-ae12927fa74d	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAwOTI1MiwiZXhwIjoxNzc0MDEwMTUyfQ.08HrhqhOdFkEJYOEwc3pp9TFyWUGdBOf9SSUayZqX5k	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 12:20:52.025	2026-03-20 13:20:52.024	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	bbb	2026-03-20 12:26:23.651	\N	\N	2026-03-20 12:26:23.65
634186dd-6648-4162-bea6-16069787dfff	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpYXQiOjE3NzM4MjAxNjYsImV4cCI6MTc3MzgyMTA2Nn0.ktbSTskh4EdW-F7yj_ir9z_wgu9LMedZT0OuLTuP_LE	TestSuite/3.0	::ffff:127.0.0.1	2026-03-18 07:49:26.595	2026-03-19 07:49:26.594	f	\N	\N	2026-03-18 07:49:29.622	Unknown	81832d7262503e7a7f3cf6893d4f2ac77a30bcae4b76e36b49d1c814411a145d	2026-03-18 07:49:29.621
cb8d6fa8-af02-48bd-8fc5-ce1e8295e3f1	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAwOTE3OCwiZXhwIjoxNzc0MDEwMDc4fQ.Vpks7iVJnv6qNX9TJvEPS8iQ7yNXgjGkHVtJ7CM2e7s	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 12:19:38.105	2026-03-20 13:19:38.104	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	vvv	2026-03-20 12:19:38.105	\N	\N	2026-03-20 12:19:38.105
6c20aba5-98d0-45c6-93cc-73571002b5d7	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpYXQiOjE3NzM4MjA2ODUsImV4cCI6MTc3MzgyMTU4NX0.sa2H121oQxIUE-0_56agyNDUXkdQXpreYc3HoCy2N2g	TestSuite/4.0	::ffff:127.0.0.1	2026-03-18 07:58:05.239	2026-03-19 07:58:05.238	f	\N	\N	2026-03-18 07:58:05.433	Unknown	b6e92062561fd3f808909a7c3f8b43920373fed053f9dc6ddc9f07b05fbc8114	2026-03-18 07:58:05.431
65609989-b4d5-41da-aaa5-fe171449bdc0	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAxMDQxNiwiZXhwIjoxNzc0MDExMzE2fQ.HGHK4ExfIaAFSg0quTk2hv-ync9xfsJU0GYmdqaUU-U	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 12:40:16.246	2026-03-20 13:40:16.245	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	nnn	2026-03-20 12:40:16.246	\N	\N	2026-03-20 12:40:16.246
2caccf90-9ed2-4f76-a3fe-e3c4def9b2d6	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAxMDc1NSwiZXhwIjoxNzc0MDExNjU1fQ.qkeSR8HWQqGO_wk8O7Pov3ihjXXG6IDxW0I3rxoVP5s	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 12:45:55.975	2026-03-20 13:45:55.974	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	hammad	2026-03-20 12:46:10.376	\N	\N	2026-03-20 12:46:10.375
e022f617-9896-4a86-ad1e-a742d1bed06c	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAxMDcxOSwiZXhwIjoxNzc0MDExNjE5fQ.S7NrsffHvyWXfi-EIufYUFHzm3_A68s8eqb4OK625Pg	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 12:45:19.01	2026-03-20 13:45:19.009	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	c	2026-03-20 12:45:19.811	\N	\N	2026-03-20 12:45:19.81
9aefa663-bd9a-49dc-bebe-7973210fe1ee	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAwNjUzMSwiZXhwIjoxNzc0NjExMzMxfQ.9vW3iWE4U68o62IsUOPDbIILQOs3npDHtlPj_-Oyk4I	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 11:35:31.034	2026-03-20 12:35:31.033	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	fahad	2026-03-20 11:35:31.034	\N	\N	2026-03-20 11:35:31.034
e841b562-479d-430c-b5db-e07b7364586e	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAwNjU0MywiZXhwIjoxNzc0NjExMzQzfQ.beuKynFw7kGrpKYba9m03fPW6dx8n3-TOcPzUO9_rjQ	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	::ffff:127.0.0.1	2026-03-20 11:35:43.045	2026-03-20 12:35:43.044	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	bb	2026-03-20 11:35:43.045	\N	\N	2026-03-20 11:35:43.045
b4af77dc-7a04-4ba3-8eea-2c40822b9f1b	75be047c-38b6-4cfc-aa3b-3c996c67755d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NWJlMDQ3Yy0zOGI2LTRjZmMtYWEzYi0zYzk5NmM2Nzc1NWQiLCJpbXBlcnNvbmF0b3JJZCI6ImVhMjdiNzRkLWJiNzYtNDc4OS1iMThiLTA2ODZjMGYwN2E2MiIsImlhdCI6MTc3NDAxMTI1MCwiZXhwIjoxNzc0MDEyMTUwfQ.zUDIbO-YBB8n63RGwOPYgCxD6IkNsGITJAkbSiWeaJs	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	::1	2026-03-20 12:54:10.672	2026-03-20 13:54:10.671	t	ea27b74d-bb76-4789-b18b-0686c0f07a62	hammad	2026-03-20 12:54:12.013	\N	\N	2026-03-20 12:54:12.012
\.


--
-- Data for Name: StorageConfig; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."StorageConfig" (id, name, provider, config, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TaxRule; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."TaxRule" (id, name, rate, country, region, "serviceType", active, "createdAt", "updatedAt") FROM stdin;
2	Pakistan Sales Tax - Hosting	0.1700	PK	\N	hosting	t	2026-03-19 14:37:00.785	2026-03-19 14:37:00.785
1	Standard GST	0.1800	\N	\N	\N	t	2026-03-19 14:37:00.682	2026-03-19 14:37:01.16
3	Tax Exempt	0.0000	AE	\N	\N	t	2026-03-19 14:37:01.57	2026-03-19 14:37:01.57
4	Max Tax	1.0000	\N	\N	\N	t	2026-03-19 14:37:01.677	2026-03-19 14:37:01.677
6	Pakistan Sales Tax - Hosting	0.1700	PK	\N	hosting	t	2026-03-20 00:24:24.438	2026-03-20 00:24:24.438
5	Standard GST	0.1800	\N	\N	\N	t	2026-03-20 00:24:24.326	2026-03-20 00:24:24.832
7	Tax Exempt	0.0000	AE	\N	\N	t	2026-03-20 00:24:25.13	2026-03-20 00:24:25.13
8	Max Tax	1.0000	\N	\N	\N	t	2026-03-20 00:24:25.19	2026-03-20 00:24:25.19
10	Pakistan Sales Tax - Hosting	0.1700	PK	\N	hosting	t	2026-03-20 00:50:00.942	2026-03-20 00:50:00.942
9	Standard GST	0.1800	\N	\N	\N	t	2026-03-20 00:50:00.806	2026-03-20 00:50:01.33
11	Tax Exempt	0.0000	AE	\N	\N	t	2026-03-20 00:50:01.734	2026-03-20 00:50:01.734
12	Max Tax	1.0000	\N	\N	\N	t	2026-03-20 00:50:01.836	2026-03-20 00:50:01.836
\.


--
-- Data for Name: Ticket; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."Ticket" (id, subject, priority, status, "createdAt", category, "closedAt", description, "ticketCode", "updatedAt", "userId") FROM stdin;
\.


--
-- Data for Name: TicketReply; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."TicketReply" (id, "ticketId", "createdBy", message, "createdAt") FROM stdin;
\.


--
-- Data for Name: TrustedDevice; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."TrustedDevice" (id, "userId", "deviceId", "userAgent", ip, name, "createdAt", "lastUsedAt", "expiresAt", revoked) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."User" (id, email, "createdAt", "updatedAt", "emailVerified", "mfaBackupCodes", "mfaEnabled", "mfaSecret", "passwordHash", disabled) FROM stdin;
ea27b74d-bb76-4789-b18b-0686c0f07a62	superadmin@example.com	2026-03-09 00:04:49.91	2026-03-09 00:04:49.91	t	{}	f	\N	$2b$12$T1TX/Qi4PWIS2nN3k3uZj.6ABMz9itSiffaqeKmpE6NghikYyJtsC	f
61bc7bb7-12e8-42a4-bffe-f7a7d9d95254	client.test@example.com	2026-03-09 00:04:59.794	2026-03-09 00:04:59.794	t	{}	f	\N	$2b$12$W7BLhbJ7395F53q8yYQlCe7WWPn0xKLZ.A664Qx/TckKYNLShgG4O	f
75be047c-38b6-4cfc-aa3b-3c996c67755d	ihammad317@gmail.com	2026-03-09 00:06:52.661	2026-03-09 00:06:52.661	f	{}	f	\N	$2b$12$JkQUt9c./ld.DyPd.cNk/Orr.b3EBYjNA5s5gY1cvgZOvMiVzsHFG	f
0fbbe234-25b6-45ee-857e-9c9c4745b443	hammaduk63@gmail.com	2026-03-21 13:02:41.605	2026-03-21 13:02:41.605	f	{}	f	\N	$2b$12$doHJql2BoHPPmP88ZReT5uNILwxA1rvL7ELO82xxRmjoO0ngWzaAS	f
\.


--
-- Data for Name: UserRole; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."UserRole" (id, "userId", "roleId") FROM stdin;
162217f1-b258-45d8-ac7a-c36660cc76c4	ea27b74d-bb76-4789-b18b-0686c0f07a62	ecab2330-28d0-43c0-b416-15297a2769de
84cbc953-e593-4a05-91f3-123ce11e8aeb	61bc7bb7-12e8-42a4-bffe-f7a7d9d95254	b6d94912-57ad-49f5-902f-292d3e64307d
fdb58a1e-0223-4a6e-8709-02d0fd681d9f	75be047c-38b6-4cfc-aa3b-3c996c67755d	b6d94912-57ad-49f5-902f-292d3e64307d
54c11ebc-8338-428a-ac02-2191f6691ec7	0fbbe234-25b6-45ee-857e-9c9c4745b443	b6d94912-57ad-49f5-902f-292d3e64307d
\.


--
-- Data for Name: WebhookEvent; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."WebhookEvent" (id, event, data, processed, "createdAt") FROM stdin;
\.


--
-- Data for Name: WorkflowRun; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."WorkflowRun" (id, "workflowId", status, "triggeredBy", input, output, "startedAt", "finishedAt", "errorMessage", "errorStack", "totalDuration", "successCount", "failureCount", "taskCount", "skippedCount", "createdAt", "triggerId") FROM stdin;
acf0a694-f6d9-42bc-bc7a-c88786096cec	16626035-2c5b-407d-8ee7-502c8a574030	failed	manual	{}	null	2026-03-21 14:55:50.795	2026-03-21 14:55:50.812	Workflow validation failed: / must have required property 'name', /tasks/0 must have required property 'type', /tasks/1 must have required property 'type', /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/2 must have required property 'type'	\N	1	0	0	0	0	2026-03-21 14:55:50.796	\N
d8f369a9-bcc3-4a96-a349-8872c05268ca	16626035-2c5b-407d-8ee7-502c8a574030	failed	manual	{}	null	2026-03-21 15:09:14.63	2026-03-21 15:09:14.657	Workflow validation failed: / must have required property 'name', /tasks/0 must have required property 'type', /tasks/1 must have required property 'type', /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/2 must have required property 'type'	\N	4	0	0	0	0	2026-03-21 15:09:14.632	\N
b8362743-bde1-4c11-8f4d-aa3df6155549	9a8ffd58-6468-48dc-bcb6-23113569ed63	failed	manual	{}	null	2026-03-21 15:09:19.637	2026-03-21 15:09:19.657	Workflow validation failed: / must have required property 'name', /tasks/0 must have required property 'type', /tasks/1/condition must be string, /tasks/2 must have required property 'type', /tasks/2 must NOT have additional properties, /tasks/2 must NOT have additional properties, /tasks/2 must NOT have additional properties, /tasks/2 must NOT have additional properties, /tasks/3 must have required property 'type'	\N	1	0	0	0	0	2026-03-21 15:09:19.639	\N
19e7e5d0-b2f4-42e1-913b-1ed3ec15bea0	7a17222e-f68c-488d-96a1-2bc16ee2baeb	failed	manual	{}	null	2026-03-21 15:09:22.536	2026-03-21 15:09:22.562	Workflow validation failed: / must have required property 'name', /tasks/0/condition must be string, /tasks/0/onFalse must be string, /tasks/1 must have required property 'type'	\N	1	0	0	0	0	2026-03-21 15:09:22.537	\N
b4522a51-c6c9-446a-9424-870a9d25a20f	c50be1a9-d00a-4acf-b9b9-50ada3c8e3da	failed	manual	{}	null	2026-03-21 15:09:28.985	2026-03-21 15:09:29.006	Workflow validation failed: / must have required property 'name', /tasks/0 must have required property 'type', /tasks/1 must have required property 'type', /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties	\N	0	0	0	0	0	2026-03-21 15:09:28.987	\N
cf21cc64-0831-4848-8c5c-d55abad6378c	ce53083a-c32b-4947-bff8-14291cd27a9d	failed	manual	{}	null	2026-03-21 15:09:31.39	2026-03-21 15:09:31.411	Workflow validation failed: / must have required property 'name', /tasks/0 must have required property 'type', /tasks/1 must have required property 'type', /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/1 must NOT have additional properties, /tasks/2 must have required property 'type'	\N	2	0	0	0	0	2026-03-21 15:09:31.392	\N
\.


--
-- Data for Name: WorkflowTaskRun; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."WorkflowTaskRun" (id, "runId", "taskId", status, "retryCount", "maxRetries", "startedAt", "finishedAt", duration, output, "errorMessage", "errorStack", "conditionResult", "selectedPath", "nextRetryAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: WorkflowTriggerRule; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public."WorkflowTriggerRule" (id, "workflowId", "eventType", enabled, conditions, "passEventAsInput", "inputMapping", "createdAt", "updatedAt") FROM stdin;
cf963531-df4b-4193-96f8-8a2a27cdc3e2	ce53083a-c32b-4947-bff8-14291cd27a9d	order.created	t	\N	t	\N	2026-03-21 14:44:40.759	2026-03-21 14:44:40.759
3d9d5db7-f273-463e-b010-17dea0d5f5a2	c50be1a9-d00a-4acf-b9b9-50ada3c8e3da	payment.received	t	\N	t	\N	2026-03-21 14:44:40.788	2026-03-21 14:44:40.788
8df03a3e-6897-45f4-a114-6d4e6e47e768	7a17222e-f68c-488d-96a1-2bc16ee2baeb	service.expiring	t	\N	t	\N	2026-03-21 14:44:40.818	2026-03-21 14:44:40.818
13dbc0a9-b742-4aa8-b430-73ff8dd7fce5	9a8ffd58-6468-48dc-bcb6-23113569ed63	payment.failed	t	\N	t	\N	2026-03-21 14:44:40.854	2026-03-21 14:44:40.854
7b293c8b-cc93-4900-9e5b-84391ad548e5	16626035-2c5b-407d-8ee7-502c8a574030	client.registered	t	\N	t	\N	2026-03-21 14:44:40.891	2026-03-21 14:44:40.891
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: whms_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
cce571c4-8c7c-4a7e-9999-a27ff6e6ebff	17d483d281308c192cd02171a3d140f3e2a40b51d761d46742fd131d493a4897	2026-03-08 13:15:34.653163+05	20260216102556_billing	\N	\N	2026-03-08 13:15:33.601163+05	1
1021824b-aaa4-4db5-8d4f-a9fe2ce324ac	0b22e8da0114278e0a2478a3b422ea4aa0eaf78a482d94bd1ec28efbb36de0a8	2026-03-08 13:15:24.383218+05	20251102133357_1	\N	\N	2026-03-08 13:15:23.530999+05	1
2bb738ef-58c4-4bbf-ab13-d1a55a00b4aa	6260f14c44e0f42366297b1ddd694f1bb58813733f61de62d61f1fd8dded4d07	2026-03-18 12:44:16.974683+05	20260318100000_fix_billing_cycle_type		\N	2026-03-18 12:44:16.974683+05	0
9a891b83-bfa6-4984-8ac4-b02d7e9327b7	f778d00637262317531b181af9f7bb00afabf0039ce49d9e0eaeccda529301bd	2026-03-08 13:15:24.828337+05	20251113125544_fix_clientservice	\N	\N	2026-03-08 13:15:24.396334+05	1
8e86633e-208c-45f5-971b-62627780810d	82a48e31e32dd13512671fc9fd00b08f42f3c7b9e35c26ffdee5013a00b48a1a	2026-03-18 12:47:19.132409+05	20260318110000_add_provisioning_module		\N	2026-03-18 12:47:19.132409+05	0
d33574c5-9f55-452a-9e58-30c9dd4a3099	539261c0e62b19c7e760b8a3431cdf98f2e1bbb3ff7d265ebdf3ed48f5056c45	2026-03-08 13:15:25.456548+05	20251117130838_a1	\N	\N	2026-03-08 13:15:24.841069+05	1
f12fbd89-9bb9-42fd-bfcb-5c80649589ea	a41269562fd5cb363ff2ebc64fe821eb80c9f83c1711e36d906dc8704163a8ab	2026-03-08 13:15:25.508714+05	20251117151539_fix_task_run_cascade	\N	\N	2026-03-08 13:15:25.469505+05	1
4a83e457-0b89-40dd-97ad-dea1e140fa3f	6d877e84b2cc9feb7982a52dedb6d9676f5f5f4cab147356956d40b82ce4cc48	2026-03-08 13:15:25.679396+05	20251118110922_plugin_system_upgrade	\N	\N	2026-03-08 13:15:25.521581+05	1
59fca5fd-ee06-4884-b2fd-8cb88ee8d882	32cba262df153a9ab79d87be0f00c227d156c630e8ab69be62c7ee4b3534080c	\N	20260319000000_enhance_services_module	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260319000000_enhance_services_module\n\nDatabase error code: 23502\n\nDatabase error:\nERROR: null value in column "snapshotId" of relation "Order" violates not-null constraint\nDETAIL: Failing row contains (ae271421-57e6-4182-acb2-745b02df72c4, 75be047c-38b6-4cfc-aa3b-3c996c67755d, null, active, 2026-03-09 01:25:08.996, 2026-04-09 01:25:08.996, null, null, null, 2026-03-09 01:25:08.899, 2026-03-09 01:25:08.997, null, null).\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E23502), message: "null value in column \\"snapshotId\\" of relation \\"Order\\" violates not-null constraint", detail: Some("Failing row contains (ae271421-57e6-4182-acb2-745b02df72c4, 75be047c-38b6-4cfc-aa3b-3c996c67755d, null, active, 2026-03-09 01:25:08.996, 2026-04-09 01:25:08.996, null, null, null, 2026-03-09 01:25:08.899, 2026-03-09 01:25:08.997, null, null)."), hint: None, position: None, where_: None, schema: Some("public"), table: Some("Order"), column: Some("snapshotId"), datatype: None, constraint: None, file: Some("execMain.c"), line: Some(2057), routine: Some("ExecConstraints") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260319000000_enhance_services_module"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260319000000_enhance_services_module"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-03-19 10:35:29.05388+05	2026-03-19 10:34:55.425826+05	0
b64f23bb-fcdf-489f-9392-040c677c740b	ed04d033c454d6dfb945872035964c182a89c02d4146787e9401f654eb8baa8e	2026-03-08 13:15:25.738602+05	20251118211942_fix_cascade_delete	\N	\N	2026-03-08 13:15:25.693887+05	1
5650f78d-041d-4e06-8acb-1de7941bf7a5	87bbe3502a0427c1d07e41850f64efddc6ba1c7d612e94e51d8327079bd28114	2026-03-08 13:15:25.789756+05	20251118225417_plugin_marketplace_support	\N	\N	2026-03-08 13:15:25.751308+05	1
7601e539-dcf1-4898-a4d8-5cff7c7246a2	7591952ba249f31243627ecc679176016d14efd15577677a82617d176d8ee040	2026-03-08 13:15:25.941955+05	20251119164909_backup	\N	\N	2026-03-08 13:15:25.802593+05	1
31e2565d-8f6f-4021-aca2-dd8bd7e5e067	45957b13aec103be601115a7ddadbb9e2f40e1fbc492d3acf7018f11eb2db8ae	2026-03-19 10:36:23.979923+05	20260319000000_enhance_services_module	\N	\N	2026-03-19 10:36:21.692958+05	1
deeb4686-7579-4b18-bc60-336d7eed73e3	6a62ea7df3090b1d6d99220905e373a9f2a4bafec809a7de7ec8bf60e2dfea0b	2026-03-08 13:15:29.599799+05	20251203181037_init_auth_rbac	\N	\N	2026-03-08 13:15:25.955295+05	1
41e45870-38f3-4253-8bd9-581242b776b0	dde6116df9de1d7a1272c0e8a5efff805dbab35f7c8d236002af337998652692	2026-03-08 13:15:30.175948+05	20251218175242_linux_init	\N	\N	2026-03-08 13:15:29.612959+05	1
7ef600e4-162f-4639-9453-b095902a1c3f	80e9e8fcc6632497bc5fb5c629d323e7332ee488bfb5cb6ecaaf726967b17922	2026-03-08 13:15:30.71472+05	20251226184151_domain	\N	\N	2026-03-08 13:15:30.18884+05	1
b074d608-0e1d-4d75-8956-b050cc769a96	a6469d378454762a3030ba77409ef2473ebc442b9513cc649c60076243857386	2026-03-08 13:15:30.842687+05	20251227191553_add_services	\N	\N	2026-03-08 13:15:30.727689+05	1
8c0d30cb-2360-4a61-a124-0682ea8023bd	34835f49b37b64d3f4f224060f53cc6123800eb6bba61effdf8559155a99731f	2026-03-08 13:15:33.587533+05	20260105181101_final_demo	\N	\N	2026-03-08 13:15:30.855992+05	1
\.


--
-- Name: AuditLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."AuditLog_id_seq"', 290, true);


--
-- Name: AutomationProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."AutomationProfile_id_seq"', 5, true);


--
-- Name: AutomationRun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."AutomationRun_id_seq"', 8, true);


--
-- Name: AutomationTask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."AutomationTask_id_seq"', 5, true);


--
-- Name: BackupStepLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."BackupStepLog_id_seq"', 3, true);


--
-- Name: BackupVersion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."BackupVersion_id_seq"', 1, false);


--
-- Name: Backup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."Backup_id_seq"', 1, true);


--
-- Name: IpAccessRule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."IpAccessRule_id_seq"', 1, false);


--
-- Name: StorageConfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."StorageConfig_id_seq"', 1, false);


--
-- Name: TaxRule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms_user
--

SELECT pg_catalog.setval('public."TaxRule_id_seq"', 12, true);


--
-- Name: AdminProfile AdminProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AdminProfile"
    ADD CONSTRAINT "AdminProfile_pkey" PRIMARY KEY (id);


--
-- Name: ApiKeyScope ApiKeyScope_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ApiKeyScope"
    ADD CONSTRAINT "ApiKeyScope_pkey" PRIMARY KEY (id);


--
-- Name: ApiKey ApiKey_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: AutomationProfile AutomationProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AutomationProfile"
    ADD CONSTRAINT "AutomationProfile_pkey" PRIMARY KEY (id);


--
-- Name: AutomationRun AutomationRun_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AutomationRun"
    ADD CONSTRAINT "AutomationRun_pkey" PRIMARY KEY (id);


--
-- Name: AutomationTask AutomationTask_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AutomationTask"
    ADD CONSTRAINT "AutomationTask_pkey" PRIMARY KEY (id);


--
-- Name: AutomationWorkflow AutomationWorkflow_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AutomationWorkflow"
    ADD CONSTRAINT "AutomationWorkflow_pkey" PRIMARY KEY (id);


--
-- Name: BackupStepLog BackupStepLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BackupStepLog"
    ADD CONSTRAINT "BackupStepLog_pkey" PRIMARY KEY (id);


--
-- Name: BackupVersion BackupVersion_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BackupVersion"
    ADD CONSTRAINT "BackupVersion_pkey" PRIMARY KEY (id);


--
-- Name: Backup Backup_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Backup"
    ADD CONSTRAINT "Backup_pkey" PRIMARY KEY (id);


--
-- Name: BillingProfile BillingProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BillingProfile"
    ADD CONSTRAINT "BillingProfile_pkey" PRIMARY KEY (id);


--
-- Name: BillingTransaction BillingTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BillingTransaction"
    ADD CONSTRAINT "BillingTransaction_pkey" PRIMARY KEY (id);


--
-- Name: ClientProfile ClientProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_pkey" PRIMARY KEY (id);


--
-- Name: DeveloperProfile DeveloperProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."DeveloperProfile"
    ADD CONSTRAINT "DeveloperProfile_pkey" PRIMARY KEY (id);


--
-- Name: Domain Domain_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_pkey" PRIMARY KEY (id);


--
-- Name: DunningAttempt DunningAttempt_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."DunningAttempt"
    ADD CONSTRAINT "DunningAttempt_pkey" PRIMARY KEY (id);


--
-- Name: EmailToken EmailToken_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."EmailToken"
    ADD CONSTRAINT "EmailToken_pkey" PRIMARY KEY (id);


--
-- Name: HostingAccount HostingAccount_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."HostingAccount"
    ADD CONSTRAINT "HostingAccount_pkey" PRIMARY KEY (id);


--
-- Name: HostingDatabase HostingDatabase_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."HostingDatabase"
    ADD CONSTRAINT "HostingDatabase_pkey" PRIMARY KEY (id);


--
-- Name: HostingDomain HostingDomain_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."HostingDomain"
    ADD CONSTRAINT "HostingDomain_pkey" PRIMARY KEY (id);


--
-- Name: HostingEmail HostingEmail_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."HostingEmail"
    ADD CONSTRAINT "HostingEmail_pkey" PRIMARY KEY (id);


--
-- Name: Impersonation Impersonation_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Impersonation"
    ADD CONSTRAINT "Impersonation_pkey" PRIMARY KEY (id);


--
-- Name: IncomingWebhook IncomingWebhook_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."IncomingWebhook"
    ADD CONSTRAINT "IncomingWebhook_pkey" PRIMARY KEY (id);


--
-- Name: InvoiceDiscount InvoiceDiscount_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."InvoiceDiscount"
    ADD CONSTRAINT "InvoiceDiscount_pkey" PRIMARY KEY (id);


--
-- Name: InvoiceLineItem InvoiceLineItem_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."InvoiceLineItem"
    ADD CONSTRAINT "InvoiceLineItem_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: IpAccessRule IpAccessRule_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."IpAccessRule"
    ADD CONSTRAINT "IpAccessRule_pkey" PRIMARY KEY (id);


--
-- Name: LoginLog LoginLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceProduct MarketplaceProduct_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."MarketplaceProduct"
    ADD CONSTRAINT "MarketplaceProduct_pkey" PRIMARY KEY (id);


--
-- Name: MarketplacePurchase MarketplacePurchase_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceReview MarketplaceReview_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."MarketplaceReview"
    ADD CONSTRAINT "MarketplaceReview_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceSubmission MarketplaceSubmission_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: PaymentMethod PaymentMethod_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."PaymentMethod"
    ADD CONSTRAINT "PaymentMethod_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: Refund Refund_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Refund"
    ADD CONSTRAINT "Refund_pkey" PRIMARY KEY (id);


--
-- Name: ResellerProfile ResellerProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ResellerProfile"
    ADD CONSTRAINT "ResellerProfile_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: ServiceAddonPricing ServiceAddonPricing_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceAddonPricing"
    ADD CONSTRAINT "ServiceAddonPricing_pkey" PRIMARY KEY (id);


--
-- Name: ServiceAddon ServiceAddon_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceAddon"
    ADD CONSTRAINT "ServiceAddon_pkey" PRIMARY KEY (id);


--
-- Name: ServiceAutomation ServiceAutomation_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceAutomation"
    ADD CONSTRAINT "ServiceAutomation_pkey" PRIMARY KEY (id);


--
-- Name: ServiceConfiguration ServiceConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceConfiguration"
    ADD CONSTRAINT "ServiceConfiguration_pkey" PRIMARY KEY (id);


--
-- Name: ServiceFeature ServiceFeature_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceFeature"
    ADD CONSTRAINT "ServiceFeature_pkey" PRIMARY KEY (id);


--
-- Name: ServiceGroup ServiceGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceGroup"
    ADD CONSTRAINT "ServiceGroup_pkey" PRIMARY KEY (id);


--
-- Name: ServicePlanAddon ServicePlanAddon_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanAddon"
    ADD CONSTRAINT "ServicePlanAddon_pkey" PRIMARY KEY (id);


--
-- Name: ServicePlanAutomation ServicePlanAutomation_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanAutomation"
    ADD CONSTRAINT "ServicePlanAutomation_pkey" PRIMARY KEY (id);


--
-- Name: ServicePlanConfiguration ServicePlanConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanConfiguration"
    ADD CONSTRAINT "ServicePlanConfiguration_pkey" PRIMARY KEY (id);


--
-- Name: ServicePlanFeature ServicePlanFeature_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanFeature"
    ADD CONSTRAINT "ServicePlanFeature_pkey" PRIMARY KEY (id);


--
-- Name: ServicePlanPolicy ServicePlanPolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanPolicy"
    ADD CONSTRAINT "ServicePlanPolicy_pkey" PRIMARY KEY (id);


--
-- Name: ServicePlan ServicePlan_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlan"
    ADD CONSTRAINT "ServicePlan_pkey" PRIMARY KEY (id);


--
-- Name: ServicePolicy ServicePolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePolicy"
    ADD CONSTRAINT "ServicePolicy_pkey" PRIMARY KEY (id);


--
-- Name: ServicePricing ServicePricing_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePricing"
    ADD CONSTRAINT "ServicePricing_pkey" PRIMARY KEY (id);


--
-- Name: ServiceSnapshot ServiceSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceSnapshot"
    ADD CONSTRAINT "ServiceSnapshot_pkey" PRIMARY KEY (id);


--
-- Name: ServiceTemplate ServiceTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceTemplate"
    ADD CONSTRAINT "ServiceTemplate_pkey" PRIMARY KEY (id);


--
-- Name: ServiceUpgradePath ServiceUpgradePath_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceUpgradePath"
    ADD CONSTRAINT "ServiceUpgradePath_pkey" PRIMARY KEY (id);


--
-- Name: Service Service_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: StorageConfig StorageConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."StorageConfig"
    ADD CONSTRAINT "StorageConfig_pkey" PRIMARY KEY (id);


--
-- Name: TaxRule TaxRule_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."TaxRule"
    ADD CONSTRAINT "TaxRule_pkey" PRIMARY KEY (id);


--
-- Name: TicketReply TicketReply_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."TicketReply"
    ADD CONSTRAINT "TicketReply_pkey" PRIMARY KEY (id);


--
-- Name: Ticket Ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_pkey" PRIMARY KEY (id);


--
-- Name: TrustedDevice TrustedDevice_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."TrustedDevice"
    ADD CONSTRAINT "TrustedDevice_pkey" PRIMARY KEY (id);


--
-- Name: UserRole UserRole_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."UserRole"
    ADD CONSTRAINT "UserRole_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WebhookEvent WebhookEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."WebhookEvent"
    ADD CONSTRAINT "WebhookEvent_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowRun WorkflowRun_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."WorkflowRun"
    ADD CONSTRAINT "WorkflowRun_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowTaskRun WorkflowTaskRun_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."WorkflowTaskRun"
    ADD CONSTRAINT "WorkflowTaskRun_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowTriggerRule WorkflowTriggerRule_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."WorkflowTriggerRule"
    ADD CONSTRAINT "WorkflowTriggerRule_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AdminProfile_userId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "AdminProfile_userId_key" ON public."AdminProfile" USING btree ("userId");


--
-- Name: AuditLog_profileId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "AuditLog_profileId_idx" ON public."AuditLog" USING btree ("profileId");


--
-- Name: AutomationWorkflow_slug_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "AutomationWorkflow_slug_key" ON public."AutomationWorkflow" USING btree (slug);


--
-- Name: BackupStepLog_backupId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "BackupStepLog_backupId_idx" ON public."BackupStepLog" USING btree ("backupId");


--
-- Name: BackupVersion_backupId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "BackupVersion_backupId_idx" ON public."BackupVersion" USING btree ("backupId");


--
-- Name: Backup_createdAt_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Backup_createdAt_idx" ON public."Backup" USING btree ("createdAt");


--
-- Name: Backup_createdById_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Backup_createdById_idx" ON public."Backup" USING btree ("createdById");


--
-- Name: Backup_status_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Backup_status_idx" ON public."Backup" USING btree (status);


--
-- Name: BillingProfile_clientId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "BillingProfile_clientId_key" ON public."BillingProfile" USING btree ("clientId");


--
-- Name: BillingTransaction_clientId_createdAt_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "BillingTransaction_clientId_createdAt_idx" ON public."BillingTransaction" USING btree ("clientId", "createdAt");


--
-- Name: BillingTransaction_clientId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "BillingTransaction_clientId_idx" ON public."BillingTransaction" USING btree ("clientId");


--
-- Name: BillingTransaction_createdAt_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "BillingTransaction_createdAt_idx" ON public."BillingTransaction" USING btree ("createdAt");


--
-- Name: BillingTransaction_invoiceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "BillingTransaction_invoiceId_idx" ON public."BillingTransaction" USING btree ("invoiceId");


--
-- Name: BillingTransaction_type_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "BillingTransaction_type_idx" ON public."BillingTransaction" USING btree (type);


--
-- Name: ClientProfile_userId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ClientProfile_userId_key" ON public."ClientProfile" USING btree ("userId");


--
-- Name: DeveloperProfile_userId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "DeveloperProfile_userId_key" ON public."DeveloperProfile" USING btree ("userId");


--
-- Name: Domain_domain_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "Domain_domain_key" ON public."Domain" USING btree (domain);


--
-- Name: Domain_userId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Domain_userId_idx" ON public."Domain" USING btree ("userId");


--
-- Name: DunningAttempt_invoiceId_action_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "DunningAttempt_invoiceId_action_idx" ON public."DunningAttempt" USING btree ("invoiceId", action);


--
-- Name: DunningAttempt_invoiceId_attemptNumber_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "DunningAttempt_invoiceId_attemptNumber_idx" ON public."DunningAttempt" USING btree ("invoiceId", "attemptNumber");


--
-- Name: DunningAttempt_invoiceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "DunningAttempt_invoiceId_idx" ON public."DunningAttempt" USING btree ("invoiceId");


--
-- Name: DunningAttempt_status_attemptedAt_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "DunningAttempt_status_attemptedAt_idx" ON public."DunningAttempt" USING btree (status, "attemptedAt");


--
-- Name: HostingAccount_clientId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "HostingAccount_clientId_idx" ON public."HostingAccount" USING btree ("clientId");


--
-- Name: HostingAccount_orderId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "HostingAccount_orderId_idx" ON public."HostingAccount" USING btree ("orderId");


--
-- Name: HostingAccount_orderId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "HostingAccount_orderId_key" ON public."HostingAccount" USING btree ("orderId");


--
-- Name: HostingAccount_status_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "HostingAccount_status_idx" ON public."HostingAccount" USING btree (status);


--
-- Name: HostingAccount_username_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "HostingAccount_username_key" ON public."HostingAccount" USING btree (username);


--
-- Name: HostingDatabase_hostingAccountId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "HostingDatabase_hostingAccountId_idx" ON public."HostingDatabase" USING btree ("hostingAccountId");


--
-- Name: HostingDatabase_hostingAccountId_name_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "HostingDatabase_hostingAccountId_name_key" ON public."HostingDatabase" USING btree ("hostingAccountId", name);


--
-- Name: HostingDomain_hostingAccountId_domain_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "HostingDomain_hostingAccountId_domain_key" ON public."HostingDomain" USING btree ("hostingAccountId", domain);


--
-- Name: HostingDomain_hostingAccountId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "HostingDomain_hostingAccountId_idx" ON public."HostingDomain" USING btree ("hostingAccountId");


--
-- Name: HostingEmail_hostingAccountId_email_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "HostingEmail_hostingAccountId_email_key" ON public."HostingEmail" USING btree ("hostingAccountId", email);


--
-- Name: HostingEmail_hostingAccountId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "HostingEmail_hostingAccountId_idx" ON public."HostingEmail" USING btree ("hostingAccountId");


--
-- Name: Impersonation_sessionToken_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "Impersonation_sessionToken_key" ON public."Impersonation" USING btree ("sessionToken");


--
-- Name: InvoiceDiscount_code_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "InvoiceDiscount_code_idx" ON public."InvoiceDiscount" USING btree (code);


--
-- Name: InvoiceDiscount_invoiceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "InvoiceDiscount_invoiceId_idx" ON public."InvoiceDiscount" USING btree ("invoiceId");


--
-- Name: InvoiceLineItem_invoiceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "InvoiceLineItem_invoiceId_idx" ON public."InvoiceLineItem" USING btree ("invoiceId");


--
-- Name: InvoiceLineItem_snapshotId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "InvoiceLineItem_snapshotId_idx" ON public."InvoiceLineItem" USING btree ("snapshotId");


--
-- Name: Invoice_clientId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Invoice_clientId_idx" ON public."Invoice" USING btree ("clientId");


--
-- Name: Invoice_clientId_invoiceType_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Invoice_clientId_invoiceType_idx" ON public."Invoice" USING btree ("clientId", "invoiceType");


--
-- Name: Invoice_clientId_status_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Invoice_clientId_status_idx" ON public."Invoice" USING btree ("clientId", status);


--
-- Name: Invoice_dueDate_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Invoice_dueDate_idx" ON public."Invoice" USING btree ("dueDate");


--
-- Name: Invoice_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Invoice_invoiceNumber_idx" ON public."Invoice" USING btree ("invoiceNumber");


--
-- Name: Invoice_invoiceNumber_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "Invoice_invoiceNumber_key" ON public."Invoice" USING btree ("invoiceNumber");


--
-- Name: Invoice_invoiceType_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Invoice_invoiceType_idx" ON public."Invoice" USING btree ("invoiceType");


--
-- Name: Invoice_orderId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Invoice_orderId_idx" ON public."Invoice" USING btree ("orderId");


--
-- Name: Invoice_orderId_invoiceType_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Invoice_orderId_invoiceType_idx" ON public."Invoice" USING btree ("orderId", "invoiceType");


--
-- Name: Invoice_status_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Invoice_status_idx" ON public."Invoice" USING btree (status);


--
-- Name: IpAccessRule_active_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "IpAccessRule_active_idx" ON public."IpAccessRule" USING btree (active);


--
-- Name: IpAccessRule_createdById_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "IpAccessRule_createdById_idx" ON public."IpAccessRule" USING btree ("createdById");


--
-- Name: MarketplacePurchase_userId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "MarketplacePurchase_userId_idx" ON public."MarketplacePurchase" USING btree ("userId");


--
-- Name: MarketplaceReview_productId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "MarketplaceReview_productId_idx" ON public."MarketplaceReview" USING btree ("productId");


--
-- Name: MarketplaceReview_userId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "MarketplaceReview_userId_idx" ON public."MarketplaceReview" USING btree ("userId");


--
-- Name: MarketplaceSubmission_userId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "MarketplaceSubmission_userId_idx" ON public."MarketplaceSubmission" USING btree ("userId");


--
-- Name: Order_clientId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Order_clientId_idx" ON public."Order" USING btree ("clientId");


--
-- Name: Order_nextRenewalAt_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Order_nextRenewalAt_idx" ON public."Order" USING btree ("nextRenewalAt");


--
-- Name: Order_status_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Order_status_idx" ON public."Order" USING btree (status);


--
-- Name: PaymentMethod_clientId_gatewayRef_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "PaymentMethod_clientId_gatewayRef_key" ON public."PaymentMethod" USING btree ("clientId", "gatewayRef");


--
-- Name: PaymentMethod_clientId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "PaymentMethod_clientId_idx" ON public."PaymentMethod" USING btree ("clientId");


--
-- Name: PaymentMethod_clientId_isDefault_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "PaymentMethod_clientId_isDefault_idx" ON public."PaymentMethod" USING btree ("clientId", "isDefault");


--
-- Name: PaymentMethod_gateway_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "PaymentMethod_gateway_idx" ON public."PaymentMethod" USING btree (gateway);


--
-- Name: Payment_clientId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Payment_clientId_idx" ON public."Payment" USING btree ("clientId");


--
-- Name: Payment_gatewayRef_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Payment_gatewayRef_idx" ON public."Payment" USING btree ("gatewayRef");


--
-- Name: Payment_invoiceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Payment_invoiceId_idx" ON public."Payment" USING btree ("invoiceId");


--
-- Name: Payment_isAutoCharge_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Payment_isAutoCharge_idx" ON public."Payment" USING btree ("isAutoCharge");


--
-- Name: Payment_paymentMethodId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Payment_paymentMethodId_idx" ON public."Payment" USING btree ("paymentMethodId");


--
-- Name: Payment_status_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Payment_status_idx" ON public."Payment" USING btree (status);


--
-- Name: Permission_key_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "Permission_key_key" ON public."Permission" USING btree (key);


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: Refund_invoiceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Refund_invoiceId_idx" ON public."Refund" USING btree ("invoiceId");


--
-- Name: Refund_paymentId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Refund_paymentId_idx" ON public."Refund" USING btree ("paymentId");


--
-- Name: ResellerProfile_resellerCode_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ResellerProfile_resellerCode_key" ON public."ResellerProfile" USING btree ("resellerCode");


--
-- Name: ResellerProfile_userId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ResellerProfile_userId_key" ON public."ResellerProfile" USING btree ("userId");


--
-- Name: RolePermission_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "RolePermission_roleId_permissionId_key" ON public."RolePermission" USING btree ("roleId", "permissionId");


--
-- Name: Role_name_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "Role_name_key" ON public."Role" USING btree (name);


--
-- Name: ServiceAddonPricing_addonId_cycle_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServiceAddonPricing_addonId_cycle_key" ON public."ServiceAddonPricing" USING btree ("addonId", cycle);


--
-- Name: ServiceAddonPricing_addonId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServiceAddonPricing_addonId_idx" ON public."ServiceAddonPricing" USING btree ("addonId");


--
-- Name: ServiceAddon_active_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServiceAddon_active_idx" ON public."ServiceAddon" USING btree (active);


--
-- Name: ServiceAddon_serviceId_code_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServiceAddon_serviceId_code_key" ON public."ServiceAddon" USING btree ("serviceId", code);


--
-- Name: ServiceAddon_serviceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServiceAddon_serviceId_idx" ON public."ServiceAddon" USING btree ("serviceId");


--
-- Name: ServiceAutomation_event_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServiceAutomation_event_idx" ON public."ServiceAutomation" USING btree (event);


--
-- Name: ServiceAutomation_serviceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServiceAutomation_serviceId_idx" ON public."ServiceAutomation" USING btree ("serviceId");


--
-- Name: ServiceConfiguration_serviceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServiceConfiguration_serviceId_idx" ON public."ServiceConfiguration" USING btree ("serviceId");


--
-- Name: ServiceConfiguration_serviceId_key_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServiceConfiguration_serviceId_key_key" ON public."ServiceConfiguration" USING btree ("serviceId", key);


--
-- Name: ServiceFeature_serviceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServiceFeature_serviceId_idx" ON public."ServiceFeature" USING btree ("serviceId");


--
-- Name: ServiceFeature_serviceId_key_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServiceFeature_serviceId_key_key" ON public."ServiceFeature" USING btree ("serviceId", key);


--
-- Name: ServiceGroup_name_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServiceGroup_name_key" ON public."ServiceGroup" USING btree (name);


--
-- Name: ServiceGroup_slug_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServiceGroup_slug_key" ON public."ServiceGroup" USING btree (slug);


--
-- Name: ServicePlanAddon_addonId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePlanAddon_addonId_idx" ON public."ServicePlanAddon" USING btree ("addonId");


--
-- Name: ServicePlanAddon_planId_addonId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServicePlanAddon_planId_addonId_key" ON public."ServicePlanAddon" USING btree ("planId", "addonId");


--
-- Name: ServicePlanAddon_planId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePlanAddon_planId_idx" ON public."ServicePlanAddon" USING btree ("planId");


--
-- Name: ServicePlanAutomation_planId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePlanAutomation_planId_idx" ON public."ServicePlanAutomation" USING btree ("planId");


--
-- Name: ServicePlanConfiguration_planId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePlanConfiguration_planId_idx" ON public."ServicePlanConfiguration" USING btree ("planId");


--
-- Name: ServicePlanFeature_featureId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePlanFeature_featureId_idx" ON public."ServicePlanFeature" USING btree ("featureId");


--
-- Name: ServicePlanFeature_planId_featureId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServicePlanFeature_planId_featureId_key" ON public."ServicePlanFeature" USING btree ("planId", "featureId");


--
-- Name: ServicePlanFeature_planId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePlanFeature_planId_idx" ON public."ServicePlanFeature" USING btree ("planId");


--
-- Name: ServicePlanPolicy_planId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePlanPolicy_planId_idx" ON public."ServicePlanPolicy" USING btree ("planId");


--
-- Name: ServicePlan_active_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePlan_active_idx" ON public."ServicePlan" USING btree (active);


--
-- Name: ServicePlan_serviceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePlan_serviceId_idx" ON public."ServicePlan" USING btree ("serviceId");


--
-- Name: ServicePlan_serviceId_name_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServicePlan_serviceId_name_key" ON public."ServicePlan" USING btree ("serviceId", name);


--
-- Name: ServicePolicy_serviceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePolicy_serviceId_idx" ON public."ServicePolicy" USING btree ("serviceId");


--
-- Name: ServicePolicy_serviceId_key_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServicePolicy_serviceId_key_key" ON public."ServicePolicy" USING btree ("serviceId", key);


--
-- Name: ServicePricing_active_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePricing_active_idx" ON public."ServicePricing" USING btree (active);


--
-- Name: ServicePricing_planId_cycle_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServicePricing_planId_cycle_key" ON public."ServicePricing" USING btree ("planId", cycle);


--
-- Name: ServicePricing_planId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServicePricing_planId_idx" ON public."ServicePricing" USING btree ("planId");


--
-- Name: ServiceSnapshot_planId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServiceSnapshot_planId_idx" ON public."ServiceSnapshot" USING btree ("planId");


--
-- Name: ServiceTemplate_name_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServiceTemplate_name_key" ON public."ServiceTemplate" USING btree (name);


--
-- Name: ServiceUpgradePath_fromPlanId_toPlanId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "ServiceUpgradePath_fromPlanId_toPlanId_key" ON public."ServiceUpgradePath" USING btree ("fromPlanId", "toPlanId");


--
-- Name: ServiceUpgradePath_serviceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "ServiceUpgradePath_serviceId_idx" ON public."ServiceUpgradePath" USING btree ("serviceId");


--
-- Name: Service_active_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Service_active_idx" ON public."Service" USING btree (active);


--
-- Name: Service_code_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "Service_code_key" ON public."Service" USING btree (code);


--
-- Name: Service_groupId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Service_groupId_idx" ON public."Service" USING btree ("groupId");


--
-- Name: Service_parentServiceId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Service_parentServiceId_idx" ON public."Service" USING btree ("parentServiceId");


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: StorageConfig_createdById_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "StorageConfig_createdById_idx" ON public."StorageConfig" USING btree ("createdById");


--
-- Name: TaxRule_active_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "TaxRule_active_idx" ON public."TaxRule" USING btree (active);


--
-- Name: TaxRule_country_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "TaxRule_country_idx" ON public."TaxRule" USING btree (country);


--
-- Name: TaxRule_country_serviceType_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "TaxRule_country_serviceType_idx" ON public."TaxRule" USING btree (country, "serviceType");


--
-- Name: TicketReply_ticketId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "TicketReply_ticketId_idx" ON public."TicketReply" USING btree ("ticketId");


--
-- Name: Ticket_createdAt_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Ticket_createdAt_idx" ON public."Ticket" USING btree ("createdAt");


--
-- Name: Ticket_status_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Ticket_status_idx" ON public."Ticket" USING btree (status);


--
-- Name: Ticket_ticketCode_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "Ticket_ticketCode_key" ON public."Ticket" USING btree ("ticketCode");


--
-- Name: Ticket_userId_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "Ticket_userId_idx" ON public."Ticket" USING btree ("userId");


--
-- Name: TrustedDevice_deviceId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "TrustedDevice_deviceId_key" ON public."TrustedDevice" USING btree ("deviceId");


--
-- Name: UserRole_userId_roleId_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "UserRole_userId_roleId_key" ON public."UserRole" USING btree ("userId", "roleId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: WebhookEvent_event_idx; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE INDEX "WebhookEvent_event_idx" ON public."WebhookEvent" USING btree (event);


--
-- Name: WorkflowTriggerRule_workflowId_eventType_key; Type: INDEX; Schema: public; Owner: whms_user
--

CREATE UNIQUE INDEX "WorkflowTriggerRule_workflowId_eventType_key" ON public."WorkflowTriggerRule" USING btree ("workflowId", "eventType");


--
-- Name: AdminProfile AdminProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AdminProfile"
    ADD CONSTRAINT "AdminProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ApiKeyScope ApiKeyScope_apiKeyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ApiKeyScope"
    ADD CONSTRAINT "ApiKeyScope_apiKeyId_fkey" FOREIGN KEY ("apiKeyId") REFERENCES public."ApiKey"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ApiKey ApiKey_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public."AutomationProfile"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AutomationRun AutomationRun_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AutomationRun"
    ADD CONSTRAINT "AutomationRun_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public."AutomationProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationTask AutomationTask_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."AutomationTask"
    ADD CONSTRAINT "AutomationTask_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public."AutomationProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BackupStepLog BackupStepLog_backupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BackupStepLog"
    ADD CONSTRAINT "BackupStepLog_backupId_fkey" FOREIGN KEY ("backupId") REFERENCES public."Backup"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BackupVersion BackupVersion_backupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BackupVersion"
    ADD CONSTRAINT "BackupVersion_backupId_fkey" FOREIGN KEY ("backupId") REFERENCES public."Backup"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Backup Backup_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Backup"
    ADD CONSTRAINT "Backup_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Backup Backup_storageConfigId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Backup"
    ADD CONSTRAINT "Backup_storageConfigId_fkey" FOREIGN KEY ("storageConfigId") REFERENCES public."StorageConfig"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: BillingProfile BillingProfile_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BillingProfile"
    ADD CONSTRAINT "BillingProfile_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: BillingTransaction BillingTransaction_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."BillingTransaction"
    ADD CONSTRAINT "BillingTransaction_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DeveloperProfile DeveloperProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."DeveloperProfile"
    ADD CONSTRAINT "DeveloperProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Domain Domain_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DunningAttempt DunningAttempt_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."DunningAttempt"
    ADD CONSTRAINT "DunningAttempt_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmailToken EmailToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."EmailToken"
    ADD CONSTRAINT "EmailToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: HostingAccount HostingAccount_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."HostingAccount"
    ADD CONSTRAINT "HostingAccount_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: HostingAccount HostingAccount_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."HostingAccount"
    ADD CONSTRAINT "HostingAccount_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: HostingDatabase HostingDatabase_hostingAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."HostingDatabase"
    ADD CONSTRAINT "HostingDatabase_hostingAccountId_fkey" FOREIGN KEY ("hostingAccountId") REFERENCES public."HostingAccount"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: HostingDomain HostingDomain_hostingAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."HostingDomain"
    ADD CONSTRAINT "HostingDomain_hostingAccountId_fkey" FOREIGN KEY ("hostingAccountId") REFERENCES public."HostingAccount"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: HostingEmail HostingEmail_hostingAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."HostingEmail"
    ADD CONSTRAINT "HostingEmail_hostingAccountId_fkey" FOREIGN KEY ("hostingAccountId") REFERENCES public."HostingAccount"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Impersonation Impersonation_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Impersonation"
    ADD CONSTRAINT "Impersonation_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Impersonation Impersonation_impersonatedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Impersonation"
    ADD CONSTRAINT "Impersonation_impersonatedId_fkey" FOREIGN KEY ("impersonatedId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IncomingWebhook IncomingWebhook_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."IncomingWebhook"
    ADD CONSTRAINT "IncomingWebhook_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public."AutomationWorkflow"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InvoiceDiscount InvoiceDiscount_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."InvoiceDiscount"
    ADD CONSTRAINT "InvoiceDiscount_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InvoiceLineItem InvoiceLineItem_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."InvoiceLineItem"
    ADD CONSTRAINT "InvoiceLineItem_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoice Invoice_billingProfileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_billingProfileId_fkey" FOREIGN KEY ("billingProfileId") REFERENCES public."BillingProfile"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invoice Invoice_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: IpAccessRule IpAccessRule_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."IpAccessRule"
    ADD CONSTRAINT "IpAccessRule_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LoginLog LoginLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceProduct MarketplaceProduct_devId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."MarketplaceProduct"
    ADD CONSTRAINT "MarketplaceProduct_devId_fkey" FOREIGN KEY ("devId") REFERENCES public."DeveloperProfile"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplacePurchase MarketplacePurchase_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceReview MarketplaceReview_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."MarketplaceReview"
    ADD CONSTRAINT "MarketplaceReview_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceReview MarketplaceReview_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."MarketplaceReview"
    ADD CONSTRAINT "MarketplaceReview_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceSubmission MarketplaceSubmission_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_snapshotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_snapshotId_fkey" FOREIGN KEY ("snapshotId") REFERENCES public."ServiceSnapshot"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PaymentMethod PaymentMethod_billingProfileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."PaymentMethod"
    ADD CONSTRAINT "PaymentMethod_billingProfileId_fkey" FOREIGN KEY ("billingProfileId") REFERENCES public."BillingProfile"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PaymentMethod PaymentMethod_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."PaymentMethod"
    ADD CONSTRAINT "PaymentMethod_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_paymentMethodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_paymentMethodId_fkey" FOREIGN KEY ("paymentMethodId") REFERENCES public."PaymentMethod"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Refund Refund_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Refund"
    ADD CONSTRAINT "Refund_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public."Payment"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResellerProfile ResellerProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ResellerProfile"
    ADD CONSTRAINT "ResellerProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermission RolePermission_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermission RolePermission_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceAddonPricing ServiceAddonPricing_addonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceAddonPricing"
    ADD CONSTRAINT "ServiceAddonPricing_addonId_fkey" FOREIGN KEY ("addonId") REFERENCES public."ServiceAddon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceAddon ServiceAddon_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceAddon"
    ADD CONSTRAINT "ServiceAddon_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceAutomation ServiceAutomation_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceAutomation"
    ADD CONSTRAINT "ServiceAutomation_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceConfiguration ServiceConfiguration_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceConfiguration"
    ADD CONSTRAINT "ServiceConfiguration_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceFeature ServiceFeature_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceFeature"
    ADD CONSTRAINT "ServiceFeature_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePlanAddon ServicePlanAddon_addonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanAddon"
    ADD CONSTRAINT "ServicePlanAddon_addonId_fkey" FOREIGN KEY ("addonId") REFERENCES public."ServiceAddon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePlanAddon ServicePlanAddon_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanAddon"
    ADD CONSTRAINT "ServicePlanAddon_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePlanAutomation ServicePlanAutomation_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanAutomation"
    ADD CONSTRAINT "ServicePlanAutomation_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePlanConfiguration ServicePlanConfiguration_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanConfiguration"
    ADD CONSTRAINT "ServicePlanConfiguration_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePlanFeature ServicePlanFeature_featureId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanFeature"
    ADD CONSTRAINT "ServicePlanFeature_featureId_fkey" FOREIGN KEY ("featureId") REFERENCES public."ServiceFeature"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePlanFeature ServicePlanFeature_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanFeature"
    ADD CONSTRAINT "ServicePlanFeature_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePlanPolicy ServicePlanPolicy_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlanPolicy"
    ADD CONSTRAINT "ServicePlanPolicy_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePlan ServicePlan_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePlan"
    ADD CONSTRAINT "ServicePlan_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePolicy ServicePolicy_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePolicy"
    ADD CONSTRAINT "ServicePolicy_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePricing ServicePricing_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServicePricing"
    ADD CONSTRAINT "ServicePricing_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceSnapshot ServiceSnapshot_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceSnapshot"
    ADD CONSTRAINT "ServiceSnapshot_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceUpgradePath ServiceUpgradePath_fromPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceUpgradePath"
    ADD CONSTRAINT "ServiceUpgradePath_fromPlanId_fkey" FOREIGN KEY ("fromPlanId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceUpgradePath ServiceUpgradePath_toPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."ServiceUpgradePath"
    ADD CONSTRAINT "ServiceUpgradePath_toPlanId_fkey" FOREIGN KEY ("toPlanId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Service Service_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."ServiceGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Service Service_parentServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_parentServiceId_fkey" FOREIGN KEY ("parentServiceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StorageConfig StorageConfig_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."StorageConfig"
    ADD CONSTRAINT "StorageConfig_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketReply TicketReply_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."TicketReply"
    ADD CONSTRAINT "TicketReply_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Ticket"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Ticket Ticket_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TrustedDevice TrustedDevice_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."TrustedDevice"
    ADD CONSTRAINT "TrustedDevice_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserRole UserRole_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."UserRole"
    ADD CONSTRAINT "UserRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserRole UserRole_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."UserRole"
    ADD CONSTRAINT "UserRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WorkflowRun WorkflowRun_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."WorkflowRun"
    ADD CONSTRAINT "WorkflowRun_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public."AutomationWorkflow"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkflowTaskRun WorkflowTaskRun_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."WorkflowTaskRun"
    ADD CONSTRAINT "WorkflowTaskRun_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."WorkflowRun"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkflowTriggerRule WorkflowTriggerRule_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms_user
--

ALTER TABLE ONLY public."WorkflowTriggerRule"
    ADD CONSTRAINT "WorkflowTriggerRule_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public."AutomationWorkflow"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict pxjDAclrgLxWBpv7fnwyGOHSoh2toa6JcKKHsZqu47LfyTqaPy6eUKS1JKmCaDs

