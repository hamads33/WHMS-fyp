module.exports = () => {
  console.log("Demo plugin executed!");
};
