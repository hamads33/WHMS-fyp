--
-- PostgreSQL database dump
--

\restrict 7IrbvJ9QhOYj2T6JMCSnXbQWaGJPm0bWowU256sZv2jKKUsBSZ6DmWmCoHzevoH

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AutomationRunStatus; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."AutomationRunStatus" AS ENUM (
    'pending',
    'running',
    'success',
    'failed'
);


ALTER TYPE public."AutomationRunStatus" OWNER TO whms;

--
-- Name: IpRuleType; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."IpRuleType" AS ENUM (
    'ALLOW',
    'DENY'
);


ALTER TYPE public."IpRuleType" OWNER TO whms;

--
-- Name: MarketplaceSubmissionStatus; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."MarketplaceSubmissionStatus" AS ENUM (
    'pending_review',
    'pending_dependency_approval',
    'pending_resubmission',
    'rejected',
    'auto_rejected',
    'approved'
);


ALTER TYPE public."MarketplaceSubmissionStatus" OWNER TO whms;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AdminProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AdminProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    department text,
    "staffTitle" text,
    "restrictionJson" jsonb
);


ALTER TABLE public."AdminProfile" OWNER TO whms;

--
-- Name: ApiKey; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ApiKey" (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    "keyHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."ApiKey" OWNER TO whms;

--
-- Name: ApiKeyScope; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ApiKeyScope" (
    id text NOT NULL,
    "apiKeyId" text NOT NULL,
    scope text NOT NULL
);


ALTER TABLE public."ApiKeyScope" OWNER TO whms;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AuditLog" (
    "userId" text,
    action text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    data jsonb,
    entity text,
    "entityId" text,
    ip text,
    "userAgent" text,
    actor text NOT NULL,
    level text DEFAULT 'INFO'::text NOT NULL,
    meta jsonb,
    source text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO whms;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."AuditLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AuditLog_id_seq" OWNER TO whms;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."AuditLog_id_seq" OWNED BY public."AuditLog".id;


--
-- Name: AutomationProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AutomationProfile" (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    cron text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AutomationProfile" OWNER TO whms;

--
-- Name: AutomationProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."AutomationProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationProfile_id_seq" OWNER TO whms;

--
-- Name: AutomationProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."AutomationProfile_id_seq" OWNED BY public."AutomationProfile".id;


--
-- Name: AutomationRun; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AutomationRun" (
    id integer NOT NULL,
    "profileId" integer NOT NULL,
    "taskId" integer,
    result jsonb,
    "errorMessage" text,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."AutomationRunStatus" NOT NULL
);


ALTER TABLE public."AutomationRun" OWNER TO whms;

--
-- Name: AutomationRun_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."AutomationRun_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationRun_id_seq" OWNER TO whms;

--
-- Name: AutomationRun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."AutomationRun_id_seq" OWNED BY public."AutomationRun".id;


--
-- Name: AutomationTask; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AutomationTask" (
    id integer NOT NULL,
    "profileId" integer NOT NULL,
    "actionType" text NOT NULL,
    "actionMeta" jsonb,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AutomationTask" OWNER TO whms;

--
-- Name: AutomationTask_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."AutomationTask_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationTask_id_seq" OWNER TO whms;

--
-- Name: AutomationTask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."AutomationTask_id_seq" OWNED BY public."AutomationTask".id;


--
-- Name: Backup; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Backup" (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    "storageConfigId" integer,
    "filePath" text,
    "sizeBytes" bigint,
    status text NOT NULL,
    "retentionDays" integer,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    deleted boolean DEFAULT false NOT NULL,
    "errorMessage" text
);


ALTER TABLE public."Backup" OWNER TO whms;

--
-- Name: BackupStepLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."BackupStepLog" (
    id text NOT NULL,
    "backupId" text NOT NULL,
    step text NOT NULL,
    meta jsonb,
    status text DEFAULT 'started'::text NOT NULL,
    message text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."BackupStepLog" OWNER TO whms;

--
-- Name: BackupVersion; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."BackupVersion" (
    id text NOT NULL,
    "backupId" text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "filePath" text NOT NULL,
    "sizeBytes" bigint,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."BackupVersion" OWNER TO whms;

--
-- Name: ClientProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ClientProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    company text,
    phone text,
    address text,
    country text,
    city text,
    postal text
);


ALTER TABLE public."ClientProfile" OWNER TO whms;

--
-- Name: DNSRecord; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."DNSRecord" (
    id integer NOT NULL,
    "domainId" integer NOT NULL,
    type text NOT NULL,
    name text NOT NULL,
    value text NOT NULL,
    ttl integer DEFAULT 3600 NOT NULL,
    "providerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DNSRecord" OWNER TO whms;

--
-- Name: DNSRecord_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."DNSRecord_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DNSRecord_id_seq" OWNER TO whms;

--
-- Name: DNSRecord_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."DNSRecord_id_seq" OWNED BY public."DNSRecord".id;


--
-- Name: DeveloperProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."DeveloperProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "displayName" text,
    website text,
    github text,
    "payoutsEmail" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "marketplaceMeta" jsonb,
    "publicKeyPem" text,
    "storeName" text,
    "stripeAccountId" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DeveloperProfile" OWNER TO whms;

--
-- Name: Domain; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Domain" (
    id integer NOT NULL,
    name text NOT NULL,
    provider text,
    status text DEFAULT 'active'::text NOT NULL,
    "expiryDate" timestamp(3) without time zone,
    nameservers text[] DEFAULT ARRAY[]::text[],
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Domain" OWNER TO whms;

--
-- Name: DomainLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."DomainLog" (
    id integer NOT NULL,
    "domainId" integer NOT NULL,
    action text NOT NULL,
    message text,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DomainLog" OWNER TO whms;

--
-- Name: DomainLog_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."DomainLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DomainLog_id_seq" OWNER TO whms;

--
-- Name: DomainLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."DomainLog_id_seq" OWNED BY public."DomainLog".id;


--
-- Name: Domain_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."Domain_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Domain_id_seq" OWNER TO whms;

--
-- Name: Domain_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."Domain_id_seq" OWNED BY public."Domain".id;


--
-- Name: EmailEvent; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."EmailEvent" (
    id integer NOT NULL,
    "jobId" text,
    "eventType" text NOT NULL,
    "providerId" text,
    payload jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."EmailEvent" OWNER TO whms;

--
-- Name: EmailEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."EmailEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailEvent_id_seq" OWNER TO whms;

--
-- Name: EmailEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."EmailEvent_id_seq" OWNED BY public."EmailEvent".id;


--
-- Name: EmailJob; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."EmailJob" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "templateId" integer,
    "templateName" text,
    "toEmail" text NOT NULL,
    "toName" text,
    payload jsonb,
    status text DEFAULT 'queued'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "lastError" text,
    priority text DEFAULT 'normal'::text NOT NULL,
    provider text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailJob" OWNER TO whms;

--
-- Name: EmailTemplate; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."EmailTemplate" (
    id integer NOT NULL,
    name text NOT NULL,
    subject text NOT NULL,
    "bodyHtml" text NOT NULL,
    "bodyText" text,
    language text DEFAULT 'en'::text NOT NULL,
    "isDefault" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailTemplate" OWNER TO whms;

--
-- Name: EmailTemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."EmailTemplate_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailTemplate_id_seq" OWNER TO whms;

--
-- Name: EmailTemplate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."EmailTemplate_id_seq" OWNED BY public."EmailTemplate".id;


--
-- Name: EmailToken; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."EmailToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    type text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL
);


ALTER TABLE public."EmailToken" OWNER TO whms;

--
-- Name: Impersonation; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Impersonation" (
    id text NOT NULL,
    "adminId" text NOT NULL,
    "impersonatedId" text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) without time zone,
    "sessionToken" text NOT NULL,
    reason text
);


ALTER TABLE public."Impersonation" OWNER TO whms;

--
-- Name: IpAccessRule; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."IpAccessRule" (
    id integer NOT NULL,
    pattern text NOT NULL,
    type public."IpRuleType" NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."IpAccessRule" OWNER TO whms;

--
-- Name: IpAccessRule_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."IpAccessRule_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."IpAccessRule_id_seq" OWNER TO whms;

--
-- Name: IpAccessRule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."IpAccessRule_id_seq" OWNED BY public."IpAccessRule".id;


--
-- Name: LoginLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."LoginLog" (
    id text NOT NULL,
    "userId" text,
    "userEmail" text,
    success boolean NOT NULL,
    ip text,
    "userAgent" text,
    reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoginLog" OWNER TO whms;

--
-- Name: MarketplaceActiveInstance; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceActiveInstance" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    "instanceId" text NOT NULL,
    "userId" text,
    "lastSeen" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceActiveInstance" OWNER TO whms;

--
-- Name: MarketplaceAnalytics; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceAnalytics" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    "eventType" text NOT NULL,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceAnalytics" OWNER TO whms;

--
-- Name: MarketplaceAnalyticsAggregate; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceAnalyticsAggregate" (
    id text NOT NULL,
    "productId" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    installs integer DEFAULT 0 NOT NULL,
    active integer DEFAULT 0 NOT NULL,
    crashes integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceAnalyticsAggregate" OWNER TO whms;

--
-- Name: MarketplaceBuildLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceBuildLog" (
    id text NOT NULL,
    "submissionId" text,
    "productId" text,
    "versionId" text,
    level text DEFAULT 'info'::text NOT NULL,
    message text NOT NULL,
    meta jsonb,
    step text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceBuildLog" OWNER TO whms;

--
-- Name: MarketplaceCategory; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceCategory" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    icon text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."MarketplaceCategory" OWNER TO whms;

--
-- Name: MarketplaceCrash; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceCrash" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    "userId" text,
    message text NOT NULL,
    "stackTrace" text,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceCrash" OWNER TO whms;

--
-- Name: MarketplaceDependency; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceDependency" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "dependencyId" text NOT NULL,
    "versionRange" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    approved boolean DEFAULT false NOT NULL
);


ALTER TABLE public."MarketplaceDependency" OWNER TO whms;

--
-- Name: MarketplaceLicenseActivation; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceLicenseActivation" (
    id text NOT NULL,
    "licenseId" text NOT NULL,
    "userAgent" text,
    host text,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceLicenseActivation" OWNER TO whms;

--
-- Name: MarketplacePerfMetric; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplacePerfMetric" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    metric text NOT NULL,
    value double precision NOT NULL,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplacePerfMetric" OWNER TO whms;

--
-- Name: MarketplaceProduct; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceProduct" (
    id text NOT NULL,
    "sellerId" text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    "shortDesc" text,
    "longDesc" text,
    "categoryId" text,
    tags text[] DEFAULT ARRAY[]::text[],
    status text DEFAULT 'draft'::text NOT NULL,
    "rejectReason" text,
    logo text,
    screenshots text[] DEFAULT ARRAY[]::text[],
    documentation text,
    "ratingAvg" double precision DEFAULT 0 NOT NULL,
    "ratingCount" integer DEFAULT 0 NOT NULL,
    "installCount" integer DEFAULT 0 NOT NULL,
    "downloadCount" integer DEFAULT 0 NOT NULL,
    "lastUpdatedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "approvedAt" timestamp(3) without time zone
);


ALTER TABLE public."MarketplaceProduct" OWNER TO whms;

--
-- Name: MarketplacePurchase; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplacePurchase" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text NOT NULL,
    "licenseKey" text NOT NULL,
    subscribed boolean DEFAULT false NOT NULL,
    "activationLimit" integer DEFAULT 1 NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    revoked boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplacePurchase" OWNER TO whms;

--
-- Name: MarketplaceReview; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceReview" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    rating integer NOT NULL,
    stability integer,
    review text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceReview" OWNER TO whms;

--
-- Name: MarketplaceSubmission; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceSubmission" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    "reviewerId" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."MarketplaceSubmissionStatus" NOT NULL
);


ALTER TABLE public."MarketplaceSubmission" OWNER TO whms;

--
-- Name: MarketplaceVerification; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceVerification" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text NOT NULL,
    passed boolean NOT NULL,
    issues jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceVerification" OWNER TO whms;

--
-- Name: MarketplaceVersion; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceVersion" (
    id text NOT NULL,
    "productId" text NOT NULL,
    version text NOT NULL,
    "manifestJson" jsonb NOT NULL,
    "archivePath" text NOT NULL,
    changelog text,
    "priceCents" integer NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "approvedAt" timestamp(3) without time zone
);


ALTER TABLE public."MarketplaceVersion" OWNER TO whms;

--
-- Name: MarketplaceWebhook; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceWebhook" (
    id text NOT NULL,
    event text NOT NULL,
    payload jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceWebhook" OWNER TO whms;

--
-- Name: MarketplaceWebhookEndpoint; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceWebhookEndpoint" (
    id text NOT NULL,
    "vendorId" text NOT NULL,
    url text NOT NULL,
    secret text,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceWebhookEndpoint" OWNER TO whms;

--
-- Name: Permission; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Permission" (
    id text NOT NULL,
    key text NOT NULL,
    description text
);


ALTER TABLE public."Permission" OWNER TO whms;

--
-- Name: Plugin; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Plugin" (
    id text NOT NULL,
    name text NOT NULL,
    version text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "installedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    folder text NOT NULL,
    "configSchema" jsonb,
    type text DEFAULT 'ui'::text
);


ALTER TABLE public."Plugin" OWNER TO whms;

--
-- Name: PluginSetting; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."PluginSetting" (
    id integer NOT NULL,
    "pluginId" text NOT NULL,
    key text NOT NULL,
    value jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PluginSetting" OWNER TO whms;

--
-- Name: PluginSetting_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."PluginSetting_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PluginSetting_id_seq" OWNER TO whms;

--
-- Name: PluginSetting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."PluginSetting_id_seq" OWNED BY public."PluginSetting".id;


--
-- Name: ProviderConfig; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ProviderConfig" (
    id integer NOT NULL,
    name text NOT NULL,
    key text,
    secret text,
    endpoint text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProviderConfig" OWNER TO whms;

--
-- Name: ProviderConfig_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."ProviderConfig_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProviderConfig_id_seq" OWNER TO whms;

--
-- Name: ProviderConfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."ProviderConfig_id_seq" OWNED BY public."ProviderConfig".id;


--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."RefreshToken" (
    id integer NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RefreshToken" OWNER TO whms;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."RefreshToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RefreshToken_id_seq" OWNER TO whms;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."RefreshToken_id_seq" OWNED BY public."RefreshToken".id;


--
-- Name: ResellerProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ResellerProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "resellerCode" text NOT NULL,
    company text,
    phone text,
    address text
);


ALTER TABLE public."ResellerProfile" OWNER TO whms;

--
-- Name: Role; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public."Role" OWNER TO whms;

--
-- Name: RolePermission; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."RolePermission" (
    id text NOT NULL,
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL
);


ALTER TABLE public."RolePermission" OWNER TO whms;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "userAgent" text,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "isImpersonation" boolean DEFAULT false NOT NULL,
    "impersonatorId" text,
    "impersonationReason" text
);


ALTER TABLE public."Session" OWNER TO whms;

--
-- Name: StorageConfig; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."StorageConfig" (
    id integer NOT NULL,
    name text NOT NULL,
    provider text NOT NULL,
    config jsonb NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StorageConfig" OWNER TO whms;

--
-- Name: StorageConfig_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."StorageConfig_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StorageConfig_id_seq" OWNER TO whms;

--
-- Name: StorageConfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."StorageConfig_id_seq" OWNED BY public."StorageConfig".id;


--
-- Name: Ticket; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Ticket" (
    id integer NOT NULL,
    "clientId" text NOT NULL,
    subject text NOT NULL,
    message text NOT NULL,
    priority text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Ticket" OWNER TO whms;

--
-- Name: Ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."Ticket_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Ticket_id_seq" OWNER TO whms;

--
-- Name: Ticket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."Ticket_id_seq" OWNED BY public."Ticket".id;


--
-- Name: Tld; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Tld" (
    id integer NOT NULL,
    name text NOT NULL,
    "registerPrice" integer,
    "renewPrice" integer,
    "transferPrice" integer,
    "markupPercent" integer,
    "providerData" jsonb,
    "lastSynced" timestamp(3) without time zone,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Tld" OWNER TO whms;

--
-- Name: Tld_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."Tld_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Tld_id_seq" OWNER TO whms;

--
-- Name: Tld_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."Tld_id_seq" OWNED BY public."Tld".id;


--
-- Name: TrustedDevice; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."TrustedDevice" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "deviceId" text NOT NULL,
    "userAgent" text,
    ip text,
    name text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastUsedAt" timestamp(3) without time zone NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public."TrustedDevice" OWNER TO whms;

--
-- Name: User; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "mfaBackupCodes" text[] DEFAULT ARRAY[]::text[],
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaSecret" text,
    "passwordHash" text NOT NULL
);


ALTER TABLE public."User" OWNER TO whms;

--
-- Name: UserRole; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."UserRole" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "roleId" text NOT NULL
);


ALTER TABLE public."UserRole" OWNER TO whms;

--
-- Name: Webhook; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Webhook" (
    id text NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    secret text NOT NULL,
    events text[],
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Webhook" OWNER TO whms;

--
-- Name: WebhookLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."WebhookLog" (
    id text NOT NULL,
    "webhookId" text NOT NULL,
    event text NOT NULL,
    payload jsonb NOT NULL,
    status text NOT NULL,
    "httpStatus" integer,
    attempts integer DEFAULT 0 NOT NULL,
    "lastError" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WebhookLog" OWNER TO whms;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO whms;

--
-- Name: AuditLog id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AuditLog" ALTER COLUMN id SET DEFAULT nextval('public."AuditLog_id_seq"'::regclass);


--
-- Name: AutomationProfile id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationProfile" ALTER COLUMN id SET DEFAULT nextval('public."AutomationProfile_id_seq"'::regclass);


--
-- Name: AutomationRun id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationRun" ALTER COLUMN id SET DEFAULT nextval('public."AutomationRun_id_seq"'::regclass);


--
-- Name: AutomationTask id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationTask" ALTER COLUMN id SET DEFAULT nextval('public."AutomationTask_id_seq"'::regclass);


--
-- Name: DNSRecord id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DNSRecord" ALTER COLUMN id SET DEFAULT nextval('public."DNSRecord_id_seq"'::regclass);


--
-- Name: Domain id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Domain" ALTER COLUMN id SET DEFAULT nextval('public."Domain_id_seq"'::regclass);


--
-- Name: DomainLog id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainLog" ALTER COLUMN id SET DEFAULT nextval('public."DomainLog_id_seq"'::regclass);


--
-- Name: EmailEvent id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailEvent" ALTER COLUMN id SET DEFAULT nextval('public."EmailEvent_id_seq"'::regclass);


--
-- Name: EmailTemplate id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailTemplate" ALTER COLUMN id SET DEFAULT nextval('public."EmailTemplate_id_seq"'::regclass);


--
-- Name: IpAccessRule id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."IpAccessRule" ALTER COLUMN id SET DEFAULT nextval('public."IpAccessRule_id_seq"'::regclass);


--
-- Name: PluginSetting id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."PluginSetting" ALTER COLUMN id SET DEFAULT nextval('public."PluginSetting_id_seq"'::regclass);


--
-- Name: ProviderConfig id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ProviderConfig" ALTER COLUMN id SET DEFAULT nextval('public."ProviderConfig_id_seq"'::regclass);


--
-- Name: RefreshToken id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RefreshToken" ALTER COLUMN id SET DEFAULT nextval('public."RefreshToken_id_seq"'::regclass);


--
-- Name: StorageConfig id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."StorageConfig" ALTER COLUMN id SET DEFAULT nextval('public."StorageConfig_id_seq"'::regclass);


--
-- Name: Ticket id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Ticket" ALTER COLUMN id SET DEFAULT nextval('public."Ticket_id_seq"'::regclass);


--
-- Name: Tld id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Tld" ALTER COLUMN id SET DEFAULT nextval('public."Tld_id_seq"'::regclass);


--
-- Data for Name: AdminProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AdminProfile" (id, "userId", department, "staffTitle", "restrictionJson") FROM stdin;
b5d2947b-7cda-43b6-85b1-f783f30f5e7b	67192e26-5ba9-47fa-8e66-b3e87af343d9	System	Super Administrator	\N
\.


--
-- Data for Name: ApiKey; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ApiKey" (id, "userId", name, "keyHash", "createdAt", revoked, "expiresAt") FROM stdin;
\.


--
-- Data for Name: ApiKeyScope; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ApiKeyScope" (id, "apiKeyId", scope) FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AuditLog" ("userId", action, "createdAt", data, entity, "entityId", ip, "userAgent", actor, level, meta, source, id) FROM stdin;
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-18 18:44:50.462	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	1
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-18 18:44:51.95	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	2
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-18 18:45:01.508	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	3
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-18 18:48:44.092	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	4
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 12:05:34.028	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	5
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 12:06:04.461	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	6
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-19 12:39:06.696	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	7
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-19 12:39:07.835	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	8
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-19 12:39:18.036	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	9
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 12:39:56.265	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	10
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-19 12:54:40.479	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	11
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-19 12:54:59.278	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	12
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-19 12:55:00.369	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	13
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 12:55:24.728	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	14
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 13:01:05.191	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	15
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 13:23:06.868	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	16
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 13:23:45.391	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	17
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 13:34:36.188	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	18
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 14:09:26.394	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	19
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-19 14:49:08.089	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	20
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 14:49:19.926	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	21
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 16:05:17.339	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	22
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 16:20:59.383	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	23
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.failure	2025-12-19 16:38:47.564	{"email": "superadmin@example.com", "reason": "invalid_password"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	24
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 16:39:03.334	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	25
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 16:45:00.688	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	26
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 17:02:41.172	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	27
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 17:14:02.461	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	28
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 17:31:01.898	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	29
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 17:56:14.654	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	30
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 18:20:41.002	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	31
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 18:22:38.391	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	32
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 18:39:56.408	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	33
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 19:40:38.998	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	34
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-19 20:03:33.469	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	35
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 12:26:12.669	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	36
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 13:56:41.846	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	37
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 13:59:47.691	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	38
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 14:16:11.325	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	39
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 14:49:43.878	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	40
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 15:05:32.766	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	41
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 15:22:26.357	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	42
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 15:37:49.772	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	43
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 15:53:51.621	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	44
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 16:21:22.89	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	45
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 16:38:50.296	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	46
67192e26-5ba9-47fa-8e66-b3e87af343d9	login.success	2025-12-20 16:56:40.376	{"email": "superadmin@example.com", "reason": "login_success"}	auth	67192e26-5ba9-47fa-8e66-b3e87af343d9	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	47
\.


--
-- Data for Name: AutomationProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AutomationProfile" (id, name, description, cron, enabled, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AutomationRun; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AutomationRun" (id, "profileId", "taskId", result, "errorMessage", "startedAt", "finishedAt", "createdAt", status) FROM stdin;
\.


--
-- Data for Name: AutomationTask; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AutomationTask" (id, "profileId", "actionType", "actionMeta", "order", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Backup; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Backup" (id, name, type, "storageConfigId", "filePath", "sizeBytes", status, "retentionDays", "createdById", "createdAt", "startedAt", "finishedAt", deleted, "errorMessage") FROM stdin;
cmjef6f08000c1ctidqxzluix	backup-1766242494584	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:54.585	2025-12-20 14:55:10.065	2025-12-20 14:55:10.106	f	database is required for pg_dump
cmjef61yh00061cti2zkzifi4	backup-1766242477673	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:37.673	2025-12-20 14:54:53.171	2025-12-20 14:54:53.212	f	database is required for pg_dump
cmjehoa4z00021cr4hi4293l0	backup-1766246687315	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:04:47.315	2025-12-20 16:05:02.768	2025-12-20 16:05:02.809	f	pgDumpToGzipStream is not a function
cmjef6f9x000d1ctimbe919xg	backup-1766242494933	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:54.934	2025-12-20 14:55:10.566	2025-12-20 14:55:10.607	f	database is required for pg_dump
cmjef62pa00071ctigc1iflnk	backup-1766242478638	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:38.639	2025-12-20 14:54:54.175	2025-12-20 14:54:54.239	f	database is required for pg_dump
cmjef6fo7000e1ctiqp0xau4a	backup-1766242495446	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:55.447	2025-12-20 14:55:10.969	2025-12-20 14:55:11.011	f	database is required for pg_dump
cmjef6fz6000f1ctihbqsy4ik	backup-1766242495842	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:55.843	2025-12-20 14:55:11.371	2025-12-20 14:55:11.412	f	database is required for pg_dump
cmjehoald00031cr4xqquzwpa	backup-1766246687905	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:04:47.906	2025-12-20 16:05:03.37	2025-12-20 16:05:03.411	f	pgDumpToGzipStream is not a function
cmjef4pxg00011ctippp5x92o	backup-1766242415428	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:53:35.428	2025-12-20 14:54:31.875	2025-12-20 14:54:31.916	f	database is required for pg_dump
cmjef4ht000001ctiwsloy31v	backup-1766242404817	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:53:24.901	2025-12-20 14:54:31.949	2025-12-20 14:54:31.99	f	database is required for pg_dump
cmjeglazj00011c7vge2fli5p	backup-1766244868817	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 15:34:28.818	2025-12-20 15:50:59.424	2025-12-20 15:50:59.466	f	pgDumpToGzipStream is not a function
cmjefkjj000001crm2rfodmuj	backup-1766243153551	full	\N	\N	\N	running	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 15:05:53.628	2025-12-20 15:09:48.481	\N	f	\N
cmjef4qg000021ctijpe15wtz	backup-1766242416096	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:53:36.097	2025-12-20 14:54:32.02	2025-12-20 14:54:32.083	f	database is required for pg_dump
cmjef4qrd00031cti6spq9d3z	backup-1766242416505	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:53:36.505	2025-12-20 14:54:32.021	2025-12-20 14:54:32.095	f	database is required for pg_dump
cmjef4r3400041ctigwuptyzg	backup-1766242416928	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:53:36.929	2025-12-20 14:54:32.133	2025-12-20 14:54:32.204	f	database is required for pg_dump
cmjefpmc400001c3ihtrogh3b	backup-1766243390456	full	\N	\N	\N	running	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 15:09:50.548	2025-12-20 15:13:33.545	\N	f	\N
cmjef4rfh00051cti2q4oorup	backup-1766242417373	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:53:37.373	2025-12-20 14:54:32.146	2025-12-20 14:54:32.217	f	database is required for pg_dump
cmjef6ahf00091cticyfm9jvl	backup-1766242488722	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:48.723	2025-12-20 14:55:04.233	2025-12-20 14:55:04.273	f	database is required for pg_dump
cmjef65oo00081ctinsiqjs1b	backup-1766242482504	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:42.505	2025-12-20 14:54:57.999	2025-12-20 14:54:58.039	f	database is required for pg_dump
cmjeg6lnz00001c7vrj7fv22g	backup-1766244182742	full	\N	\N	\N	running	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 15:23:02.831	2025-12-20 15:25:23.674	\N	f	\N
cmjef6e1b000a1ctiio88rnji	backup-1766242493327	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:53.327	2025-12-20 14:55:08.857	2025-12-20 14:55:08.898	f	database is required for pg_dump
cmjef6erm000b1ctiuuc6xp8b	backup-1766242494274	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 14:54:54.275	2025-12-20 14:55:09.762	2025-12-20 14:55:09.803	f	database is required for pg_dump
cmjehsr4y00041cr4ybx67vi7	backup-1766246895969	full	\N	\N	\N	running	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:08:15.97	2025-12-20 16:16:18.495	\N	f	\N
cmjehah6p00001cr4g228eyqt	backup-1766246043189	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 15:54:03.266	2025-12-20 15:54:18.869	2025-12-20 15:54:18.91	f	pgDumpToGzipStream is not a function
cmjehsxlx00061cr4tqbabn8c	backup-1766246904356	full	\N	\N	\N	running	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:08:24.357	2025-12-20 16:17:55.946	\N	f	\N
cmjeho9hi00011cr4fk7pm2qo	backup-1766246686450	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:04:46.451	2025-12-20 16:05:01.965	2025-12-20 16:05:02.007	f	pgDumpToGzipStream is not a function
cmjei9sok00011cx35mdc3zak	backup-1766247691124	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:21:31.125	2025-12-20 16:25:57.005	2025-12-20 16:25:57.067	f	pgDumpToGzipStream is not a function
cmjehsrum00051cr42b4bsfb2	backup-1766246896894	full	\N	\N	\N	running	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:08:16.895	2025-12-20 16:17:55.946	\N	f	\N
cmjehsxz800071cr4s6t9z0dx	backup-1766246904835	full	\N	\N	\N	running	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:08:24.836	2025-12-20 16:20:11.306	\N	f	\N
cmjei9s5i00001cx35ep9y944	backup-1766247690363	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:21:30.439	2025-12-20 16:26:26.693	2025-12-20 16:26:26.732	f	pgDumpToGzipStream is not a function
cmjeia2rs00031cx3eu4wlg0l	backup-1766247704199	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:21:44.2	2025-12-20 16:25:57.119	2025-12-20 16:25:57.189	f	pgDumpToGzipStream is not a function
cmjeia86j00041cx3b0sn86bv	backup-1766247711210	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:21:51.211	2025-12-20 16:25:57.131	2025-12-20 16:25:57.201	f	pgDumpToGzipStream is not a function
cmjei9swp00021cx3326rxtve	backup-1766247691417	full	\N	\N	\N	failed	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:21:31.418	2025-12-20 16:25:57.004	2025-12-20 16:25:57.079	f	pgDumpToGzipStream is not a function
cmjeiljt400061cx3pyn59pxj	backup-1766248239495	full	\N	backup-1766248239495-1766248239734.tar.gz	32783	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:30:39.496	2025-12-20 16:30:39.513	2025-12-20 16:30:39.751	f	\N
cmjeilj4400051cx3bbji19ro	backup-1766248238576	full	\N	backup-1766248238576-1766248238920.tar.gz	32410	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:30:38.577	2025-12-20 16:30:38.714	2025-12-20 16:30:38.938	f	\N
cmjeill5i00071cx3y28p8kj6	backup-1766248241237	full	\N	backup-1766248241237-1766248241472.tar.gz	33123	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:30:41.238	2025-12-20 16:30:41.255	2025-12-20 16:30:41.488	f	\N
cmjeilley00081cx305wdh1pl	backup-1766248241577	full	\N	backup-1766248241577-1766248241870.tar.gz	33471	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:30:41.578	2025-12-20 16:30:41.595	2025-12-20 16:30:41.887	f	\N
cmjeim06400001c6eqv8n9uvd	backup-1766248260615	full	\N	backup-1766248260615-1766248260943.tar.gz	33795	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:31:00.7	2025-12-20 16:31:00.72	2025-12-20 16:31:00.96	f	\N
cmjeim0vs00011c6emq1lygjt	backup-1766248261623	full	\N	backup-1766248261623-1766248261922.tar.gz	34154	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:31:01.624	2025-12-20 16:31:01.641	2025-12-20 16:31:01.939	f	\N
cmjeim1ef00021c6ein562dgg	backup-1766248262295	full	\N	backup-1766248262295-1766248262576.tar.gz	34488	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:31:02.296	2025-12-20 16:31:02.313	2025-12-20 16:31:02.593	f	\N
cmjeim21f00031c6ezkfpb4b6	backup-1766248263122	full	\N	backup-1766248263122-1766248263348.tar.gz	34818	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:31:03.123	2025-12-20 16:31:03.14	2025-12-20 16:31:03.364	f	\N
cmjeiog3x00001c9qapzfi300	backup-1766248374572	full	\N	backup-1766248374572-1766248374901.tar.gz	35172	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:32:54.669	2025-12-20 16:32:54.687	2025-12-20 16:32:54.918	f	\N
cmjeiogxq00011c9qnzdycnzj	backup-1766248375742	full	\N	backup-1766248375742-1766248375967.tar.gz	35510	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 16:32:55.743	2025-12-20 16:32:55.759	2025-12-20 16:32:55.983	f	\N
cmjejrtre00021c9quw7qzxhb	Manual-1766250211922	full	\N	Manual-1766250211922-1766250212308.tar.gz	36185	success	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 17:03:31.932	2025-12-20 17:03:32.065	2025-12-20 17:03:32.327	f	\N
cmjejxg6700001cxe6zmglxz4	Manual-1766250474173	full	\N	\N	\N	running	30	67192e26-5ba9-47fa-8e66-b3e87af343d9	2025-12-20 17:07:54.271	2025-12-20 17:07:54.302	\N	f	\N
\.


--
-- Data for Name: BackupStepLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."BackupStepLog" (id, "backupId", step, meta, status, message, "createdAt") FROM stdin;
e0ad568f-ac24-4bd3-a0ef-92945031ead4	cmjef4ht000001ctiwsloy31v	job_started	{}	success	\N	2025-12-20 14:54:16.304
f2f041fe-437b-4dc0-a15c-9446292dcbca	cmjef4pxg00011ctippp5x92o	job_started	{}	success	\N	2025-12-20 14:54:16.317
79e3c609-a407-4b3e-ae0d-bcb0584feb08	cmjef4ht000001ctiwsloy31v	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:16.331
d6b52fbb-5871-4fb4-b14c-f75c929ebfde	cmjef4pxg00011ctippp5x92o	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:16.343
a87e44d3-d9f5-4c5f-bbc7-80f66e6eb741	cmjef4ht000001ctiwsloy31v	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:16.38
5a9e20b9-7d49-4ccd-8086-63ef0acfd08c	cmjef4pxg00011ctippp5x92o	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:16.392
387ae8e0-840d-4988-bd2f-56336e515fb8	cmjef4qg000021ctijpe15wtz	job_started	{}	success	\N	2025-12-20 14:54:16.428
0b4ba222-44c7-43a9-a53c-e35f05912526	cmjef4qrd00031cti6spq9d3z	job_started	{}	success	\N	2025-12-20 14:54:16.441
1ed7978b-5e1b-446d-b478-a6e7ba59983f	cmjef4qg000021ctijpe15wtz	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:16.453
04a04bd4-d060-4be8-af1d-ee6b873c4c15	cmjef4qrd00031cti6spq9d3z	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:16.465
8310774f-c67c-4b9e-8175-bd126b3fa5a9	cmjef4qg000021ctijpe15wtz	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:16.502
eb780c7d-b405-44e1-87d3-a8895302628a	cmjef4qrd00031cti6spq9d3z	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:16.514
11c134ac-65eb-4ebd-9fb4-0dfabf60b5a1	cmjef4r3400041ctigwuptyzg	job_started	{}	success	\N	2025-12-20 14:54:16.552
3832f18e-e0c9-43ce-b6ca-e926e826293c	cmjef4rfh00051cti2q4oorup	job_started	{}	success	\N	2025-12-20 14:54:16.565
5242784b-04a9-414c-b0aa-763edc1ba1eb	cmjef4r3400041ctigwuptyzg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:16.577
d133c5ed-9276-4b02-ba5e-5b38d447024d	cmjef4rfh00051cti2q4oorup	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:16.59
78d5b572-288b-47f2-aff7-b5937c0405f7	cmjef4r3400041ctigwuptyzg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:16.627
8bad5f59-04db-444f-853d-bba5db89542a	cmjef4rfh00051cti2q4oorup	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:16.639
36fc8606-27bf-4f41-bed6-2bb77275c47b	cmjef4pxg00011ctippp5x92o	job_started	{}	success	\N	2025-12-20 14:54:17.44
92f96733-a8c5-4295-aa6b-d50ebb4ddb73	cmjef4ht000001ctiwsloy31v	job_started	{}	success	\N	2025-12-20 14:54:17.453
a7eb3dee-0d5b-4f0c-9be0-1eb24b287c00	cmjef4pxg00011ctippp5x92o	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:17.465
f77e3634-2bb4-4cd5-96a8-26be735e3fdc	cmjef4ht000001ctiwsloy31v	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:17.477
bda0a048-0435-4df0-9857-06aefececc75	cmjef4pxg00011ctippp5x92o	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:17.514
9cf43ac9-9a4b-47a4-990b-4908f09e3a4a	cmjef4ht000001ctiwsloy31v	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:17.526
1aef9190-d633-4553-a090-a7b2c80a4a1c	cmjef4qg000021ctijpe15wtz	job_started	{}	success	\N	2025-12-20 14:54:17.563
0aa8cf35-957c-4bfd-988d-532e28b82741	cmjef4qrd00031cti6spq9d3z	job_started	{}	success	\N	2025-12-20 14:54:17.575
a786e188-45c5-407e-836e-9b1516b2701f	cmjef4qg000021ctijpe15wtz	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:17.588
212de3dd-5349-46a2-a0e7-4e6cedb8e55a	cmjef4qrd00031cti6spq9d3z	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:17.6
826a9d27-1abc-4088-8c62-af2e6810fd14	cmjef4qg000021ctijpe15wtz	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:17.636
09e6bb76-506e-43cc-a4f1-a33156b8eb37	cmjef4qrd00031cti6spq9d3z	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:17.648
9f13b401-1459-4990-8271-6f4f95e9515a	cmjef4r3400041ctigwuptyzg	job_started	{}	success	\N	2025-12-20 14:54:17.685
44c1974d-8c09-42c6-889f-7da6b6634373	cmjef4rfh00051cti2q4oorup	job_started	{}	success	\N	2025-12-20 14:54:17.697
3ec507f7-5141-4b65-ad20-d71103f31a99	cmjef4r3400041ctigwuptyzg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:17.709
d32ea447-13a9-406f-a9b4-f00aadac3d5d	cmjef4rfh00051cti2q4oorup	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:17.722
2c630ec9-356c-4445-8fd1-d02dbe62a976	cmjef4r3400041ctigwuptyzg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:17.758
e2bdacc2-b1f2-45d6-bef2-a956da0e3934	cmjef4rfh00051cti2q4oorup	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:17.77
95ab82e8-d53d-4bb8-a43b-583dd1f5cc72	cmjef4pxg00011ctippp5x92o	job_started	{}	success	\N	2025-12-20 14:54:19.649
30472712-f768-4045-8d2e-8bf30674d0db	cmjef4ht000001ctiwsloy31v	job_started	{}	success	\N	2025-12-20 14:54:19.661
347566ae-e39e-46e5-b3bd-7176f8ed24e2	cmjef4pxg00011ctippp5x92o	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:19.674
7358f453-e9cc-40a9-a555-a428b91996ab	cmjef4ht000001ctiwsloy31v	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:19.686
4e9df597-80d5-427c-b0e9-26875b5e9111	cmjef4pxg00011ctippp5x92o	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:19.723
6214c82b-4365-43a1-9d5f-8e5643791392	cmjef4ht000001ctiwsloy31v	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:19.735
e8df5b6c-83d7-4a0d-8d8b-2cd131108f98	cmjef4qg000021ctijpe15wtz	job_started	{}	success	\N	2025-12-20 14:54:19.772
d57a628e-dfca-43fc-8ae0-c91be8b6cdf1	cmjef4qrd00031cti6spq9d3z	job_started	{}	success	\N	2025-12-20 14:54:19.784
b6c4d292-8a16-4c8b-9c7e-34784dd87407	cmjef4qg000021ctijpe15wtz	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:19.796
23b3db4b-bb8a-4b3f-b9d0-d1de0a22f234	cmjef4qrd00031cti6spq9d3z	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:19.808
535a2bd1-85de-4a55-8940-65bf3cac7352	cmjef4qg000021ctijpe15wtz	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:19.845
86882587-708a-48ab-9876-ae8f6e0c6a01	cmjef4qrd00031cti6spq9d3z	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:19.857
ec91f572-5d5b-493a-a18f-ba730dbc6988	cmjef4r3400041ctigwuptyzg	job_started	{}	success	\N	2025-12-20 14:54:19.894
1faa82ef-e7e7-47cf-a13a-7af2e5245927	cmjef4rfh00051cti2q4oorup	job_started	{}	success	\N	2025-12-20 14:54:19.906
c63338ad-53a0-4fc1-98b6-5b8647f1dffd	cmjef4r3400041ctigwuptyzg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:19.918
22c2bcb7-d47a-45f6-bee7-422059e44dc3	cmjef4rfh00051cti2q4oorup	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:19.93
de0ae8bb-63b2-45c1-abb6-7d114479c6fa	cmjef4r3400041ctigwuptyzg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:19.967
3d5cc4d1-6bed-4c15-9a8b-f6aa5c0f57b5	cmjef4rfh00051cti2q4oorup	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:19.979
c28da8e9-50d7-4023-bec6-7f7f81249345	cmjef4pxg00011ctippp5x92o	job_started	{}	success	\N	2025-12-20 14:54:23.766
f560981b-c14a-440d-b7be-74ca86f432f9	cmjef4pxg00011ctippp5x92o	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:23.78
0bd760d1-281e-4677-ac91-eca9b89c2161	cmjef4pxg00011ctippp5x92o	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:23.808
5911c416-d364-4338-9da7-45ddc219a4de	cmjef4ht000001ctiwsloy31v	job_started	{}	success	\N	2025-12-20 14:54:23.838
b178a1e3-7643-4053-8900-fd3eaf50fc5a	cmjef4ht000001ctiwsloy31v	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:23.851
6adbe9c3-836b-4b7e-baf1-d9ebeb5deea1	cmjef4ht000001ctiwsloy31v	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:23.879
6e9a0cc5-2410-4448-876a-3c984234e913	cmjef4qrd00031cti6spq9d3z	job_started	{}	success	\N	2025-12-20 14:54:23.921
f4fdd8cb-1b59-4adc-947a-6109ef7a8532	cmjef4qrd00031cti6spq9d3z	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:23.946
701bbf56-0bc0-420c-9270-f64139ce0277	cmjef4qrd00031cti6spq9d3z	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:23.995
bbf0e5a9-98c6-42c5-aca7-05c19f2fe558	cmjef4rfh00051cti2q4oorup	job_started	{}	success	\N	2025-12-20 14:54:24.044
90f01281-8e2d-4ba3-bd5a-ac82353b8e2b	cmjef4rfh00051cti2q4oorup	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:24.068
39555a5f-5933-4779-974d-475e39af0fc6	cmjef4rfh00051cti2q4oorup	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:24.117
afd2e4d2-9195-4ca7-b42a-996c8f2c17bd	cmjef4pxg00011ctippp5x92o	job_started	{}	success	\N	2025-12-20 14:54:31.89
63b9cd43-2a12-4be0-8b4f-5ac59b6cf9dc	cmjef4pxg00011ctippp5x92o	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:31.903
9f5ef43d-b9dd-41ba-ac82-523f28cc24a9	cmjef4pxg00011ctippp5x92o	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:31.931
4167e0e5-8687-483f-a407-2fe0567b58be	cmjef4ht000001ctiwsloy31v	job_started	{}	success	\N	2025-12-20 14:54:31.963
d50d5b08-56ff-43a0-8e9c-5e212810cce0	cmjef4ht000001ctiwsloy31v	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:31.976
f1ca4f9c-026e-4afa-a80c-8de6a9f265fa	cmjef4ht000001ctiwsloy31v	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:32.004
e19ef580-7dff-4a06-8518-bf5f9bc1002f	cmjef4qrd00031cti6spq9d3z	job_started	{}	success	\N	2025-12-20 14:54:32.047
fa19255d-306c-4967-8c58-c5ff3d2f9de7	cmjef4qrd00031cti6spq9d3z	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:32.071
ccfdbe81-0563-4a7d-8a53-fd64635bd0fe	cmjef4qrd00031cti6spq9d3z	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:32.12
b9bc8b6d-5ed7-42bb-b83b-cdee8477bc07	cmjef4rfh00051cti2q4oorup	job_started	{}	success	\N	2025-12-20 14:54:32.168
747939b8-6712-4e55-81e4-47ac7f187c80	cmjef4rfh00051cti2q4oorup	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:32.193
49b7cb7b-fbeb-4e4e-95a3-b8a9fa53222d	cmjef4rfh00051cti2q4oorup	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:32.243
fbf89e26-b84a-44e5-8145-e6646e9f5164	cmjef4qg000021ctijpe15wtz	job_started	{}	success	\N	2025-12-20 14:54:23.909
6f5161d8-e847-42ca-a30e-9694ee06eadb	cmjef4qg000021ctijpe15wtz	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:23.933
8efe8553-e8b2-4be0-a015-80e6750bfa3c	cmjef4qg000021ctijpe15wtz	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:23.983
4130f929-4fff-49f6-9a76-1a33f5083c15	cmjef4r3400041ctigwuptyzg	job_started	{}	success	\N	2025-12-20 14:54:24.031
db203494-55f1-441d-bf93-a7c758f83e57	cmjef4r3400041ctigwuptyzg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:24.056
1415374a-d07e-40c7-b577-c28ece678a1b	cmjef4r3400041ctigwuptyzg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:24.106
1c879d2d-06e6-4979-b19f-a5c32ce0a84e	cmjef4qg000021ctijpe15wtz	job_started	{}	success	\N	2025-12-20 14:54:32.035
654ee892-9ea1-4a1e-90a8-c32520f7950b	cmjef4qg000021ctijpe15wtz	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:32.059
47ce747b-cec1-43e7-b45a-3b5081830f32	cmjef4qg000021ctijpe15wtz	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:32.108
59a866d3-8564-49e7-bf82-9b26e8ab396b	cmjef4r3400041ctigwuptyzg	job_started	{}	success	\N	2025-12-20 14:54:32.156
50c9eb37-cdf7-4ddb-8650-3a14eebcb51f	cmjef4r3400041ctigwuptyzg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:32.18
03ec2ae6-6874-4a91-a1b9-3fce2f02d0bc	cmjef4r3400041ctigwuptyzg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:32.23
771badb7-343f-4a5e-932a-ce8ea35f5001	cmjef61yh00061cti2zkzifi4	job_started	{}	success	\N	2025-12-20 14:54:37.705
5075c137-2dd3-4b29-87b2-8ce4d6f65958	cmjef61yh00061cti2zkzifi4	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:37.719
e06700ec-aa00-4fe6-be09-580ab53a6fa6	cmjef61yh00061cti2zkzifi4	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:37.746
128ed729-649a-42c0-abad-f1bdde140b4a	cmjef62pa00071ctigc1iflnk	job_started	{}	success	\N	2025-12-20 14:54:38.668
188ba4cf-d055-4d62-8410-6495981e8b04	cmjef62pa00071ctigc1iflnk	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:38.682
7fc33d3d-a1b8-486a-b779-257cda10a3ed	cmjef62pa00071ctigc1iflnk	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:38.709
c7d655ac-b91f-402b-bfff-3287713a0ec8	cmjef61yh00061cti2zkzifi4	job_started	{}	success	\N	2025-12-20 14:54:38.818
2d787cea-5ff3-4ac3-a0ed-37fdd86ea684	cmjef61yh00061cti2zkzifi4	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:38.832
9428b95a-8c94-4bdf-811f-b7888368f86f	cmjef61yh00061cti2zkzifi4	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:38.859
ceb2a844-8326-48c9-969a-ebb4465ef571	cmjef62pa00071ctigc1iflnk	job_started	{}	success	\N	2025-12-20 14:54:39.825
8d2e5b8c-456f-454d-92c4-b73b18c0e73e	cmjef62pa00071ctigc1iflnk	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:39.838
4f3e0790-38b3-4d40-91e2-cebe41f6fde6	cmjef62pa00071ctigc1iflnk	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:39.866
51afa3c2-86ee-4472-9ec8-a3f2c538a4ff	cmjef61yh00061cti2zkzifi4	job_started	{}	success	\N	2025-12-20 14:54:40.929
409d072e-1f7a-482a-bff7-d6428a7eb692	cmjef61yh00061cti2zkzifi4	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:40.943
ac2dc506-c905-47cb-97da-7471b1f01ea1	cmjef61yh00061cti2zkzifi4	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:40.97
52ca5811-f373-45df-9ccd-8d7fb77a1885	cmjef62pa00071ctigc1iflnk	job_started	{}	success	\N	2025-12-20 14:54:41.932
26607e6f-b393-4d09-8e8c-c16bc405eaae	cmjef62pa00071ctigc1iflnk	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:41.945
7e7c939b-7d85-46e2-b34d-b0e30197d389	cmjef62pa00071ctigc1iflnk	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:41.973
87bf012b-5c3e-46ae-8dae-c6d654856422	cmjef65oo00081ctinsiqjs1b	job_started	{}	success	\N	2025-12-20 14:54:42.535
c5340ca9-e10a-4b34-8379-2242ac318509	cmjef65oo00081ctinsiqjs1b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:42.548
39d11d12-6474-45f1-85a1-c7d3eac1f48d	cmjef65oo00081ctinsiqjs1b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:42.575
30b26524-3f16-4ba1-9fe6-d52fd685205e	cmjef65oo00081ctinsiqjs1b	job_started	{}	success	\N	2025-12-20 14:54:43.638
6015943a-6872-40d5-b79f-2f922dfdea19	cmjef65oo00081ctinsiqjs1b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:43.652
e0c2e09b-3f69-4038-86b8-b67bee26cd49	cmjef65oo00081ctinsiqjs1b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:43.703
f534705a-8c69-499b-ad9a-32b2b2168e58	cmjef61yh00061cti2zkzifi4	job_started	{}	success	\N	2025-12-20 14:54:45.045
67519fae-494f-43c4-a171-f17177fcc67f	cmjef61yh00061cti2zkzifi4	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:45.059
ed3626fa-e1e4-414c-9fb9-f1d8f21d2d99	cmjef61yh00061cti2zkzifi4	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:45.087
acfaba91-04fa-4331-b53e-665a37c631a7	cmjef65oo00081ctinsiqjs1b	job_started	{}	success	\N	2025-12-20 14:54:45.848
98bcec50-b876-41a9-b447-2dba4794c525	cmjef65oo00081ctinsiqjs1b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:45.862
a685e23f-45db-47aa-a8b6-f710e65344e7	cmjef65oo00081ctinsiqjs1b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:45.889
36d5d4c9-d35e-4cb0-bc3c-e0fdf914f8cb	cmjef62pa00071ctigc1iflnk	job_started	{}	success	\N	2025-12-20 14:54:46.049
9106c498-888a-417b-b178-355d6f50a8c3	cmjef62pa00071ctigc1iflnk	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:46.063
c68ae516-aa28-4fd1-8e95-4cea58e3d935	cmjef62pa00071ctigc1iflnk	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:46.09
d46a8e52-7dc8-4962-9c25-7abd17af0025	cmjef6ahf00091cticyfm9jvl	job_started	{}	success	\N	2025-12-20 14:54:48.773
6f3f23f1-9e4e-477c-89cf-00c1b0f3b006	cmjef6ahf00091cticyfm9jvl	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:48.787
10014e4f-e9ac-4b99-8d86-7c6d32ec7775	cmjef6ahf00091cticyfm9jvl	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:48.814
22d65b7c-221b-4894-9256-4fda56852fc7	cmjef6ahf00091cticyfm9jvl	job_started	{}	success	\N	2025-12-20 14:54:49.867
77426704-617b-492a-9bb7-f1b09ea634ff	cmjef6ahf00091cticyfm9jvl	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:49.88
9ed3a835-a24c-416a-9272-540afc52e1c8	cmjef6ahf00091cticyfm9jvl	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:49.908
25c75748-d044-4127-97cc-147ff425757e	cmjef65oo00081ctinsiqjs1b	job_started	{}	success	\N	2025-12-20 14:54:49.938
9e804f93-f344-46ca-a0d9-bfe17844640d	cmjef65oo00081ctinsiqjs1b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:49.951
b822318a-307a-41ef-9955-b1bd1f33163b	cmjef65oo00081ctinsiqjs1b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:49.979
da55cf52-fb6c-4886-a5a1-a30e72b7057c	cmjef6ahf00091cticyfm9jvl	job_started	{}	success	\N	2025-12-20 14:54:51.979
2df45bbd-6692-48a3-890a-b39f137daf24	cmjef6ahf00091cticyfm9jvl	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:51.992
6bcb865f-4fe2-443b-8d48-f64a26f2998d	cmjef6ahf00091cticyfm9jvl	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:52.032
69af57e9-5b4d-4021-b45f-0f2f3b2c641a	cmjef61yh00061cti2zkzifi4	job_started	{}	success	\N	2025-12-20 14:54:53.185
e0051ca1-1e07-4808-91c3-e2211a76eee8	cmjef61yh00061cti2zkzifi4	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:53.199
4ed9a462-976a-4e0b-8712-6a077b71d0bf	cmjef61yh00061cti2zkzifi4	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:53.227
85c775a4-1208-46a0-8021-69a0c687ab7a	cmjef6e1b000a1ctiio88rnji	job_started	{}	success	\N	2025-12-20 14:54:53.357
5e68f94d-bc0d-4e68-9fc9-83d602358dc9	cmjef6e1b000a1ctiio88rnji	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:53.371
0418e1c0-d4e3-4854-88c1-790f4984baf7	cmjef6e1b000a1ctiio88rnji	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:53.398
e93a4cfb-d39b-4202-b412-7b3ac213fd72	cmjef62pa00071ctigc1iflnk	job_started	{}	success	\N	2025-12-20 14:54:54.19
3eaabdaf-4336-470a-99a1-baab323c3dd1	cmjef62pa00071ctigc1iflnk	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:54.226
d64aa565-0480-402f-bd60-330ddd5ddb34	cmjef62pa00071ctigc1iflnk	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:54.253
574a0acd-8c4f-4fad-974e-78f5e692fbb2	cmjef6erm000b1ctiuuc6xp8b	job_started	{}	success	\N	2025-12-20 14:54:54.304
c9b68778-e08a-49e6-bf9e-6467932a6fb6	cmjef6erm000b1ctiuuc6xp8b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:54.318
26fcb4a2-15df-41e5-8f9a-7f2f77b3977e	cmjef6erm000b1ctiuuc6xp8b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:54.345
52d383f7-1809-49a5-913f-81cffdb1772c	cmjef6e1b000a1ctiio88rnji	job_started	{}	success	\N	2025-12-20 14:54:54.493
881685e6-6a83-46af-af38-f60b9b37894b	cmjef6e1b000a1ctiio88rnji	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:54.507
c441c688-b334-4630-bb80-489f4fa1fba3	cmjef6e1b000a1ctiio88rnji	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:54.534
1f48c50f-bbee-4902-afd0-502b21d8260e	cmjef6f08000c1ctidqxzluix	job_started	{}	success	\N	2025-12-20 14:54:54.615
41a30fd8-51f9-4ff8-bdab-ee4b2ff5398e	cmjef6f08000c1ctidqxzluix	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:54.628
f8fccfa7-c25a-4b9b-ada7-c2c753405fdf	cmjef6f08000c1ctidqxzluix	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:54.655
4fbf2d22-be4b-49f1-bbf0-64205a49931e	cmjef6f9x000d1ctimbe919xg	job_started	{}	success	\N	2025-12-20 14:54:54.964
f1df0f16-bfdd-4325-8d3d-6ce9b6030e19	cmjef6f9x000d1ctimbe919xg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:54.978
33818af5-7bbc-4f88-9666-32769e07bde0	cmjef6f9x000d1ctimbe919xg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:55.005
d583feff-25d9-4e85-93f5-71429be10444	cmjef6erm000b1ctiuuc6xp8b	job_started	{}	success	\N	2025-12-20 14:54:55.395
51d87783-e111-4ee2-a509-6847fc28b61b	cmjef6erm000b1ctiuuc6xp8b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:55.409
0eb1fe71-f15c-42d6-bdcb-3f39f66f8ed6	cmjef6erm000b1ctiuuc6xp8b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:55.435
d2622c31-bfc0-4760-b0ad-8ef0e171d4f1	cmjef6fo7000e1ctiqp0xau4a	job_started	{}	success	\N	2025-12-20 14:54:55.478
561649bf-91ca-43f5-9178-50df85d247b9	cmjef6fo7000e1ctiqp0xau4a	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:55.491
8d198405-260a-4b43-b822-ef2cbe45041b	cmjef6fo7000e1ctiqp0xau4a	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:55.519
bff133c0-a576-466f-bb69-91379bcd09e1	cmjef6f08000c1ctidqxzluix	job_started	{}	success	\N	2025-12-20 14:54:55.697
eeb4845e-7d77-4ef7-b767-f4a29a235e7f	cmjef6f08000c1ctidqxzluix	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:55.71
1e080b14-c414-439f-8bfd-3fb593569774	cmjef6f08000c1ctidqxzluix	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:55.738
59224362-7b40-4a73-9dc3-131cec016438	cmjef6fz6000f1ctihbqsy4ik	job_started	{}	success	\N	2025-12-20 14:54:55.873
e2e76f38-6861-4c92-9ce4-bdbb7a5178af	cmjef6fz6000f1ctihbqsy4ik	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:55.886
1d01cdab-9183-4ef3-a6f2-396800274e1f	cmjef6fz6000f1ctihbqsy4ik	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:55.913
b50dad4d-2c73-4924-b2dc-c66dd4893109	cmjef6f9x000d1ctimbe919xg	job_started	{}	success	\N	2025-12-20 14:54:56.1
a3cf4aab-6dc0-4fe6-b522-46a4a98e6f8e	cmjef6ahf00091cticyfm9jvl	job_started	{}	success	\N	2025-12-20 14:54:56.112
e56aa64c-de4d-4745-af07-9e249d465458	cmjef6f9x000d1ctimbe919xg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:56.125
9685e5be-c0fc-4ee8-9452-cb5f9704a406	cmjef6ahf00091cticyfm9jvl	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:56.137
66c64b19-8e3a-47d6-8bbc-eb5069c74bd6	cmjef6f9x000d1ctimbe919xg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:56.173
2439f288-d915-42b5-97a4-8ccd45d615d6	cmjef6ahf00091cticyfm9jvl	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:56.186
4d83a298-7142-42b3-93f8-8ec452f508e2	cmjef6fo7000e1ctiqp0xau4a	job_started	{}	success	\N	2025-12-20 14:54:56.604
922221b5-f3f4-4f12-b584-589dc838f6c2	cmjef6e1b000a1ctiio88rnji	job_started	{}	success	\N	2025-12-20 14:54:56.604
75e5626b-c4ea-4f28-a319-f0a084852762	cmjef6fo7000e1ctiqp0xau4a	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:56.618
540a5e2f-e006-4acb-a620-ba91422810ea	cmjef6e1b000a1ctiio88rnji	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:56.63
cf6e102b-2ab2-4bef-80c3-21d39dfc5d11	cmjef6fo7000e1ctiqp0xau4a	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:56.667
ddd63a6e-4c35-4e4f-8d70-9392c3de7eca	cmjef6e1b000a1ctiio88rnji	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:56.679
2262b64d-c86b-44b2-9ce4-d199f6c8a7f6	cmjef6fz6000f1ctihbqsy4ik	job_started	{}	success	\N	2025-12-20 14:54:57.006
cdc57ec1-5fe3-478e-857c-6a1724c136fe	cmjef6fz6000f1ctihbqsy4ik	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:57.02
1a1f1e4c-b32f-4fb3-b369-67d80e339c9f	cmjef6fz6000f1ctihbqsy4ik	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:57.048
c108d6b7-192c-452f-8c1b-ca218f5b8adf	cmjef6erm000b1ctiuuc6xp8b	job_started	{}	success	\N	2025-12-20 14:54:57.508
64cf4c82-ac49-4f7c-ab7e-45c05be6774b	cmjef6erm000b1ctiuuc6xp8b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:57.522
e0e6ebb3-b9b1-404f-be26-645fa869b560	cmjef6erm000b1ctiuuc6xp8b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:57.549
26b03b39-6d90-4357-94b0-aced9566877f	cmjef6f08000c1ctidqxzluix	job_started	{}	success	\N	2025-12-20 14:54:57.811
4ff8ceac-ef7d-46f4-b4bc-52a1c296865d	cmjef6f08000c1ctidqxzluix	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:57.824
5beff099-1c98-4ec8-8af3-b00b6d6972c6	cmjef6f08000c1ctidqxzluix	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:57.852
a5546bc3-ff23-4253-92da-694a368f979c	cmjef65oo00081ctinsiqjs1b	job_started	{}	success	\N	2025-12-20 14:54:58.013
944b7958-8ae0-4459-be7d-a4744145e990	cmjef65oo00081ctinsiqjs1b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:58.026
dd6b8deb-9535-4f0e-ae10-db17e41f6160	cmjef65oo00081ctinsiqjs1b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:58.054
704917ea-24c3-4130-b8ad-602ebfabcc78	cmjef6f9x000d1ctimbe919xg	job_started	{}	success	\N	2025-12-20 14:54:58.315
34c316b4-9fca-4378-ad5b-73d84ae88841	cmjef6f9x000d1ctimbe919xg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:58.329
816c1e10-3efd-4af7-ac60-c8fdf6d08d98	cmjef6f9x000d1ctimbe919xg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:58.356
2ecfe821-2305-4cd0-b786-6699609757f2	cmjef6fo7000e1ctiqp0xau4a	job_started	{}	success	\N	2025-12-20 14:54:58.718
b46c2867-41a8-40b7-aeb3-74e96cd71012	cmjef6fo7000e1ctiqp0xau4a	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:58.732
5f53aa99-cb15-4be2-a2f0-9228903b6cae	cmjef6fo7000e1ctiqp0xau4a	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:58.76
bc5259f1-1137-4494-bb23-03dfc44b9c5f	cmjef6fz6000f1ctihbqsy4ik	job_started	{}	success	\N	2025-12-20 14:54:59.12
0d9d67a8-ba0b-4013-946a-1bf1f63763d8	cmjef6fz6000f1ctihbqsy4ik	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:54:59.134
9cbe92cd-538f-49bc-a44d-19ec9b9a9057	cmjef6fz6000f1ctihbqsy4ik	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:54:59.161
aad91b95-8278-4e13-8aff-fa12847b6627	cmjef6e1b000a1ctiio88rnji	job_started	{}	success	\N	2025-12-20 14:55:00.727
34366152-e075-42a9-8ffb-759eb55448e4	cmjef6e1b000a1ctiio88rnji	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:00.741
a16e5b45-8f9b-46a3-bc12-b45299e8dd77	cmjef6e1b000a1ctiio88rnji	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:00.769
fb2ed7f0-eb4c-4a85-8ca9-bbcaa07f72f5	cmjef6erm000b1ctiuuc6xp8b	job_started	{}	success	\N	2025-12-20 14:55:01.632
e17f67ef-c725-4483-a58d-4cc94d7f2cce	cmjef6erm000b1ctiuuc6xp8b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:01.645
1a7eddcb-ea88-4411-98f0-bfd165ce4d1f	cmjef6erm000b1ctiuuc6xp8b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:01.673
49ba7de4-e8e7-4038-85a2-2d134dd59cbf	cmjef6f08000c1ctidqxzluix	job_started	{}	success	\N	2025-12-20 14:55:01.934
caa14822-a571-4ab7-9ac2-23b889cef96f	cmjef6f08000c1ctidqxzluix	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:01.948
65d673f1-fdf9-4fd7-9141-6d6104ec6af5	cmjef6f08000c1ctidqxzluix	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:01.975
3e7aace5-d74b-4478-b762-252a20c45961	cmjef6f9x000d1ctimbe919xg	job_started	{}	success	\N	2025-12-20 14:55:02.436
f1b6eb6e-b773-407d-8cc9-cf6cee70383b	cmjef6f9x000d1ctimbe919xg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:02.45
b50e3f9f-8664-4cfc-a7dc-3c3c0db26ad3	cmjef6f9x000d1ctimbe919xg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:02.478
344a671e-031a-45f5-99fd-ed668ffd4923	cmjef6fo7000e1ctiqp0xau4a	job_started	{}	success	\N	2025-12-20 14:55:02.839
0a361457-96e8-4efb-ab89-5452e7c4ce7e	cmjef6fo7000e1ctiqp0xau4a	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:02.853
6f40c5ee-d8ba-4bf5-ad9b-adb421d0beb6	cmjef6fo7000e1ctiqp0xau4a	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:02.881
5618873a-f0c9-4acc-96fa-b4d8fa857c34	cmjef6fz6000f1ctihbqsy4ik	job_started	{}	success	\N	2025-12-20 14:55:03.244
44a9a877-d060-49ce-a7f1-b879cabba123	cmjef6fz6000f1ctihbqsy4ik	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:03.257
b7f60857-2c03-44f6-8d37-f9d0f5e9cec5	cmjef6fz6000f1ctihbqsy4ik	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:03.288
cf56d6e2-6e11-4dc2-8ba9-363fd43ed304	cmjef6ahf00091cticyfm9jvl	job_started	{}	success	\N	2025-12-20 14:55:04.247
cad7a50a-57e9-4f9b-bb68-4f391ae2a9d5	cmjef6ahf00091cticyfm9jvl	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:04.261
e15d146b-2c15-4c4c-8dbf-d615fb8ca86c	cmjef6ahf00091cticyfm9jvl	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:04.288
5952cf17-5e72-4c8c-8014-fe10fc26096d	cmjef6e1b000a1ctiio88rnji	job_started	{}	success	\N	2025-12-20 14:55:08.872
117c583e-1305-4f40-b011-1f2e5ec5142e	cmjef6e1b000a1ctiio88rnji	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:08.885
c171dd5e-a876-470f-a89d-46158252cfe2	cmjef6e1b000a1ctiio88rnji	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:08.913
0dbc1f2f-3870-456a-8bfa-e8ac573ddf0f	cmjef6erm000b1ctiuuc6xp8b	job_started	{}	success	\N	2025-12-20 14:55:09.776
956a9f75-6a7d-44cd-8569-5561ed659c51	cmjef6erm000b1ctiuuc6xp8b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:09.79
61e1281c-75a9-4aaa-b942-e4b3d4ee023d	cmjef6erm000b1ctiuuc6xp8b	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:09.817
bb4b5362-e4b4-4176-a951-a59820c886a6	cmjef6f08000c1ctidqxzluix	job_started	{}	success	\N	2025-12-20 14:55:10.08
d7407557-073a-403a-8c9a-6483a949069b	cmjef6f08000c1ctidqxzluix	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:10.093
16a38241-fedd-4d6f-a9b7-8b97343ca2f2	cmjef6f08000c1ctidqxzluix	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:10.121
f5ec0738-af1e-404a-8a00-6f0de32d2e1b	cmjef6f9x000d1ctimbe919xg	job_started	{}	success	\N	2025-12-20 14:55:10.58
c60a79e1-7afe-492a-9afc-1f04b227eceb	cmjef6f9x000d1ctimbe919xg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:10.594
faf5659a-c7e3-4340-acfe-436028a9dfd1	cmjef6f9x000d1ctimbe919xg	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:10.621
897dadee-67f4-4422-a7ec-4743647b6f5e	cmjef6fo7000e1ctiqp0xau4a	job_started	{}	success	\N	2025-12-20 14:55:10.984
c4933c79-d905-4ffb-824a-0b32f6735c30	cmjef6fo7000e1ctiqp0xau4a	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:10.998
45dad710-64d7-4a67-83d2-f9cd284ae835	cmjef6fo7000e1ctiqp0xau4a	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:11.025
908dcbcc-19f3-41b1-9059-5908fc80d605	cmjef6fz6000f1ctihbqsy4ik	job_started	{}	success	\N	2025-12-20 14:55:11.385
fddef53c-7f3b-4c7f-83f4-2345b15c880c	cmjef6fz6000f1ctihbqsy4ik	provider_ready	{"provider": "local"}	success	\N	2025-12-20 14:55:11.399
f84b5a55-2fd6-4264-bd87-14cbb72bc331	cmjef6fz6000f1ctihbqsy4ik	job_failed	{"error": "database is required for pg_dump"}	failed	\N	2025-12-20 14:55:11.427
4b94ff54-5dab-4834-a4f8-2a2d96bcf64a	cmjefkjj000001crm2rfodmuj	job_started	{}	success	\N	2025-12-20 15:05:53.766
eb89a5db-8760-4483-b9a3-c56e3c87f2e2	cmjefkjj000001crm2rfodmuj	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:05:53.781
705a90c3-7404-423c-b16b-733137b7a09c	cmjefkjj000001crm2rfodmuj	archive_ready	{}	success	\N	2025-12-20 15:05:53.802
d8ba7d9d-3265-4bf5-91a5-40aa7541dafc	cmjefkjj000001crm2rfodmuj	upload_started	{"remotePath": "backup-1766243153551-1766243153815.tar.gz"}	started	\N	2025-12-20 15:05:53.816
a931591e-68fb-441a-a6e3-599670e77f43	cmjefkjj000001crm2rfodmuj	job_started	{}	success	\N	2025-12-20 15:09:48.496
45d10ab1-b655-4532-bc1a-6df66ec7997d	cmjefkjj000001crm2rfodmuj	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:09:48.511
f20d852f-8eb0-4324-8bfa-330e5272307a	cmjefkjj000001crm2rfodmuj	archive_ready	{}	success	\N	2025-12-20 15:09:48.531
8b2ca8ef-7e3d-4ffd-941f-08b51bd95e0e	cmjefkjj000001crm2rfodmuj	upload_started	{"remotePath": "backup-1766243153551-1766243388543.tar.gz"}	started	\N	2025-12-20 15:09:48.545
db48766e-0fc1-4ec7-ac72-8a472e9af719	cmjefpmc400001c3ihtrogh3b	job_started	{}	success	\N	2025-12-20 15:11:25.677
7a59710c-ee3a-4121-a516-4b827b8c5d6a	cmjefpmc400001c3ihtrogh3b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:11:25.692
fdf19f86-01d5-4cc7-af2e-09fcbf74e21b	cmjefpmc400001c3ihtrogh3b	archive_ready	{}	success	\N	2025-12-20 15:11:25.713
0ca32ee6-9933-450c-9444-fde38bd94d6b	cmjefpmc400001c3ihtrogh3b	upload_started	{"remotePath": "backup-1766243390456-1766243485726.tar.gz"}	started	\N	2025-12-20 15:11:25.727
b5118560-20a7-4492-9fe2-491c87ac4320	cmjefpmc400001c3ihtrogh3b	job_started	{}	success	\N	2025-12-20 15:13:33.56
6b4ee28e-4ddd-4c7f-915d-66d695bed516	cmjefpmc400001c3ihtrogh3b	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:13:33.575
590b6d1d-260d-40a7-93c6-0adca94db5e5	cmjefpmc400001c3ihtrogh3b	archive_ready	{}	success	\N	2025-12-20 15:13:33.596
df8a4a25-9a5e-4d5c-aeff-b7a09cc1086b	cmjefpmc400001c3ihtrogh3b	upload_started	{"remotePath": "backup-1766243390456-1766243613609.tar.gz"}	started	\N	2025-12-20 15:13:33.61
518cba52-9c6d-44a1-b29e-f57ba117058b	cmjeg6lnz00001c7vrj7fv22g	job_started	{}	success	\N	2025-12-20 15:23:02.966
3a3fcaff-86b6-46b9-8d35-165fbb086132	cmjeg6lnz00001c7vrj7fv22g	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:23:02.981
dd697464-bd31-4989-a0e5-4f30697c6942	cmjeg6lnz00001c7vrj7fv22g	archive_ready	{}	success	\N	2025-12-20 15:23:03.003
abdbc664-e204-4494-928c-37add2de9b4a	cmjeg6lnz00001c7vrj7fv22g	upload_started	{"remotePath": "backup-1766244182742-1766244183016.tar.gz"}	started	\N	2025-12-20 15:23:03.017
2c18fe7a-726a-4bdc-9d41-2c52442eeab2	cmjeg6lnz00001c7vrj7fv22g	job_started	{}	success	\N	2025-12-20 15:25:23.689
ff0d13b5-ac96-4068-9672-ce19563643c9	cmjeg6lnz00001c7vrj7fv22g	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:25:23.704
89f912ae-2490-4f3f-81cd-c38641bb181b	cmjeg6lnz00001c7vrj7fv22g	archive_ready	{}	success	\N	2025-12-20 15:25:23.724
be9aa7b7-9fdc-4809-8ed6-4a2c641dd0bc	cmjeg6lnz00001c7vrj7fv22g	upload_started	{"remotePath": "backup-1766244182742-1766244323737.tar.gz"}	started	\N	2025-12-20 15:25:23.738
55f88acb-7449-47ff-b905-495a48c3a6c5	cmjeglazj00011c7vge2fli5p	job_started	{}	success	\N	2025-12-20 15:40:57.758
ac34777f-24ce-4a1e-abdd-e5e8d97d69eb	cmjeglazj00011c7vge2fli5p	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:40:57.773
bf64e05e-551a-4656-bf0b-d7f8d48055d9	cmjeglazj00011c7vge2fli5p	archive_ready	{}	success	\N	2025-12-20 15:40:57.793
b00db413-d22e-4843-b367-77d53d301a2b	cmjeglazj00011c7vge2fli5p	upload_started	{"remotePath": "backup-1766244868817-1766245257806.tar.gz"}	started	\N	2025-12-20 15:40:57.807
833b5f41-3561-4dd3-ad70-ad342d944b37	cmjeglazj00011c7vge2fli5p	job_started	{}	success	\N	2025-12-20 15:50:43.86
bb4dcd72-0bd3-48ce-ac08-79b6f2f81773	cmjeglazj00011c7vge2fli5p	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:50:43.896
84a3dfc5-48ad-470b-9b2d-370749eaef78	cmjeglazj00011c7vge2fli5p	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:50:43.968
81fb5aa7-4979-4ba3-b7c1-9c064fe0e544	cmjeglazj00011c7vge2fli5p	job_started	{}	success	\N	2025-12-20 15:50:45.088
47a2ad2e-fed2-49cc-9ace-e79ae5ebb932	cmjeglazj00011c7vge2fli5p	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:50:45.102
9ea611e9-3caf-4f38-9aa9-ca1e5e3553b5	cmjeglazj00011c7vge2fli5p	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:50:45.129
48a750c7-ac08-409d-a43e-e508b33eb705	cmjeglazj00011c7vge2fli5p	job_started	{}	success	\N	2025-12-20 15:50:47.196
e7e848d4-0acc-47ba-95a5-b0c6de5ede3c	cmjeglazj00011c7vge2fli5p	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:50:47.211
c54f4e4c-5651-4ec4-a30a-ed8335b12035	cmjeglazj00011c7vge2fli5p	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:50:47.273
971bb954-9369-4f77-937e-71ed4d68e00d	cmjeglazj00011c7vge2fli5p	job_started	{}	success	\N	2025-12-20 15:50:51.311
d9627820-c7bb-4d89-8279-d41f391a9899	cmjeglazj00011c7vge2fli5p	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:50:51.325
6afecb46-39a8-4fb8-a014-dfef7a2b3b83	cmjeglazj00011c7vge2fli5p	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:50:51.353
270170b9-2e8c-4a8a-a388-a8095828c9b2	cmjeglazj00011c7vge2fli5p	job_started	{}	success	\N	2025-12-20 15:50:59.439
222921b5-b833-406f-af7e-315e5e446973	cmjeglazj00011c7vge2fli5p	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:50:59.453
49b05b68-e61f-4d69-9812-353fd59535d9	cmjeglazj00011c7vge2fli5p	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:50:59.48
7b26335b-afdf-48bb-b16c-a83e9ed58fb3	cmjehah6p00001cr4g228eyqt	job_started	{}	success	\N	2025-12-20 15:54:03.433
f751ff32-7736-4783-a036-ad6b4bb35fa4	cmjehah6p00001cr4g228eyqt	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:54:03.448
cc8f80f8-4bce-4e74-9dbb-d7a559d1b575	cmjehah6p00001cr4g228eyqt	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:54:03.477
9b891e4b-9111-40de-bb5d-ebe75efeb92a	cmjehah6p00001cr4g228eyqt	job_started	{}	success	\N	2025-12-20 15:54:04.532
2db2e30e-b278-436a-923f-badfa54f8e66	cmjehah6p00001cr4g228eyqt	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:54:04.546
9fadf33d-e5f5-4d71-876a-167c450a0af5	cmjehah6p00001cr4g228eyqt	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:54:04.574
19024fe6-92bc-4faa-81d5-c2c2a64925ab	cmjehah6p00001cr4g228eyqt	job_started	{}	success	\N	2025-12-20 15:54:06.638
bfc80015-6f74-4e62-9446-89b7bd3aec24	cmjehah6p00001cr4g228eyqt	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:54:06.651
a16bee09-25e1-4879-8a51-5997d9453d1a	cmjehah6p00001cr4g228eyqt	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:54:06.679
27f09412-68cc-4452-9b47-5380972f86c0	cmjehah6p00001cr4g228eyqt	job_started	{}	success	\N	2025-12-20 15:54:10.753
866d85f1-49d6-4a75-9528-0faaa0781e2f	cmjehah6p00001cr4g228eyqt	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:54:10.766
fdc761b5-883c-48f3-b775-578a8f90b7ae	cmjehah6p00001cr4g228eyqt	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:54:10.794
db938954-fb49-4a00-951f-f9a5290348ec	cmjehah6p00001cr4g228eyqt	job_started	{}	success	\N	2025-12-20 15:54:18.883
fd619157-6a28-4cc8-bc7e-32b88f0a7a67	cmjehah6p00001cr4g228eyqt	provider_ready	{"provider": "local"}	success	\N	2025-12-20 15:54:18.897
0fdd4afe-2007-4424-b0a3-42c56890a186	cmjehsrum00051cr42b4bsfb2	archive_ready	{}	success	\N	2025-12-20 16:14:21.341
c0cc3962-033d-4894-abe7-09a13b091b40	cmjehah6p00001cr4g228eyqt	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 15:54:18.925
7649ee74-9de6-458f-b73e-0b29c0800423	cmjeho9hi00011cr4fk7pm2qo	job_started	{}	success	\N	2025-12-20 16:04:46.526
c391fd15-3391-418c-8ac2-4436880c5e22	cmjeho9hi00011cr4fk7pm2qo	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:46.54
4b47e837-602a-4360-94c4-139ff48461c9	cmjeho9hi00011cr4fk7pm2qo	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:46.569
2d6c3aa9-06ca-410b-b446-4883cd92bb0b	cmjehoa4z00021cr4hi4293l0	job_started	{}	success	\N	2025-12-20 16:04:47.347
efed02e3-c80f-4a52-8800-4529339c7f49	cmjehoa4z00021cr4hi4293l0	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:47.36
4e50b601-76bb-49f0-b6f8-5c0a09a301c7	cmjehoa4z00021cr4hi4293l0	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:47.388
51c1316d-4de0-4b03-92bf-e8f054f25ada	cmjeho9hi00011cr4fk7pm2qo	job_started	{}	success	\N	2025-12-20 16:04:47.631
6a9fd27d-5d45-4375-9dc0-957c603861e9	cmjeho9hi00011cr4fk7pm2qo	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:47.644
62a5a7c9-5ee7-41eb-97e0-389ff64aa71d	cmjeho9hi00011cr4fk7pm2qo	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:47.672
f96c9292-e700-4db1-b389-5909a1ddcad4	cmjehoald00031cr4xqquzwpa	job_started	{}	success	\N	2025-12-20 16:04:47.937
b5774abf-0f87-455c-ac1d-bbacf8c7b895	cmjehoald00031cr4xqquzwpa	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:47.952
a819b150-4a37-4b37-90bf-5d5a64c1e800	cmjehoald00031cr4xqquzwpa	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:47.983
7e2f11a3-d3b4-45a1-9813-87135032aad5	cmjehoa4z00021cr4hi4293l0	job_started	{}	success	\N	2025-12-20 16:04:48.436
9e87d5c4-92b9-489d-a2f8-46c74ff0dcb5	cmjehoa4z00021cr4hi4293l0	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:48.45
560a05e0-ed58-4516-a593-bae9430fcd5f	cmjehoa4z00021cr4hi4293l0	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:48.478
425f0b61-b9aa-4198-9264-f232a6875847	cmjehoald00031cr4xqquzwpa	job_started	{}	success	\N	2025-12-20 16:04:49.037
9ba53da8-796c-4695-b87f-d748e897f21e	cmjehoald00031cr4xqquzwpa	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:49.05
a86c70c8-3e18-49f5-9652-29118482775a	cmjehoald00031cr4xqquzwpa	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:49.077
c76ce08c-c6e1-48ba-a041-0fd5ecca915c	cmjeho9hi00011cr4fk7pm2qo	job_started	{}	success	\N	2025-12-20 16:04:49.739
de0c9a99-9b4b-438a-96c2-224510bc828b	cmjeho9hi00011cr4fk7pm2qo	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:49.752
4a45a410-8cea-4054-9497-62285ca886c0	cmjeho9hi00011cr4fk7pm2qo	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:49.779
3b821823-d9ee-455b-b2d2-0b4860cc0d7b	cmjehoa4z00021cr4hi4293l0	job_started	{}	success	\N	2025-12-20 16:04:50.542
0a3e80dc-3cce-4abb-8b2e-62ae7315808c	cmjehoa4z00021cr4hi4293l0	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:50.556
0ff3033e-48a9-49d1-8f15-218d967d294c	cmjehoa4z00021cr4hi4293l0	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:50.583
cbc8bbff-8630-4b36-9b74-493494f0d303	cmjehoald00031cr4xqquzwpa	job_started	{}	success	\N	2025-12-20 16:04:51.143
982688c7-24b1-4d79-b93e-e014b3b0355f	cmjehoald00031cr4xqquzwpa	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:51.157
9d86cdd8-471e-4e39-ad15-78815e343401	cmjehoald00031cr4xqquzwpa	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:51.196
ed793992-997f-4f50-a33b-c0be6b015485	cmjeho9hi00011cr4fk7pm2qo	job_started	{}	success	\N	2025-12-20 16:04:53.855
9efb791b-e744-4929-8fcd-c52cb53a65ea	cmjeho9hi00011cr4fk7pm2qo	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:53.868
827ff59a-72bf-4eb4-ac7b-14ba1bede131	cmjeho9hi00011cr4fk7pm2qo	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:53.896
3349994f-b2ab-4d36-81cb-3236ae450e54	cmjehoa4z00021cr4hi4293l0	job_started	{}	success	\N	2025-12-20 16:04:54.656
f217d48c-433b-450a-8653-cb9d4066a00d	cmjehoa4z00021cr4hi4293l0	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:54.669
f41456d9-da9d-452e-8489-2fc6e49a1ecf	cmjehoa4z00021cr4hi4293l0	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:54.696
aab0dd17-27bb-42fb-9b36-7580d27ea614	cmjehoald00031cr4xqquzwpa	job_started	{}	success	\N	2025-12-20 16:04:55.257
8b19ee67-c6e2-4b13-99cf-d8a7f354fc0b	cmjehoald00031cr4xqquzwpa	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:04:55.27
2d2a5437-83c8-4700-9cb2-9118563142cd	cmjehoald00031cr4xqquzwpa	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:04:55.298
900cb941-cc2c-4e63-bf72-3b58faf6ec17	cmjeho9hi00011cr4fk7pm2qo	job_started	{}	success	\N	2025-12-20 16:05:01.979
6d30a885-6f12-4671-90f7-abf2d6b1a702	cmjeho9hi00011cr4fk7pm2qo	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:05:01.993
57cf3708-7931-4680-a791-712d3e53fd47	cmjeho9hi00011cr4fk7pm2qo	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:05:02.021
de64e66c-2584-470f-970d-959e7a4902ac	cmjehoa4z00021cr4hi4293l0	job_started	{}	success	\N	2025-12-20 16:05:02.782
f4391b11-5f51-47b7-adde-011d4da88295	cmjehoa4z00021cr4hi4293l0	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:05:02.796
2525531f-2132-41d6-b138-fa99429b4f95	cmjehoa4z00021cr4hi4293l0	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:05:02.823
2811d1eb-3a00-4e83-873e-b7bcf32fac40	cmjehoald00031cr4xqquzwpa	job_started	{}	success	\N	2025-12-20 16:05:03.384
ee701357-986e-449f-8975-76c3f29930b6	cmjehoald00031cr4xqquzwpa	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:05:03.398
1dade483-e8e3-45e3-b67c-ad5842fd33cd	cmjehoald00031cr4xqquzwpa	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:05:03.425
e7dc49ba-8426-47c2-b537-aca4c1684b34	cmjehsr4y00041cr4ybx67vi7	job_started	{}	success	\N	2025-12-20 16:08:16.113
cf50af6f-56e9-41c8-ab87-07dfc2795043	cmjehsr4y00041cr4ybx67vi7	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:08:16.128
c4d86d84-affd-4675-996c-1cf18ea3b4ca	cmjehsr4y00041cr4ybx67vi7	archive_ready	{}	success	\N	2025-12-20 16:08:16.148
511e6245-3cd1-4483-bcdf-8e4ec51e5b93	cmjehsr4y00041cr4ybx67vi7	upload_started	{"remotePath": "backup-1766246895969-1766246896160.tar.gz"}	started	\N	2025-12-20 16:08:16.162
521d11a9-cbfe-4aa3-908c-8e1df32e88d6	cmjehsxlx00061cr4tqbabn8c	job_started	{}	success	\N	2025-12-20 16:14:21.275
91107f3c-a0a3-4f70-b8fe-11443c364251	cmjehsrum00051cr42b4bsfb2	job_started	{}	success	\N	2025-12-20 16:14:21.288
f44a7f39-bb42-4ad1-bfe2-c5629e2349c8	cmjehsxlx00061cr4tqbabn8c	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:14:21.301
0aff6257-309b-4ec7-8ea3-8caa9ea9b435	cmjehsrum00051cr42b4bsfb2	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:14:21.313
bb800a00-557a-4bc7-a319-25f35ed5209f	cmjehsxlx00061cr4tqbabn8c	archive_ready	{}	success	\N	2025-12-20 16:14:21.333
354b9492-c96d-4dc5-8cdf-f47db5b79fbe	cmjehsxlx00061cr4tqbabn8c	upload_started	{"remotePath": "backup-1766246904356-1766247261349.tar.gz"}	started	\N	2025-12-20 16:14:21.35
93ef3d65-9bf7-4a70-b3af-32c80be866b9	cmjehsrum00051cr42b4bsfb2	upload_started	{"remotePath": "backup-1766246896894-1766247261361.tar.gz"}	started	\N	2025-12-20 16:14:21.362
d07233df-b9b2-4376-a21e-974c08ff4c7d	cmjehsr4y00041cr4ybx67vi7	job_started	{}	success	\N	2025-12-20 16:16:18.511
aec63bfb-79b1-4a8d-9aae-5290113318eb	cmjehsxz800071cr4s6t9z0dx	job_started	{}	success	\N	2025-12-20 16:16:18.523
bb20464c-412e-4249-a892-0ee49b35d938	cmjehsr4y00041cr4ybx67vi7	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:16:18.536
902dc5d9-4a8c-4f25-8649-11464e277a8c	cmjehsxz800071cr4s6t9z0dx	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:16:18.548
6ff1ada3-18df-415c-8d53-9834be40ea51	cmjehsr4y00041cr4ybx67vi7	archive_ready	{}	success	\N	2025-12-20 16:16:18.568
098f27e0-8bad-4ba0-9638-13d5e49a1be2	cmjehsxz800071cr4s6t9z0dx	archive_ready	{}	success	\N	2025-12-20 16:16:18.576
8f9f87c9-1ca0-421a-b06c-c12c90c0e032	cmjehsr4y00041cr4ybx67vi7	upload_started	{"remotePath": "backup-1766246895969-1766247378584.tar.gz"}	started	\N	2025-12-20 16:16:18.585
6cd09105-1a76-47b8-9351-20e322569f36	cmjehsxz800071cr4s6t9z0dx	upload_started	{"remotePath": "backup-1766246904835-1766247378596.tar.gz"}	started	\N	2025-12-20 16:16:18.597
a4d13b7c-f1cb-4600-bc6f-73ebeac752c1	cmjehsxlx00061cr4tqbabn8c	job_started	{}	success	\N	2025-12-20 16:17:55.962
baa94a58-c05e-4205-aae3-918598c00551	cmjehsrum00051cr42b4bsfb2	job_started	{}	success	\N	2025-12-20 16:17:55.974
1dd56d02-719f-4c3a-99fa-f715a14bc326	cmjehsxlx00061cr4tqbabn8c	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:17:55.987
03e3e542-b6e3-4961-8842-464a41826bbb	cmjehsrum00051cr42b4bsfb2	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:17:55.999
39b7cff4-4db9-4d36-a40e-8fc5455e852c	cmjehsxlx00061cr4tqbabn8c	archive_ready	{}	success	\N	2025-12-20 16:17:56.019
36d11ecd-aac1-43e3-b1e6-bc1a82b4622e	cmjehsrum00051cr42b4bsfb2	archive_ready	{}	success	\N	2025-12-20 16:17:56.027
265b9139-25d1-4dc0-a286-07d05207d28c	cmjehsxlx00061cr4tqbabn8c	upload_started	{"remotePath": "backup-1766246904356-1766247476035.tar.gz"}	started	\N	2025-12-20 16:17:56.036
37272d50-b2a9-4975-8d28-339bb302d83c	cmjehsrum00051cr42b4bsfb2	upload_started	{"remotePath": "backup-1766246896894-1766247476047.tar.gz"}	started	\N	2025-12-20 16:17:56.048
2092e7c4-569c-4ab9-b98d-d40d82a38303	cmjehsxz800071cr4s6t9z0dx	job_started	{}	success	\N	2025-12-20 16:20:11.322
9ed19105-280f-4cb5-8e6f-152f43f97723	cmjehsxz800071cr4s6t9z0dx	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:20:11.337
7bb6eb57-2983-4001-8b49-256b6d6c2425	cmjehsxz800071cr4s6t9z0dx	archive_ready	{}	success	\N	2025-12-20 16:20:11.357
2e5925e9-2cc3-4b24-b04b-fa4e28f47fe2	cmjehsxz800071cr4s6t9z0dx	upload_started	{"remotePath": "backup-1766246904835-1766247611370.tar.gz"}	started	\N	2025-12-20 16:20:11.371
319572a5-ec9a-4b9d-9248-ed78fb830162	cmjei9s5i00001cx35ep9y944	job_started	{}	success	\N	2025-12-20 16:21:30.563
49cac3e1-940d-457f-8f69-16cd6c2d6e7f	cmjei9s5i00001cx35ep9y944	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:21:30.578
e1f2979d-0834-429e-8503-ed53e058cd70	cmjei9s5i00001cx35ep9y944	archive_ready	{}	success	\N	2025-12-20 16:21:30.601
021c3dac-c297-47ff-af9c-8cc68cab5f27	cmjei9s5i00001cx35ep9y944	upload_started	{"remotePath": "backup-1766247690363-1766247690614.tar.gz"}	started	\N	2025-12-20 16:21:30.615
90697e05-92aa-4fcd-a1bb-c245c7640935	cmjei9sok00011cx35mdc3zak	job_started	{}	success	\N	2025-12-20 16:25:41.285
de629515-f1e8-4ca7-a702-5e85a99e3bb0	cmjei9swp00021cx3326rxtve	job_started	{}	success	\N	2025-12-20 16:25:41.298
4b0d3bf9-7d3c-4d39-8ba2-ff2aacc9e25c	cmjei9sok00011cx35mdc3zak	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:41.31
c71ada6b-82cb-4156-bdcc-0a0f5590b113	cmjei9swp00021cx3326rxtve	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:41.323
785c9a8d-d0bb-41a6-a3f6-db3ee9abebaf	cmjei9sok00011cx35mdc3zak	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:41.36
18272498-9ed5-4d7c-91bd-48e9fabd13c5	cmjei9swp00021cx3326rxtve	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:41.372
dbf788a6-1772-4112-9364-e19ac69dacd8	cmjeia2rs00031cx3eu4wlg0l	job_started	{}	success	\N	2025-12-20 16:25:41.409
f9096095-5fc3-408d-bde5-1dae8a8bb0d2	cmjeia86j00041cx3b0sn86bv	job_started	{}	success	\N	2025-12-20 16:25:41.421
942af70c-da33-4c51-a455-4a0d93382025	cmjeia2rs00031cx3eu4wlg0l	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:41.433
846aba85-e31e-403a-9374-7696f2e4197f	cmjeia86j00041cx3b0sn86bv	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:41.445
18205d59-62d0-45d4-843a-50866bb0e52d	cmjeia2rs00031cx3eu4wlg0l	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:41.482
39a7ac08-7f6b-4fbd-a209-d40e498ad0f2	cmjeia86j00041cx3b0sn86bv	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:41.494
0657cecb-dd84-49b9-9859-5e3496862285	cmjei9swp00021cx3326rxtve	job_started	{}	success	\N	2025-12-20 16:25:42.465
61026025-8d6d-4126-abba-390a63e27ebe	cmjei9sok00011cx35mdc3zak	job_started	{}	success	\N	2025-12-20 16:25:42.478
ac58df11-2d34-4d04-a5e8-31de9a39ebe6	cmjei9swp00021cx3326rxtve	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:42.49
0dac99ed-d48a-4fad-8a84-4fc480dd9f7b	cmjei9sok00011cx35mdc3zak	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:42.503
a5e3fd11-127a-406d-87f5-007656d36db0	cmjei9swp00021cx3326rxtve	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:42.539
d2be0c61-04d1-436d-b411-a2e7340737eb	cmjei9sok00011cx35mdc3zak	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:42.551
e9eeac0b-014a-4b08-9855-543823f072db	cmjeia2rs00031cx3eu4wlg0l	job_started	{}	success	\N	2025-12-20 16:25:42.588
822ba046-5593-4fa5-b235-deee68a0d395	cmjeia86j00041cx3b0sn86bv	job_started	{}	success	\N	2025-12-20 16:25:42.6
3a48c331-e02b-45be-af13-0951b7d67f66	cmjeia2rs00031cx3eu4wlg0l	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:42.613
704dc76a-0929-4182-a26d-48e5a29e8a0a	cmjeia86j00041cx3b0sn86bv	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:42.625
4e88e74d-5877-4d51-8cb4-2bab3aecabdd	cmjeia2rs00031cx3eu4wlg0l	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:42.662
71dc2cc1-6742-452d-9f70-4773d4d4ffd3	cmjeia86j00041cx3b0sn86bv	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:42.674
b90523cc-3911-482f-ad83-92d944953268	cmjei9swp00021cx3326rxtve	job_started	{}	success	\N	2025-12-20 16:25:44.674
fb2bf598-7ffc-4928-8367-0781edaf8536	cmjei9sok00011cx35mdc3zak	job_started	{}	success	\N	2025-12-20 16:25:44.687
c1a728ae-45d1-4c7d-83e8-bfb12bc18dd2	cmjei9swp00021cx3326rxtve	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:44.699
7f5dbdb2-b2b2-4e37-bbfd-2e3d40fccbf1	cmjei9sok00011cx35mdc3zak	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:44.711
84c1eef7-6591-406b-a8ff-0786a3525e9e	cmjei9swp00021cx3326rxtve	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:44.748
047c9ee3-ece3-4c00-b2e7-ddfb5e697d14	cmjeia2rs00031cx3eu4wlg0l	job_started	{}	success	\N	2025-12-20 16:25:44.797
c5c8af5d-b0db-4973-8980-8e5f5c80af59	cmjei9sok00011cx35mdc3zak	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:44.76
0dbfea58-0e59-4b7d-95e7-9712ebaf121d	cmjeia86j00041cx3b0sn86bv	job_started	{}	success	\N	2025-12-20 16:25:44.809
3806f638-979c-4d07-90e5-721934a761f1	cmjeia86j00041cx3b0sn86bv	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:44.833
943cd6f1-21c2-4f05-a521-4ad73c056d91	cmjeia86j00041cx3b0sn86bv	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:44.882
c26b96cb-b2bd-4f17-b773-ae94ff0033ab	cmjei9sok00011cx35mdc3zak	job_started	{}	success	\N	2025-12-20 16:25:48.901
8290cc68-421c-449d-b9fa-aa4bb0dc40c3	cmjei9sok00011cx35mdc3zak	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:48.927
9f814728-ed3c-4598-b50c-79447a9cbbdc	cmjei9sok00011cx35mdc3zak	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:48.976
6d5d168c-5450-4559-a03f-7a11dfe8778a	cmjeia86j00041cx3b0sn86bv	job_started	{}	success	\N	2025-12-20 16:25:49.025
ca565c7c-c444-471b-aa76-f796605e9d7e	cmjeia86j00041cx3b0sn86bv	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:49.05
3ba7b2b7-382d-4eee-899c-02a92807ac6c	cmjeia86j00041cx3b0sn86bv	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:49.098
60ab3409-e703-4363-9a45-3f97bcdf0bd2	cmjei9sok00011cx35mdc3zak	job_started	{}	success	\N	2025-12-20 16:25:57.019
4ae07908-6500-419a-ad37-2cb0fbca36ad	cmjei9sok00011cx35mdc3zak	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:57.043
e375cde6-27b0-4ed7-94d6-96863ee2e05f	cmjei9sok00011cx35mdc3zak	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:57.092
c8ee3d84-d172-4e8a-9827-0cfe820e88ab	cmjeia2rs00031cx3eu4wlg0l	job_started	{}	success	\N	2025-12-20 16:25:57.141
8a85cedc-4130-494f-ae9c-f44b86f5a18f	cmjeia2rs00031cx3eu4wlg0l	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:57.165
96e1421b-c6dc-45b4-9e06-4557fc79a714	cmjeia2rs00031cx3eu4wlg0l	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:57.214
7c0069eb-ed2a-4024-bbdc-e3ec412ddf8a	cmjeia2rs00031cx3eu4wlg0l	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:44.821
91ce474d-0ed6-4bf0-ac61-d507311cd242	cmjeia2rs00031cx3eu4wlg0l	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:44.87
7ca12566-8f99-4a65-aa41-9d21204d7e03	cmjei9swp00021cx3326rxtve	job_started	{}	success	\N	2025-12-20 16:25:48.888
646f5d4a-7e9c-4577-bd21-a10e55feed7b	cmjei9swp00021cx3326rxtve	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:48.914
f75a3f98-7a92-4c2f-8fe0-2fb0b7393fbb	cmjei9swp00021cx3326rxtve	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:48.964
766a8073-3b10-4efc-a49b-956f501e4ade	cmjeia2rs00031cx3eu4wlg0l	job_started	{}	success	\N	2025-12-20 16:25:49.013
298cebfe-8e43-44b7-b466-89907c5a8aff	cmjeia2rs00031cx3eu4wlg0l	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:49.037
aa792577-66d2-46eb-9f25-875f83f00984	cmjeia2rs00031cx3eu4wlg0l	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:49.087
37c2d487-918e-4afe-976c-6157e55c0be3	cmjei9swp00021cx3326rxtve	job_started	{}	success	\N	2025-12-20 16:25:57.031
9b515a73-9458-48d8-92c5-34d8b7bccc0e	cmjei9swp00021cx3326rxtve	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:57.056
59f6e39d-f44d-41f0-b790-8ef512c07df4	cmjei9swp00021cx3326rxtve	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:57.104
4ac9626b-43f0-4432-8ba5-bff13738d531	cmjeia86j00041cx3b0sn86bv	job_started	{}	success	\N	2025-12-20 16:25:57.153
770f1650-1a44-4485-b654-672f3ba205fd	cmjeia86j00041cx3b0sn86bv	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:25:57.177
73979a8b-f970-46c9-bc74-773ca9634533	cmjeia86j00041cx3b0sn86bv	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:25:57.226
1e7cd754-4d39-481e-91b2-83de7e50d4d9	cmjei9s5i00001cx35ep9y944	job_started	{}	success	\N	2025-12-20 16:26:11.213
912b6b59-0a3a-43b9-b02c-8f3e65b3723f	cmjei9s5i00001cx35ep9y944	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:26:11.226
10bbd50d-651f-4d28-a04c-508030976fd3	cmjei9s5i00001cx35ep9y944	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:26:11.256
e49e4489-80fb-4690-95fa-9d9d2a7718aa	cmjei9s5i00001cx35ep9y944	job_started	{}	success	\N	2025-12-20 16:26:12.37
0bcda5c4-24ae-46d8-ad1f-194d9bfb29f5	cmjei9s5i00001cx35ep9y944	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:26:12.383
1811e6a2-4b1a-445f-8026-6292edd5127f	cmjei9s5i00001cx35ep9y944	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:26:12.411
f1a0b0b2-5283-45ec-9a96-813ca2031028	cmjei9s5i00001cx35ep9y944	job_started	{}	success	\N	2025-12-20 16:26:14.474
f43bd7da-5e23-4b2f-8271-2820ad22abf9	cmjei9s5i00001cx35ep9y944	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:26:14.488
fca999d1-1995-4d87-8ee8-066c0eb377fb	cmjei9s5i00001cx35ep9y944	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:26:14.516
219f1256-db75-4e25-806d-69e24da13914	cmjei9s5i00001cx35ep9y944	job_started	{}	success	\N	2025-12-20 16:26:18.587
5d3fea77-76db-47bb-8cdc-6f544939b7d2	cmjei9s5i00001cx35ep9y944	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:26:18.6
cc751faf-bd71-4458-bba2-dab1daceafa4	cmjei9s5i00001cx35ep9y944	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:26:18.627
9a6e1218-a6d4-4f79-9af9-e0929ef49d64	cmjei9s5i00001cx35ep9y944	job_started	{}	success	\N	2025-12-20 16:26:26.707
fcede7a4-859d-41cd-8633-051b27bd13df	cmjei9s5i00001cx35ep9y944	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:26:26.72
9ef93d1d-4450-4c6b-8fb5-e8f5ca3b2083	cmjei9s5i00001cx35ep9y944	job_failed	{"error": "pgDumpToGzipStream is not a function"}	failed	\N	2025-12-20 16:26:26.747
ec7665d7-43f2-4add-9746-21e3d81d1b99	cmjeilj4400051cx3bbji19ro	job_started	{}	success	\N	2025-12-20 16:30:38.73
7abaf7a8-ec6d-4731-b04f-a6d8753007f6	cmjeilj4400051cx3bbji19ro	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:30:38.744
fcf2b5e7-8a1b-49ed-913d-c65146b69c85	cmjeilj4400051cx3bbji19ro	db_dump_started	{}	started	\N	2025-12-20 16:30:38.758
b9627812-4fa2-418d-895a-199b3cc2cfa8	cmjeilj4400051cx3bbji19ro	db_dump_finished	{}	success	\N	2025-12-20 16:30:38.892
545391e0-2fbf-4cb0-9d08-c28bf95ed872	cmjeilj4400051cx3bbji19ro	archive_ready	{}	success	\N	2025-12-20 16:30:38.907
bb7fe000-4e22-4ea2-a1f8-07f6a56d8459	cmjeilj4400051cx3bbji19ro	upload_started	{"remotePath": "backup-1766248238576-1766248238920.tar.gz"}	started	\N	2025-12-20 16:30:38.921
52d4a63c-f7fa-4d9d-9139-d04d58ea4cec	cmjeilj4400051cx3bbji19ro	upload_finished	{"sizeBytes": 32410, "remotePath": "backup-1766248238576-1766248238920.tar.gz"}	success	\N	2025-12-20 16:30:38.981
de0e479f-41a6-4cce-8569-098b6736f058	cmjeiljt400061cx3pyn59pxj	job_started	{}	success	\N	2025-12-20 16:30:39.528
3850f4d5-9549-4558-aae9-69dfc7706c7d	cmjeiljt400061cx3pyn59pxj	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:30:39.542
ce2587e5-752e-410c-967a-17d7764840d6	cmjeiljt400061cx3pyn59pxj	db_dump_started	{}	started	\N	2025-12-20 16:30:39.556
880cc60e-4b94-43b7-8529-7306cfb13f82	cmjeiljt400061cx3pyn59pxj	db_dump_finished	{}	success	\N	2025-12-20 16:30:39.706
1cf246c4-b4bd-44a6-a088-066472a16223	cmjeiljt400061cx3pyn59pxj	archive_ready	{}	success	\N	2025-12-20 16:30:39.721
268e9db0-84f9-420d-9c2d-bc8279fb07bc	cmjeiljt400061cx3pyn59pxj	upload_started	{"remotePath": "backup-1766248239495-1766248239734.tar.gz"}	started	\N	2025-12-20 16:30:39.735
9378631f-68e4-4762-b58f-acc7cc199de9	cmjeiljt400061cx3pyn59pxj	upload_finished	{"sizeBytes": 32783, "remotePath": "backup-1766248239495-1766248239734.tar.gz"}	success	\N	2025-12-20 16:30:39.78
47aeacf5-1ae0-4927-8ce3-3d909d1d53b4	cmjeill5i00071cx3y28p8kj6	job_started	{}	success	\N	2025-12-20 16:30:41.27
2a4317a2-993a-47c4-8687-c87f879131e7	cmjeill5i00071cx3y28p8kj6	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:30:41.283
b054d39f-7b9c-496e-8665-402f24a8aa3d	cmjeill5i00071cx3y28p8kj6	db_dump_started	{}	started	\N	2025-12-20 16:30:41.297
36c195ba-a8cb-4ef2-b8c8-9c7df916d78b	cmjeill5i00071cx3y28p8kj6	db_dump_finished	{}	success	\N	2025-12-20 16:30:41.446
cd320585-da13-4532-a51e-af5f348ed55e	cmjeill5i00071cx3y28p8kj6	archive_ready	{}	success	\N	2025-12-20 16:30:41.459
2416808d-6580-4031-815c-e1313f1788d1	cmjeill5i00071cx3y28p8kj6	upload_started	{"remotePath": "backup-1766248241237-1766248241472.tar.gz"}	started	\N	2025-12-20 16:30:41.473
d06fb610-4f68-452f-99dc-69ce5391c7b5	cmjeill5i00071cx3y28p8kj6	upload_finished	{"sizeBytes": 33123, "remotePath": "backup-1766248241237-1766248241472.tar.gz"}	success	\N	2025-12-20 16:30:41.517
e3a3a0f1-0472-432f-9971-4ec67b86bdc1	cmjeilley00081cx305wdh1pl	job_started	{}	success	\N	2025-12-20 16:30:41.61
9516e52f-a83f-4750-8aba-c41d632be6a5	cmjeilley00081cx305wdh1pl	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:30:41.625
8e891b46-1f0c-4530-a1c9-085809675d71	cmjeilley00081cx305wdh1pl	db_dump_started	{}	started	\N	2025-12-20 16:30:41.639
28fcc073-15dd-4c98-84d9-99f0eb015ee8	cmjeilley00081cx305wdh1pl	db_dump_finished	{}	success	\N	2025-12-20 16:30:41.843
a788766b-6f0a-45bc-b83d-ce3d1f0aab32	cmjeilley00081cx305wdh1pl	archive_ready	{}	success	\N	2025-12-20 16:30:41.857
38278677-7c80-48fe-9e55-01315a094c94	cmjeilley00081cx305wdh1pl	upload_started	{"remotePath": "backup-1766248241577-1766248241870.tar.gz"}	started	\N	2025-12-20 16:30:41.871
5eb688bb-0bc6-44fe-a5cf-fa9caef7295b	cmjeilley00081cx305wdh1pl	upload_finished	{"sizeBytes": 33471, "remotePath": "backup-1766248241577-1766248241870.tar.gz"}	success	\N	2025-12-20 16:30:41.915
7d988437-1947-4233-98dd-21ec1824ccea	cmjeim06400001c6eqv8n9uvd	job_started	{}	success	\N	2025-12-20 16:31:00.734
0a983897-46e9-4d43-8a80-2e0d1ee1c036	cmjeim06400001c6eqv8n9uvd	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:31:00.748
b5405ba8-6143-431a-a9b2-db5516c8dd6a	cmjeim06400001c6eqv8n9uvd	db_dump_started	{}	started	\N	2025-12-20 16:31:00.761
0424fe48-b0b9-4c82-ac1f-273a3bd21332	cmjeim06400001c6eqv8n9uvd	db_dump_finished	{}	success	\N	2025-12-20 16:31:00.917
b469dd61-0c1f-4063-a4f3-e067f362f5e7	cmjeim06400001c6eqv8n9uvd	archive_ready	{}	success	\N	2025-12-20 16:31:00.93
22762175-3170-4444-bef4-71a5eae5951b	cmjeim06400001c6eqv8n9uvd	upload_started	{"remotePath": "backup-1766248260615-1766248260943.tar.gz"}	started	\N	2025-12-20 16:31:00.944
bb92f4a3-62ff-4668-9286-59a5ac67981d	cmjeim06400001c6eqv8n9uvd	upload_finished	{"sizeBytes": 33795, "remotePath": "backup-1766248260615-1766248260943.tar.gz"}	success	\N	2025-12-20 16:31:00.988
4a3e31aa-39c3-4612-924e-2fa9d521b185	cmjeim0vs00011c6emq1lygjt	job_started	{}	success	\N	2025-12-20 16:31:01.656
54a01dc5-8984-4809-8c89-4a861885c42e	cmjeim0vs00011c6emq1lygjt	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:31:01.669
4944e027-6e1e-4c39-9b7d-35d722cef2fe	cmjeim0vs00011c6emq1lygjt	db_dump_started	{}	started	\N	2025-12-20 16:31:01.683
e85fcb7f-0f8a-4cfb-a184-63741df0294d	cmjeim0vs00011c6emq1lygjt	db_dump_finished	{}	success	\N	2025-12-20 16:31:01.895
ff577b28-a0b4-4ba7-b244-6966591ed706	cmjeim0vs00011c6emq1lygjt	archive_ready	{}	success	\N	2025-12-20 16:31:01.909
c9098e07-e616-47e2-b9e0-dd285143ef05	cmjeim0vs00011c6emq1lygjt	upload_started	{"remotePath": "backup-1766248261623-1766248261922.tar.gz"}	started	\N	2025-12-20 16:31:01.923
e85b5e3e-3942-433d-a05e-eb8db5fea56f	cmjeim0vs00011c6emq1lygjt	upload_finished	{"sizeBytes": 34154, "remotePath": "backup-1766248261623-1766248261922.tar.gz"}	success	\N	2025-12-20 16:31:01.967
d7423f35-c514-481f-a63e-d9af10a7af3f	cmjeim1ef00021c6ein562dgg	job_started	{}	success	\N	2025-12-20 16:31:02.34
477c2f55-f69e-4c57-8af7-55fe68fd4658	cmjeim1ef00021c6ein562dgg	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:31:02.354
439328fa-86b8-4ac5-ab3d-108314f89112	cmjeim1ef00021c6ein562dgg	db_dump_started	{}	started	\N	2025-12-20 16:31:02.367
128a6eec-3bf4-4262-b6e2-b02a8f9066a1	cmjeim1ef00021c6ein562dgg	db_dump_finished	{}	success	\N	2025-12-20 16:31:02.55
0df1b780-6784-422e-b9d5-176815233277	cmjeim1ef00021c6ein562dgg	archive_ready	{}	success	\N	2025-12-20 16:31:02.564
3315ebe3-951a-428c-88bb-801abb890e1a	cmjeim1ef00021c6ein562dgg	upload_started	{"remotePath": "backup-1766248262295-1766248262576.tar.gz"}	started	\N	2025-12-20 16:31:02.577
8e6c1e03-55ec-432c-8659-57477826804c	cmjeim1ef00021c6ein562dgg	upload_finished	{"sizeBytes": 34488, "remotePath": "backup-1766248262295-1766248262576.tar.gz"}	success	\N	2025-12-20 16:31:02.621
4844bfb7-2c17-4ae3-83ce-c95fbc2ba33c	cmjeim21f00031c6ezkfpb4b6	job_started	{}	success	\N	2025-12-20 16:31:03.155
b11a1397-9646-4855-a91c-74c5a8f38115	cmjeim21f00031c6ezkfpb4b6	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:31:03.168
f1e41bac-fad6-45a5-8e72-6d68e0b62a2f	cmjeim21f00031c6ezkfpb4b6	db_dump_started	{}	started	\N	2025-12-20 16:31:03.182
805af052-37d2-47ec-bd82-c8d844f56e9e	cmjeim21f00031c6ezkfpb4b6	db_dump_finished	{}	success	\N	2025-12-20 16:31:03.322
9cccd3f2-41c3-48e5-8a64-daf408ce732e	cmjeim21f00031c6ezkfpb4b6	archive_ready	{}	success	\N	2025-12-20 16:31:03.335
3c382a0c-963d-4280-b7ba-7c1cc186f94d	cmjeim21f00031c6ezkfpb4b6	upload_started	{"remotePath": "backup-1766248263122-1766248263348.tar.gz"}	started	\N	2025-12-20 16:31:03.349
97582338-77eb-42e5-b500-7230a078180a	cmjeim21f00031c6ezkfpb4b6	upload_finished	{"sizeBytes": 34818, "remotePath": "backup-1766248263122-1766248263348.tar.gz"}	success	\N	2025-12-20 16:31:03.393
2b15029d-8905-46ac-89e1-56597aa542ed	cmjeiog3x00001c9qapzfi300	job_started	{}	success	\N	2025-12-20 16:32:54.702
875ec193-39d4-4184-9871-d67c8ec9b3f7	cmjeiog3x00001c9qapzfi300	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:32:54.715
7b1c384c-8f0c-4cc6-8a00-9343aba0ad48	cmjeiog3x00001c9qapzfi300	db_dump_started	{}	started	\N	2025-12-20 16:32:54.729
295314fb-3534-4cf5-8235-11c15ea69dfe	cmjeiog3x00001c9qapzfi300	db_dump_finished	{}	success	\N	2025-12-20 16:32:54.875
c98846d6-c5d9-47a2-b23a-f7255bb173ae	cmjeiog3x00001c9qapzfi300	archive_ready	{}	success	\N	2025-12-20 16:32:54.889
0bbe2d02-2463-4ffe-8529-d062ef3514da	cmjeiog3x00001c9qapzfi300	upload_started	{"remotePath": "backup-1766248374572-1766248374901.tar.gz"}	started	\N	2025-12-20 16:32:54.902
1e8317f2-c907-44f2-90ca-38b89290cf09	cmjeiog3x00001c9qapzfi300	upload_finished	{"sizeBytes": 35172, "remotePath": "backup-1766248374572-1766248374901.tar.gz"}	success	\N	2025-12-20 16:32:54.946
36c363dc-0591-496e-a072-774514936ac3	cmjeiogxq00011c9qnzdycnzj	job_started	{}	success	\N	2025-12-20 16:32:55.774
890109eb-b922-41f1-8aa2-60daf624b0ae	cmjeiogxq00011c9qnzdycnzj	provider_ready	{"provider": "local"}	success	\N	2025-12-20 16:32:55.788
5eff7340-8a34-4019-90e9-84984816cb2a	cmjeiogxq00011c9qnzdycnzj	db_dump_started	{}	started	\N	2025-12-20 16:32:55.801
d00f5124-3531-4105-ae8f-8e0ef36f4103	cmjeiogxq00011c9qnzdycnzj	db_dump_finished	{}	success	\N	2025-12-20 16:32:55.94
e02bff86-f3a0-4496-bb80-986e796adcbc	cmjeiogxq00011c9qnzdycnzj	archive_ready	{}	success	\N	2025-12-20 16:32:55.954
5dd1e790-1b1e-4eaa-b849-b8e1195d1fbb	cmjeiogxq00011c9qnzdycnzj	upload_started	{"remotePath": "backup-1766248375742-1766248375967.tar.gz"}	started	\N	2025-12-20 16:32:55.967
23403463-87c6-43cc-9a8c-b7a02ce60b78	cmjeiogxq00011c9qnzdycnzj	upload_finished	{"sizeBytes": 35510, "remotePath": "backup-1766248375742-1766248375967.tar.gz"}	success	\N	2025-12-20 16:32:56.01
1793e673-c265-4f9e-83f4-e63764d81701	cmjejrtre00021c9quw7qzxhb	job_started	{}	success	\N	2025-12-20 17:03:32.081
b0aae109-77a2-44e8-9f73-de29d7cac19d	cmjejrtre00021c9quw7qzxhb	provider_ready	{"provider": "local"}	success	\N	2025-12-20 17:03:32.096
c6086011-34b2-4550-8c00-9e798239bcbc	cmjejrtre00021c9quw7qzxhb	db_dump_started	{}	started	\N	2025-12-20 17:03:32.109
122ccae2-fd80-40a0-84e4-9f2bb27dd492	cmjejrtre00021c9quw7qzxhb	db_dump_finished	{}	success	\N	2025-12-20 17:03:32.28
1c1a7ec1-0b65-4a04-9a44-65108c2cf1b6	cmjejrtre00021c9quw7qzxhb	archive_ready	{}	success	\N	2025-12-20 17:03:32.295
bcf9d1d8-2a68-4701-845e-8603cf7297fd	cmjejrtre00021c9quw7qzxhb	upload_started	{"remotePath": "Manual-1766250211922-1766250212308.tar.gz"}	started	\N	2025-12-20 17:03:32.309
fcf5bb15-da8f-4d32-9fca-bbf42cb86921	cmjejrtre00021c9quw7qzxhb	upload_finished	{"sizeBytes": 36185, "remotePath": "Manual-1766250211922-1766250212308.tar.gz"}	success	\N	2025-12-20 17:03:32.357
7c27db7b-2066-4cc9-948d-00e09d54ab5e	cmjejxg6700001cxe6zmglxz4	job_started	{}	success	\N	2025-12-20 17:07:54.317
e083b482-6171-494f-ae7b-76ba9d6d3074	cmjejxg6700001cxe6zmglxz4	provider_ready	{"provider": "local"}	success	\N	2025-12-20 17:07:54.331
caac30c5-6060-47e9-adfd-9ce816e12414	cmjejxg6700001cxe6zmglxz4	db_dump_started	{}	started	\N	2025-12-20 17:07:54.345
\.


--
-- Data for Name: BackupVersion; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."BackupVersion" (id, "backupId", version, "filePath", "sizeBytes", "createdAt") FROM stdin;
dd3f8b26-7cad-4e0b-98f9-dc888de2b11f	cmjeilj4400051cx3bbji19ro	1	backup-1766248238576-1766248238920.tar.gz	32410	2025-12-20 16:30:38.954
88c15b0f-9701-4e2f-8cad-0adf9653316e	cmjeiljt400061cx3pyn59pxj	1	backup-1766248239495-1766248239734.tar.gz	32783	2025-12-20 16:30:39.766
72fe5041-a5c0-487a-ab7c-0722a5c8a4fe	cmjeill5i00071cx3y28p8kj6	1	backup-1766248241237-1766248241472.tar.gz	33123	2025-12-20 16:30:41.503
dd66464f-b5cb-45ee-a63d-5a8ce31c64d4	cmjeilley00081cx305wdh1pl	1	backup-1766248241577-1766248241870.tar.gz	33471	2025-12-20 16:30:41.901
edacb80e-fc98-43c8-8080-97f174e3220b	cmjeim06400001c6eqv8n9uvd	1	backup-1766248260615-1766248260943.tar.gz	33795	2025-12-20 16:31:00.974
b087cc57-797e-44a6-8dfb-c78d6466dbfe	cmjeim0vs00011c6emq1lygjt	1	backup-1766248261623-1766248261922.tar.gz	34154	2025-12-20 16:31:01.954
c811b909-62b7-4079-a358-8fbd757cb39b	cmjeim1ef00021c6ein562dgg	1	backup-1766248262295-1766248262576.tar.gz	34488	2025-12-20 16:31:02.607
1ec052b4-441c-469c-b3ba-37839114b7c5	cmjeim21f00031c6ezkfpb4b6	1	backup-1766248263122-1766248263348.tar.gz	34818	2025-12-20 16:31:03.379
1c9d2516-d1e4-4bab-81c8-4b11171c80a9	cmjeiog3x00001c9qapzfi300	1	backup-1766248374572-1766248374901.tar.gz	35172	2025-12-20 16:32:54.933
566a49a3-98a7-4a26-a6cd-34b5563fc206	cmjeiogxq00011c9qnzdycnzj	1	backup-1766248375742-1766248375967.tar.gz	35510	2025-12-20 16:32:55.997
8d96b2dd-35a4-48c2-8eaa-4a3fe711f7a0	cmjejrtre00021c9quw7qzxhb	1	Manual-1766250211922-1766250212308.tar.gz	36185	2025-12-20 17:03:32.343
\.


--
-- Data for Name: ClientProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ClientProfile" (id, "userId", company, phone, address, country, city, postal) FROM stdin;
\.


--
-- Data for Name: DNSRecord; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."DNSRecord" (id, "domainId", type, name, value, ttl, "providerId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: DeveloperProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."DeveloperProfile" (id, "userId", "displayName", website, github, "payoutsEmail", "createdAt", "marketplaceMeta", "publicKeyPem", "storeName", "stripeAccountId", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Domain; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Domain" (id, name, provider, status, "expiryDate", nameservers, metadata, "createdAt", "updatedAt", deleted, "deletedAt") FROM stdin;
\.


--
-- Data for Name: DomainLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."DomainLog" (id, "domainId", action, message, meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: EmailEvent; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."EmailEvent" (id, "jobId", "eventType", "providerId", payload, "createdAt") FROM stdin;
\.


--
-- Data for Name: EmailJob; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."EmailJob" (id, "templateId", "templateName", "toEmail", "toName", payload, status, attempts, "lastError", priority, provider, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: EmailTemplate; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."EmailTemplate" (id, name, subject, "bodyHtml", "bodyText", language, "isDefault", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: EmailToken; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."EmailToken" (id, "userId", "tokenHash", type, "createdAt", "expiresAt", used) FROM stdin;
\.


--
-- Data for Name: Impersonation; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Impersonation" (id, "adminId", "impersonatedId", "startedAt", "endedAt", "sessionToken", reason) FROM stdin;
\.


--
-- Data for Name: IpAccessRule; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."IpAccessRule" (id, pattern, type, description, active, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: LoginLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."LoginLog" (id, "userId", "userEmail", success, ip, "userAgent", reason, "createdAt") FROM stdin;
7615c2fa-a18c-4188-87bd-dd2fd77a946f	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-18 18:22:25.162
56bbb3a5-4f1e-48d6-a219-9f79e6fd6b9b	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-18 18:22:27.003
9545aaae-a73c-4079-8f19-b9827df718d5	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-18 18:23:32.279
f0ba35b2-d4e7-4ad1-8067-d7968dbc049a	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-18 18:37:31.962
71955e3d-3802-4441-98c3-4692171a2cb4	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-18 18:39:34.019
24b54a7c-04be-4f30-a86e-ea79a1d22775	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-18 18:40:58.141
411ed08a-1a50-4fd9-9ed0-6e73b915cfb2	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-18 18:41:09.873
f9bad985-141f-447f-a71d-26d8156eabde	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-18 18:44:50.448
85d93445-0bd6-460d-aa33-5c08f8945a62	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-18 18:44:51.936
468612e0-fdf9-439e-a841-8cf6b018353d	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-18 18:45:01.481
03f871c3-b8d7-40a1-bced-2d2fe6bef2be	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-18 18:48:44.077
e4f3f36a-4de5-4942-8560-2378eb4825f3	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 12:05:34.012
8fab85b4-8c5e-446a-b90c-f74d31e5f4f5	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 12:06:04.447
b23701d5-4198-4f79-9ecb-57d5a3fb9bc9	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-19 12:39:06.682
c7227e53-cf48-42cb-a25f-d188ea4b1e8c	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-19 12:39:07.821
4650ad15-37d8-4cf0-8719-bdb0425d5dff	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-19 12:39:18.022
5ab2f77d-e8b1-4200-9894-584326966f96	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 12:39:56.251
f3d2f5c7-7baf-43f6-b41b-d977822d14e5	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-19 12:54:40.464
9933a58c-9481-4530-be57-4ab08303afab	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-19 12:54:59.264
23368b99-041f-412a-a22f-ee1ee9b8e280	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-19 12:55:00.355
0e636a63-8402-4f37-b192-290432349b2c	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 12:55:24.714
d923e2da-ec3d-4c16-aa86-beb0ef31bdbe	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 13:01:05.177
6c10cb56-9cc5-4eb1-8346-65a1644b6255	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 13:23:06.853
45d6dde1-36a1-41e2-82a9-369998c90a08	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 13:23:45.378
f09c7596-1f65-491a-8a7f-8d2e578ba5fa	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 13:34:36.174
991bc9a0-2bfa-4914-a9da-eefb96ab2b6b	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 14:09:26.38
b890008e-4ecf-463e-b7a9-e8f010b8f422	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-19 14:49:08.074
71478f1f-ebed-42b4-aff9-e215b515fca1	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 14:49:19.912
b0e19a7a-bbb7-4c0e-b87f-0f814b8d7675	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 16:05:17.325
be48c538-b03e-442e-a9d5-94851a9d1506	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 16:20:59.369
fe85316f-6fb4-4026-b170-a3eb41d827dc	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	invalid_password	2025-12-19 16:38:47.549
6b9f3ec0-e37c-4579-a672-938b4d458966	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 16:39:03.308
6856c7f9-a19b-469c-8474-b159de3c2d72	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 16:45:00.674
55cc6063-739a-4173-ae35-1ffe85064801	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 17:02:41.157
a1ff0a9b-a0e9-4b2b-8dc5-34481499417b	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 17:14:02.447
110f145b-c3ed-4bba-9787-62a21b9b59ef	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 17:31:01.884
5509370b-a98e-42a7-add2-51e75aab82a8	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 17:56:14.639
db272039-88f2-4683-b55e-20917e4343a1	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 18:20:40.986
8f970a74-9e1b-419d-86d5-de09f3f750fc	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 18:22:38.377
a7db9a30-eb16-4ac1-9260-c0e7e43159d7	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 18:39:56.393
98873037-18cb-4f0d-953d-e617bcfb25cc	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 19:40:38.983
56ea8680-0a22-4f6b-933d-1c28ca2c336f	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-19 20:03:33.454
bbbc7f22-953c-423e-90e9-fb65fb2c9d32	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 12:26:12.653
57a4e523-7920-4259-8fcd-e0b6130c5028	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 13:56:41.831
db43e724-9f3e-48f2-b73a-a96881913168	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 13:59:47.678
1cc590c9-989c-4d35-b847-933c898d28eb	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 14:16:11.311
16e124bc-fef2-475b-bfc2-d8c47aebe21e	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 14:49:43.863
4c6c1a1b-2f1d-4593-aa86-f1578361f38e	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 15:05:32.752
3f697715-4d38-46d6-b625-9a757503b910	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 15:22:26.341
4e644417-9c26-461d-af5e-43396913e066	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 15:37:49.758
d2c851ee-2317-444c-976d-a4ce5cfeac4c	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 15:53:51.607
1fe93292-4079-41ff-a344-9e65b787c3d3	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 16:21:22.876
32e5d47f-82d1-4c0f-92f6-53b1715fad8d	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 16:38:50.281
4b2a8a0d-bd75-4e6d-8cde-8c70f302b325	67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2025-12-20 16:56:40.362
\.


--
-- Data for Name: MarketplaceActiveInstance; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceActiveInstance" (id, "productId", "versionId", "instanceId", "userId", "lastSeen", meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceAnalytics; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceAnalytics" (id, "productId", "versionId", "eventType", meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceAnalyticsAggregate; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceAnalyticsAggregate" (id, "productId", date, installs, active, crashes, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceBuildLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceBuildLog" (id, "submissionId", "productId", "versionId", level, message, meta, step, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceCategory; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceCategory" (id, name, slug, icon, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceCrash; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceCrash" (id, "productId", "versionId", "userId", message, "stackTrace", meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceDependency; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceDependency" (id, "productId", "dependencyId", "versionRange", "createdAt", approved) FROM stdin;
\.


--
-- Data for Name: MarketplaceLicenseActivation; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceLicenseActivation" (id, "licenseId", "userAgent", host, ip, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplacePerfMetric; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplacePerfMetric" (id, "productId", "versionId", metric, value, meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceProduct; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceProduct" (id, "sellerId", title, slug, "shortDesc", "longDesc", "categoryId", tags, status, "rejectReason", logo, screenshots, documentation, "ratingAvg", "ratingCount", "installCount", "downloadCount", "lastUpdatedAt", "createdAt", "updatedAt", "approvedAt") FROM stdin;
\.


--
-- Data for Name: MarketplacePurchase; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplacePurchase" (id, "userId", "productId", "versionId", "licenseKey", subscribed, "activationLimit", "expiresAt", revoked, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceReview; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceReview" (id, "productId", "userId", rating, stability, review, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceSubmission; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceSubmission" (id, "productId", "versionId", "reviewerId", notes, "createdAt", status) FROM stdin;
\.


--
-- Data for Name: MarketplaceVerification; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceVerification" (id, "productId", "versionId", passed, issues, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceVersion; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceVersion" (id, "productId", version, "manifestJson", "archivePath", changelog, "priceCents", currency, "createdAt", "approvedAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceWebhook; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceWebhook" (id, event, payload, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceWebhookEndpoint; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceWebhookEndpoint" (id, "vendorId", url, secret, enabled, "createdAt") FROM stdin;
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Permission" (id, key, description) FROM stdin;
40376989-bf33-4416-9bdc-f903bef557a4	admin.access	Access admin portal
86911f4d-15b7-42ba-b0d0-cbf830083976	admin.manage.staff	Manage admin staff accounts
b8e2e656-5620-4e0c-b862-a999f16264c2	admin.settings.update	Update system settings
96890136-aaef-469f-9127-96dbc735e47c	client.area.access	Access client dashboard
e5208f9d-eccb-40d6-86bc-6ed0253387e1	billing.invoices.view	View invoices
c65db3ee-50aa-4f43-90c5-cbe262b49fc7	billing.invoices.pay	Pay invoices
a2ce23a2-4536-49ed-a6e8-38f183a18163	reseller.dashboard.access	Access reseller dashboard
c5a09832-be01-42a7-b657-61b6bbb231ff	developer.console.access	Access developer console
3989d64d-6207-409a-ac67-4cf8ffc9916f	plugins.upload	Upload new plugin to marketplace
425a9f5e-fc51-4b98-99d7-b31fd1bdb3b3	plugins.update	Update existing plugin versions
\.


--
-- Data for Name: Plugin; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Plugin" (id, name, version, enabled, "installedAt", "updatedAt", "createdAt", folder, "configSchema", type) FROM stdin;
\.


--
-- Data for Name: PluginSetting; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."PluginSetting" (id, "pluginId", key, value, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProviderConfig; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ProviderConfig" (id, name, key, secret, endpoint, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."RefreshToken" (id, token, "userId", revoked, "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: ResellerProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ResellerProfile" (id, "userId", "resellerCode", company, phone, address) FROM stdin;
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Role" (id, name, description) FROM stdin;
fc16247e-5227-4c3f-b55b-33e27da78998	superadmin	Full unrestricted access
7a5470f4-8af2-4171-8fe2-c84b2e23fc74	admin	Admin access with limited control
d77372f5-6662-48d1-823b-ad9c5ac175bd	staff	Support/billing agent
04cc3128-3a6a-4614-8402-279d3af51dfa	client	Regular client account
34a7cf06-a96c-442b-b78b-6f9384be42f6	reseller	Reseller portal access
5f07bcd3-6927-4f0e-ab95-cee67a08c3e8	developer	Marketplace developer
\.


--
-- Data for Name: RolePermission; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."RolePermission" (id, "roleId", "permissionId") FROM stdin;
fe87a4b9-ee67-42d3-8d78-f7542930185d	fc16247e-5227-4c3f-b55b-33e27da78998	40376989-bf33-4416-9bdc-f903bef557a4
ef6db071-138b-4ac5-a0c3-598f885a8beb	fc16247e-5227-4c3f-b55b-33e27da78998	86911f4d-15b7-42ba-b0d0-cbf830083976
bebadcf9-778d-496f-bdae-745af024f77b	fc16247e-5227-4c3f-b55b-33e27da78998	b8e2e656-5620-4e0c-b862-a999f16264c2
a1ee474b-a11b-46b8-8e1e-4317fb12f554	fc16247e-5227-4c3f-b55b-33e27da78998	e5208f9d-eccb-40d6-86bc-6ed0253387e1
46a7ac55-55b7-42d1-8a35-82332042f8b8	fc16247e-5227-4c3f-b55b-33e27da78998	c65db3ee-50aa-4f43-90c5-cbe262b49fc7
61e159f5-4ac0-4c38-9186-baa2a29ff6c8	fc16247e-5227-4c3f-b55b-33e27da78998	a2ce23a2-4536-49ed-a6e8-38f183a18163
191d3b66-3c61-481f-a072-a47b71110e8f	fc16247e-5227-4c3f-b55b-33e27da78998	c5a09832-be01-42a7-b657-61b6bbb231ff
0aa44bf4-8398-42f1-9ba3-4698ce6a294e	fc16247e-5227-4c3f-b55b-33e27da78998	3989d64d-6207-409a-ac67-4cf8ffc9916f
c21dde5c-df38-4849-9a1f-ec9b47c8085e	fc16247e-5227-4c3f-b55b-33e27da78998	425a9f5e-fc51-4b98-99d7-b31fd1bdb3b3
68af27e4-306a-43d5-96b0-cf87fb20a6fd	fc16247e-5227-4c3f-b55b-33e27da78998	96890136-aaef-469f-9127-96dbc735e47c
34d99052-6a31-4c7e-b0b1-9f5b9b2375d2	7a5470f4-8af2-4171-8fe2-c84b2e23fc74	40376989-bf33-4416-9bdc-f903bef557a4
e8894714-685d-4eb3-9419-d9d417ed4cb6	7a5470f4-8af2-4171-8fe2-c84b2e23fc74	e5208f9d-eccb-40d6-86bc-6ed0253387e1
c0f10313-3ef1-4c08-8995-fa1a8c884619	7a5470f4-8af2-4171-8fe2-c84b2e23fc74	c65db3ee-50aa-4f43-90c5-cbe262b49fc7
f4d4027e-335a-44b1-b161-b0d040d1a697	7a5470f4-8af2-4171-8fe2-c84b2e23fc74	96890136-aaef-469f-9127-96dbc735e47c
2346b560-87e0-4267-8480-8813269f633e	d77372f5-6662-48d1-823b-ad9c5ac175bd	40376989-bf33-4416-9bdc-f903bef557a4
524291ce-5e96-462c-beeb-a4b39fb4f000	d77372f5-6662-48d1-823b-ad9c5ac175bd	e5208f9d-eccb-40d6-86bc-6ed0253387e1
a2d332f6-f472-4882-9434-75dfeac7ff30	04cc3128-3a6a-4614-8402-279d3af51dfa	96890136-aaef-469f-9127-96dbc735e47c
3076017f-5974-4730-81a5-76dc4035d7d4	04cc3128-3a6a-4614-8402-279d3af51dfa	e5208f9d-eccb-40d6-86bc-6ed0253387e1
7b412f0e-6404-48d0-888c-b5d268ac84ce	04cc3128-3a6a-4614-8402-279d3af51dfa	c65db3ee-50aa-4f43-90c5-cbe262b49fc7
e69a9548-4979-4d22-a04f-b886757023df	34a7cf06-a96c-442b-b78b-6f9384be42f6	a2ce23a2-4536-49ed-a6e8-38f183a18163
87beb5da-3550-4f5b-884a-de9f37ffebc9	34a7cf06-a96c-442b-b78b-6f9384be42f6	e5208f9d-eccb-40d6-86bc-6ed0253387e1
4abd570b-b696-4d9a-a8de-440bcd3cdc46	34a7cf06-a96c-442b-b78b-6f9384be42f6	c65db3ee-50aa-4f43-90c5-cbe262b49fc7
4b644a79-ae5b-4202-a36b-ddc1a6fe3a33	5f07bcd3-6927-4f0e-ab95-cee67a08c3e8	c5a09832-be01-42a7-b657-61b6bbb231ff
bedcac53-dd07-496f-9815-d604c0ca618f	5f07bcd3-6927-4f0e-ab95-cee67a08c3e8	3989d64d-6207-409a-ac67-4cf8ffc9916f
fad87ce2-9144-4fe8-91a9-8099256d7e96	5f07bcd3-6927-4f0e-ab95-cee67a08c3e8	425a9f5e-fc51-4b98-99d7-b31fd1bdb3b3
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Session" (id, "userId", token, "userAgent", ip, "createdAt", "expiresAt", "isImpersonation", "impersonatorId", "impersonationReason") FROM stdin;
f2c55ccc-4a75-48e2-a58a-4b198a7a47ef	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyMzkwMDEsImV4cCI6MTc2Njg0MzgwMX0.6MbJnjY8I5TIiY0UYoxdkDfwRQ2ZZaDHN5lRE2MyoL8	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 13:56:41.816	2025-12-27 13:56:41.815	f	\N	\N
82d06b32-e986-41f5-a4ea-ebcf5045c0c5	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyMzkxODcsImV4cCI6MTc2Njg0Mzk4N30.zWQUf_reHzgDzBSyJ6uPGalM6BROslZnFamxpn6yGF8	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 13:59:47.664	2025-12-27 13:59:47.663	f	\N	\N
505133b3-bca3-4855-8a84-605c9840f1c9	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyNDAxNzEsImV4cCI6MTc2Njg0NDk3MX0.wzwrtK2YEfBC9YfXh7-fPFXXe42q7UaHBIwexNeWgsI	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 14:16:11.286	2025-12-27 14:16:11.285	f	\N	\N
2ecaf461-cd1b-4ae5-a608-770062fb479b	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyNDIxODMsImV4cCI6MTc2Njg0Njk4M30.QKMV-lPg1yI_BVg4ETiUDna9zcTlXbPT6czRnuguphI	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 14:49:43.848	2025-12-27 14:49:43.847	f	\N	\N
98313e25-0d1d-42f4-ba02-deec7f315de7	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyNDMxMzIsImV4cCI6MTc2Njg0NzkzMn0.l2lDIbNxlcV04BZp4lRbtwgr6ejVlezD16b8ytWJfmY	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 15:05:32.738	2025-12-27 15:05:32.737	f	\N	\N
2f770112-101a-4be2-9926-83a3a96bed99	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyNDQxNDYsImV4cCI6MTc2Njg0ODk0Nn0.ktV8J9x8c7ywXkxwNpFlb-CJFkyccEolruGyAby-O08	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 15:22:26.326	2025-12-27 15:22:26.325	f	\N	\N
3a5346cc-8fe3-4068-8111-8249784bade9	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyNDUwNjksImV4cCI6MTc2Njg0OTg2OX0.ToFlOJilkQ59YlDvR_5-wKZzocZS05w9WBAXlUV-cvE	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 15:37:49.744	2025-12-27 15:37:49.743	f	\N	\N
1e23fd8a-27ad-4665-bf7d-6d292efda85e	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyNDYwMzEsImV4cCI6MTc2Njg1MDgzMX0.JGG5hsSMKT2BN5HfdbIcXuXpaiO_fI8VuxvEFLU2Woc	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 15:53:51.592	2025-12-27 15:53:51.591	f	\N	\N
9e450785-4c68-4e42-a058-54dfa454c2ac	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyNDc2ODIsImV4cCI6MTc2Njg1MjQ4Mn0.H8Z_3dlMcn9nQuoM1yWhEfG9MCuiiA9vXNKWqNlpVPA	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 16:21:22.861	2025-12-27 16:21:22.86	f	\N	\N
a2afcc80-c694-4bc5-83ce-a13532ab9133	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyNDg3MzAsImV4cCI6MTc2Njg1MzUzMH0.Qht2HlgEkmVMSOxP4Ql3KYheDYPPqPJCKPzru2fwYuQ	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 16:38:50.266	2025-12-27 16:38:50.265	f	\N	\N
17c69acd-813d-4cdd-8c3d-9c63de367fef	67192e26-5ba9-47fa-8e66-b3e87af343d9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NzE5MmUyNi01YmE5LTQ3ZmEtOGU2Ni1iM2U4N2FmMzQzZDkiLCJpYXQiOjE3NjYyNDk4MDAsImV4cCI6MTc2Njg1NDYwMH0.ZDDEkE50osSiBxsMlA8UI3TkcppEvj0WfydKwtS6fwc	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2025-12-20 16:56:40.348	2025-12-27 16:56:40.347	f	\N	\N
\.


--
-- Data for Name: StorageConfig; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."StorageConfig" (id, name, provider, config, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Ticket; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Ticket" (id, "clientId", subject, message, priority, status, "createdAt") FROM stdin;
\.


--
-- Data for Name: Tld; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Tld" (id, name, "registerPrice", "renewPrice", "transferPrice", "markupPercent", "providerData", "lastSynced", active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TrustedDevice; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."TrustedDevice" (id, "userId", "deviceId", "userAgent", ip, name, "createdAt", "lastUsedAt", "expiresAt", revoked) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."User" (id, email, "createdAt", "updatedAt", "emailVerified", "mfaBackupCodes", "mfaEnabled", "mfaSecret", "passwordHash") FROM stdin;
67192e26-5ba9-47fa-8e66-b3e87af343d9	superadmin@example.com	2025-12-18 18:22:01.662	2025-12-18 18:22:01.662	t	{}	f	\N	$2b$12$9eZIdFOxlyAGckQyMaqMFuTYJzSwn8kwDMrD4Svfm19qpWn3eIVLC
\.


--
-- Data for Name: UserRole; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."UserRole" (id, "userId", "roleId") FROM stdin;
267ba183-d834-4cc8-8391-3005fd8a8bce	67192e26-5ba9-47fa-8e66-b3e87af343d9	fc16247e-5227-4c3f-b55b-33e27da78998
\.


--
-- Data for Name: Webhook; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Webhook" (id, name, url, secret, events, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WebhookLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."WebhookLog" (id, "webhookId", event, payload, status, "httpStatus", attempts, "lastError", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
ed7aabf7-6733-4a99-862d-dd150d93f41f	0b22e8da0114278e0a2478a3b422ea4aa0eaf78a482d94bd1ec28efbb36de0a8	2025-12-18 22:52:14.993793+05	20251102133357_1	\N	\N	2025-12-18 22:52:14.227579+05	1
e861cf90-396b-40d5-b2ef-c7715c60da87	f778d00637262317531b181af9f7bb00afabf0039ce49d9e0eaeccda529301bd	2025-12-18 22:52:15.417764+05	20251113125544_fix_clientservice	\N	\N	2025-12-18 22:52:15.006523+05	1
db1ee9a3-10db-4f38-8468-f48928d878f0	539261c0e62b19c7e760b8a3431cdf98f2e1bbb3ff7d265ebdf3ed48f5056c45	2025-12-18 22:52:16.040787+05	20251117130838_a1	\N	\N	2025-12-18 22:52:15.430843+05	1
956a74fe-0698-41d8-aa22-189de12d41a6	a41269562fd5cb363ff2ebc64fe821eb80c9f83c1711e36d906dc8704163a8ab	2025-12-18 22:52:16.093481+05	20251117151539_fix_task_run_cascade	\N	\N	2025-12-18 22:52:16.053597+05	1
5d395e00-39b3-4a8a-9f5e-e43a27409b69	6d877e84b2cc9feb7982a52dedb6d9676f5f5f4cab147356956d40b82ce4cc48	2025-12-18 22:52:16.248603+05	20251118110922_plugin_system_upgrade	\N	\N	2025-12-18 22:52:16.106373+05	1
b9e6d83e-26d9-493b-b0fc-37c4a10df54f	ed04d033c454d6dfb945872035964c182a89c02d4146787e9401f654eb8baa8e	2025-12-18 22:52:16.301582+05	20251118211942_fix_cascade_delete	\N	\N	2025-12-18 22:52:16.26134+05	1
e7643ecf-84fe-4d47-9ab7-bc04f2b0a745	87bbe3502a0427c1d07e41850f64efddc6ba1c7d612e94e51d8327079bd28114	2025-12-18 22:52:16.353991+05	20251118225417_plugin_marketplace_support	\N	\N	2025-12-18 22:52:16.314324+05	1
14ddfb77-5b2e-46ad-a857-e624ba2cacd3	7591952ba249f31243627ecc679176016d14efd15577677a82617d176d8ee040	2025-12-18 22:52:16.518719+05	20251119164909_backup	\N	\N	2025-12-18 22:52:16.367005+05	1
37b3ffdc-24a7-45f9-96e4-e07dad50f4ff	6a62ea7df3090b1d6d99220905e373a9f2a4bafec809a7de7ec8bf60e2dfea0b	2025-12-18 22:52:20.074428+05	20251203181037_init_auth_rbac	\N	\N	2025-12-18 22:52:16.532127+05	1
303a7847-f644-4a52-b401-eb5b3f2d66ff	dde6116df9de1d7a1272c0e8a5efff805dbab35f7c8d236002af337998652692	2025-12-18 22:52:43.067226+05	20251218175242_linux_init	\N	\N	2025-12-18 22:52:42.505497+05	1
\.


--
-- Name: AuditLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."AuditLog_id_seq"', 47, true);


--
-- Name: AutomationProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."AutomationProfile_id_seq"', 1, false);


--
-- Name: AutomationRun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."AutomationRun_id_seq"', 1, false);


--
-- Name: AutomationTask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."AutomationTask_id_seq"', 1, false);


--
-- Name: DNSRecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."DNSRecord_id_seq"', 1, false);


--
-- Name: DomainLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."DomainLog_id_seq"', 1, false);


--
-- Name: Domain_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."Domain_id_seq"', 1, false);


--
-- Name: EmailEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."EmailEvent_id_seq"', 1, false);


--
-- Name: EmailTemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."EmailTemplate_id_seq"', 1, false);


--
-- Name: IpAccessRule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."IpAccessRule_id_seq"', 4, true);


--
-- Name: PluginSetting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."PluginSetting_id_seq"', 1, false);


--
-- Name: ProviderConfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."ProviderConfig_id_seq"', 1, false);


--
-- Name: RefreshToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."RefreshToken_id_seq"', 1, false);


--
-- Name: StorageConfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."StorageConfig_id_seq"', 1, false);


--
-- Name: Ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."Ticket_id_seq"', 1, false);


--
-- Name: Tld_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."Tld_id_seq"', 1, false);


--
-- Name: AdminProfile AdminProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AdminProfile"
    ADD CONSTRAINT "AdminProfile_pkey" PRIMARY KEY (id);


--
-- Name: ApiKeyScope ApiKeyScope_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ApiKeyScope"
    ADD CONSTRAINT "ApiKeyScope_pkey" PRIMARY KEY (id);


--
-- Name: ApiKey ApiKey_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: AutomationProfile AutomationProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationProfile"
    ADD CONSTRAINT "AutomationProfile_pkey" PRIMARY KEY (id);


--
-- Name: AutomationRun AutomationRun_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationRun"
    ADD CONSTRAINT "AutomationRun_pkey" PRIMARY KEY (id);


--
-- Name: AutomationTask AutomationTask_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationTask"
    ADD CONSTRAINT "AutomationTask_pkey" PRIMARY KEY (id);


--
-- Name: BackupStepLog BackupStepLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."BackupStepLog"
    ADD CONSTRAINT "BackupStepLog_pkey" PRIMARY KEY (id);


--
-- Name: BackupVersion BackupVersion_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."BackupVersion"
    ADD CONSTRAINT "BackupVersion_pkey" PRIMARY KEY (id);


--
-- Name: Backup Backup_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Backup"
    ADD CONSTRAINT "Backup_pkey" PRIMARY KEY (id);


--
-- Name: ClientProfile ClientProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_pkey" PRIMARY KEY (id);


--
-- Name: DNSRecord DNSRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DNSRecord"
    ADD CONSTRAINT "DNSRecord_pkey" PRIMARY KEY (id);


--
-- Name: DeveloperProfile DeveloperProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DeveloperProfile"
    ADD CONSTRAINT "DeveloperProfile_pkey" PRIMARY KEY (id);


--
-- Name: DomainLog DomainLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainLog"
    ADD CONSTRAINT "DomainLog_pkey" PRIMARY KEY (id);


--
-- Name: Domain Domain_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_pkey" PRIMARY KEY (id);


--
-- Name: EmailEvent EmailEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailEvent"
    ADD CONSTRAINT "EmailEvent_pkey" PRIMARY KEY (id);


--
-- Name: EmailJob EmailJob_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailJob"
    ADD CONSTRAINT "EmailJob_pkey" PRIMARY KEY (id);


--
-- Name: EmailTemplate EmailTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailTemplate"
    ADD CONSTRAINT "EmailTemplate_pkey" PRIMARY KEY (id);


--
-- Name: EmailToken EmailToken_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailToken"
    ADD CONSTRAINT "EmailToken_pkey" PRIMARY KEY (id);


--
-- Name: Impersonation Impersonation_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Impersonation"
    ADD CONSTRAINT "Impersonation_pkey" PRIMARY KEY (id);


--
-- Name: IpAccessRule IpAccessRule_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."IpAccessRule"
    ADD CONSTRAINT "IpAccessRule_pkey" PRIMARY KEY (id);


--
-- Name: LoginLog LoginLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceActiveInstance MarketplaceActiveInstance_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceActiveInstance"
    ADD CONSTRAINT "MarketplaceActiveInstance_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceAnalyticsAggregate MarketplaceAnalyticsAggregate_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceAnalyticsAggregate"
    ADD CONSTRAINT "MarketplaceAnalyticsAggregate_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceAnalytics MarketplaceAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceAnalytics"
    ADD CONSTRAINT "MarketplaceAnalytics_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceBuildLog MarketplaceBuildLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceBuildLog"
    ADD CONSTRAINT "MarketplaceBuildLog_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceCategory MarketplaceCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceCategory"
    ADD CONSTRAINT "MarketplaceCategory_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceCrash MarketplaceCrash_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceCrash"
    ADD CONSTRAINT "MarketplaceCrash_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceDependency MarketplaceDependency_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceDependency"
    ADD CONSTRAINT "MarketplaceDependency_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceLicenseActivation MarketplaceLicenseActivation_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceLicenseActivation"
    ADD CONSTRAINT "MarketplaceLicenseActivation_pkey" PRIMARY KEY (id);


--
-- Name: MarketplacePerfMetric MarketplacePerfMetric_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePerfMetric"
    ADD CONSTRAINT "MarketplacePerfMetric_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceProduct MarketplaceProduct_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceProduct"
    ADD CONSTRAINT "MarketplaceProduct_pkey" PRIMARY KEY (id);


--
-- Name: MarketplacePurchase MarketplacePurchase_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceReview MarketplaceReview_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceReview"
    ADD CONSTRAINT "MarketplaceReview_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceSubmission MarketplaceSubmission_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceVerification MarketplaceVerification_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVerification"
    ADD CONSTRAINT "MarketplaceVerification_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceVersion MarketplaceVersion_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVersion"
    ADD CONSTRAINT "MarketplaceVersion_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceWebhookEndpoint MarketplaceWebhookEndpoint_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceWebhookEndpoint"
    ADD CONSTRAINT "MarketplaceWebhookEndpoint_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceWebhook MarketplaceWebhook_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceWebhook"
    ADD CONSTRAINT "MarketplaceWebhook_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: PluginSetting PluginSetting_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."PluginSetting"
    ADD CONSTRAINT "PluginSetting_pkey" PRIMARY KEY (id);


--
-- Name: Plugin Plugin_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Plugin"
    ADD CONSTRAINT "Plugin_pkey" PRIMARY KEY (id);


--
-- Name: ProviderConfig ProviderConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ProviderConfig"
    ADD CONSTRAINT "ProviderConfig_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: ResellerProfile ResellerProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ResellerProfile"
    ADD CONSTRAINT "ResellerProfile_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: StorageConfig StorageConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."StorageConfig"
    ADD CONSTRAINT "StorageConfig_pkey" PRIMARY KEY (id);


--
-- Name: Ticket Ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_pkey" PRIMARY KEY (id);


--
-- Name: Tld Tld_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Tld"
    ADD CONSTRAINT "Tld_pkey" PRIMARY KEY (id);


--
-- Name: TrustedDevice TrustedDevice_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."TrustedDevice"
    ADD CONSTRAINT "TrustedDevice_pkey" PRIMARY KEY (id);


--
-- Name: UserRole UserRole_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."UserRole"
    ADD CONSTRAINT "UserRole_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WebhookLog WebhookLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WebhookLog"
    ADD CONSTRAINT "WebhookLog_pkey" PRIMARY KEY (id);


--
-- Name: Webhook Webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Webhook"
    ADD CONSTRAINT "Webhook_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AdminProfile_userId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "AdminProfile_userId_key" ON public."AdminProfile" USING btree ("userId");


--
-- Name: AutomationProfile_cron_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationProfile_cron_idx" ON public."AutomationProfile" USING btree (cron);


--
-- Name: AutomationProfile_enabled_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationProfile_enabled_idx" ON public."AutomationProfile" USING btree (enabled);


--
-- Name: AutomationProfile_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "AutomationProfile_name_key" ON public."AutomationProfile" USING btree (name);


--
-- Name: AutomationRun_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationRun_createdAt_idx" ON public."AutomationRun" USING btree ("createdAt");


--
-- Name: AutomationRun_profileId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationRun_profileId_idx" ON public."AutomationRun" USING btree ("profileId");


--
-- Name: AutomationRun_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationRun_status_idx" ON public."AutomationRun" USING btree (status);


--
-- Name: AutomationRun_taskId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationRun_taskId_idx" ON public."AutomationRun" USING btree ("taskId");


--
-- Name: AutomationTask_order_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationTask_order_idx" ON public."AutomationTask" USING btree ("order");


--
-- Name: AutomationTask_profileId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationTask_profileId_idx" ON public."AutomationTask" USING btree ("profileId");


--
-- Name: ClientProfile_userId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ClientProfile_userId_key" ON public."ClientProfile" USING btree ("userId");


--
-- Name: DeveloperProfile_userId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "DeveloperProfile_userId_key" ON public."DeveloperProfile" USING btree ("userId");


--
-- Name: Domain_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Domain_name_key" ON public."Domain" USING btree (name);


--
-- Name: EmailEvent_jobId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "EmailEvent_jobId_idx" ON public."EmailEvent" USING btree ("jobId");


--
-- Name: EmailJob_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "EmailJob_status_idx" ON public."EmailJob" USING btree (status);


--
-- Name: EmailJob_templateId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "EmailJob_templateId_idx" ON public."EmailJob" USING btree ("templateId");


--
-- Name: EmailTemplate_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "EmailTemplate_name_key" ON public."EmailTemplate" USING btree (name);


--
-- Name: Impersonation_sessionToken_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Impersonation_sessionToken_key" ON public."Impersonation" USING btree ("sessionToken");


--
-- Name: IpAccessRule_pattern_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "IpAccessRule_pattern_idx" ON public."IpAccessRule" USING btree (pattern);


--
-- Name: MarketplaceActiveInstance_instanceId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceActiveInstance_instanceId_idx" ON public."MarketplaceActiveInstance" USING btree ("instanceId");


--
-- Name: MarketplaceActiveInstance_lastSeen_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceActiveInstance_lastSeen_idx" ON public."MarketplaceActiveInstance" USING btree ("lastSeen");


--
-- Name: MarketplaceActiveInstance_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceActiveInstance_productId_idx" ON public."MarketplaceActiveInstance" USING btree ("productId");


--
-- Name: MarketplaceAnalyticsAggregate_productId_date_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalyticsAggregate_productId_date_idx" ON public."MarketplaceAnalyticsAggregate" USING btree ("productId", date);


--
-- Name: MarketplaceAnalyticsAggregate_productId_date_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplaceAnalyticsAggregate_productId_date_key" ON public."MarketplaceAnalyticsAggregate" USING btree ("productId", date);


--
-- Name: MarketplaceAnalytics_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalytics_createdAt_idx" ON public."MarketplaceAnalytics" USING btree ("createdAt");


--
-- Name: MarketplaceAnalytics_eventType_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalytics_eventType_idx" ON public."MarketplaceAnalytics" USING btree ("eventType");


--
-- Name: MarketplaceAnalytics_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalytics_productId_idx" ON public."MarketplaceAnalytics" USING btree ("productId");


--
-- Name: MarketplaceAnalytics_versionId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalytics_versionId_idx" ON public."MarketplaceAnalytics" USING btree ("versionId");


--
-- Name: MarketplaceBuildLog_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceBuildLog_createdAt_idx" ON public."MarketplaceBuildLog" USING btree ("createdAt");


--
-- Name: MarketplaceBuildLog_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceBuildLog_productId_idx" ON public."MarketplaceBuildLog" USING btree ("productId");


--
-- Name: MarketplaceBuildLog_submissionId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceBuildLog_submissionId_idx" ON public."MarketplaceBuildLog" USING btree ("submissionId");


--
-- Name: MarketplaceBuildLog_versionId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceBuildLog_versionId_idx" ON public."MarketplaceBuildLog" USING btree ("versionId");


--
-- Name: MarketplaceCategory_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplaceCategory_name_key" ON public."MarketplaceCategory" USING btree (name);


--
-- Name: MarketplaceCategory_slug_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplaceCategory_slug_key" ON public."MarketplaceCategory" USING btree (slug);


--
-- Name: MarketplaceCrash_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceCrash_createdAt_idx" ON public."MarketplaceCrash" USING btree ("createdAt");


--
-- Name: MarketplaceCrash_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceCrash_productId_idx" ON public."MarketplaceCrash" USING btree ("productId");


--
-- Name: MarketplaceCrash_versionId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceCrash_versionId_idx" ON public."MarketplaceCrash" USING btree ("versionId");


--
-- Name: MarketplacePerfMetric_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplacePerfMetric_createdAt_idx" ON public."MarketplacePerfMetric" USING btree ("createdAt");


--
-- Name: MarketplacePerfMetric_metric_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplacePerfMetric_metric_idx" ON public."MarketplacePerfMetric" USING btree (metric);


--
-- Name: MarketplacePerfMetric_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplacePerfMetric_productId_idx" ON public."MarketplacePerfMetric" USING btree ("productId");


--
-- Name: MarketplaceProduct_slug_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplaceProduct_slug_key" ON public."MarketplaceProduct" USING btree (slug);


--
-- Name: MarketplacePurchase_licenseKey_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplacePurchase_licenseKey_key" ON public."MarketplacePurchase" USING btree ("licenseKey");


--
-- Name: MarketplaceWebhookEndpoint_vendorId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceWebhookEndpoint_vendorId_idx" ON public."MarketplaceWebhookEndpoint" USING btree ("vendorId");


--
-- Name: Permission_key_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Permission_key_key" ON public."Permission" USING btree (key);


--
-- Name: PluginSetting_pluginId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "PluginSetting_pluginId_idx" ON public."PluginSetting" USING btree ("pluginId");


--
-- Name: PluginSetting_pluginId_key_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "PluginSetting_pluginId_key_key" ON public."PluginSetting" USING btree ("pluginId", key);


--
-- Name: ProviderConfig_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ProviderConfig_name_key" ON public."ProviderConfig" USING btree (name);


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: RefreshToken_userId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "RefreshToken_userId_idx" ON public."RefreshToken" USING btree ("userId");


--
-- Name: ResellerProfile_resellerCode_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ResellerProfile_resellerCode_key" ON public."ResellerProfile" USING btree ("resellerCode");


--
-- Name: ResellerProfile_userId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ResellerProfile_userId_key" ON public."ResellerProfile" USING btree ("userId");


--
-- Name: RolePermission_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "RolePermission_roleId_permissionId_key" ON public."RolePermission" USING btree ("roleId", "permissionId");


--
-- Name: Role_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Role_name_key" ON public."Role" USING btree (name);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: Ticket_clientId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Ticket_clientId_idx" ON public."Ticket" USING btree ("clientId");


--
-- Name: Tld_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Tld_name_key" ON public."Tld" USING btree (name);


--
-- Name: TrustedDevice_deviceId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "TrustedDevice_deviceId_key" ON public."TrustedDevice" USING btree ("deviceId");


--
-- Name: UserRole_userId_roleId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "UserRole_userId_roleId_key" ON public."UserRole" USING btree ("userId", "roleId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Webhook_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Webhook_name_key" ON public."Webhook" USING btree (name);


--
-- Name: AdminProfile AdminProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AdminProfile"
    ADD CONSTRAINT "AdminProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ApiKeyScope ApiKeyScope_apiKeyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ApiKeyScope"
    ADD CONSTRAINT "ApiKeyScope_apiKeyId_fkey" FOREIGN KEY ("apiKeyId") REFERENCES public."ApiKey"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ApiKey ApiKey_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AutomationRun AutomationRun_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationRun"
    ADD CONSTRAINT "AutomationRun_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public."AutomationProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationRun AutomationRun_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationRun"
    ADD CONSTRAINT "AutomationRun_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."AutomationTask"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationTask AutomationTask_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationTask"
    ADD CONSTRAINT "AutomationTask_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public."AutomationProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BackupStepLog BackupStepLog_backupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."BackupStepLog"
    ADD CONSTRAINT "BackupStepLog_backupId_fkey" FOREIGN KEY ("backupId") REFERENCES public."Backup"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: BackupVersion BackupVersion_backupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."BackupVersion"
    ADD CONSTRAINT "BackupVersion_backupId_fkey" FOREIGN KEY ("backupId") REFERENCES public."Backup"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ClientProfile ClientProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DNSRecord DNSRecord_domainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DNSRecord"
    ADD CONSTRAINT "DNSRecord_domainId_fkey" FOREIGN KEY ("domainId") REFERENCES public."Domain"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DeveloperProfile DeveloperProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DeveloperProfile"
    ADD CONSTRAINT "DeveloperProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DomainLog DomainLog_domainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainLog"
    ADD CONSTRAINT "DomainLog_domainId_fkey" FOREIGN KEY ("domainId") REFERENCES public."Domain"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: EmailJob EmailJob_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailJob"
    ADD CONSTRAINT "EmailJob_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."EmailTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EmailToken EmailToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailToken"
    ADD CONSTRAINT "EmailToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Impersonation Impersonation_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Impersonation"
    ADD CONSTRAINT "Impersonation_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Impersonation Impersonation_impersonatedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Impersonation"
    ADD CONSTRAINT "Impersonation_impersonatedId_fkey" FOREIGN KEY ("impersonatedId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LoginLog LoginLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceAnalytics MarketplaceAnalytics_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceAnalytics"
    ADD CONSTRAINT "MarketplaceAnalytics_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceAnalytics MarketplaceAnalytics_versionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceAnalytics"
    ADD CONSTRAINT "MarketplaceAnalytics_versionId_fkey" FOREIGN KEY ("versionId") REFERENCES public."MarketplaceVersion"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceDependency MarketplaceDependency_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceDependency"
    ADD CONSTRAINT "MarketplaceDependency_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceLicenseActivation MarketplaceLicenseActivation_licenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceLicenseActivation"
    ADD CONSTRAINT "MarketplaceLicenseActivation_licenseId_fkey" FOREIGN KEY ("licenseId") REFERENCES public."MarketplacePurchase"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceProduct MarketplaceProduct_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceProduct"
    ADD CONSTRAINT "MarketplaceProduct_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."MarketplaceCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceProduct MarketplaceProduct_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceProduct"
    ADD CONSTRAINT "MarketplaceProduct_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."DeveloperProfile"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplacePurchase MarketplacePurchase_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplacePurchase MarketplacePurchase_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplacePurchase MarketplacePurchase_versionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_versionId_fkey" FOREIGN KEY ("versionId") REFERENCES public."MarketplaceVersion"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceReview MarketplaceReview_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceReview"
    ADD CONSTRAINT "MarketplaceReview_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceReview MarketplaceReview_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceReview"
    ADD CONSTRAINT "MarketplaceReview_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceSubmission MarketplaceSubmission_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceSubmission MarketplaceSubmission_reviewerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_reviewerId_fkey" FOREIGN KEY ("reviewerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceSubmission MarketplaceSubmission_versionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_versionId_fkey" FOREIGN KEY ("versionId") REFERENCES public."MarketplaceVersion"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceVerification MarketplaceVerification_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVerification"
    ADD CONSTRAINT "MarketplaceVerification_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceVerification MarketplaceVerification_versionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVerification"
    ADD CONSTRAINT "MarketplaceVerification_versionId_fkey" FOREIGN KEY ("versionId") REFERENCES public."MarketplaceVersion"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceVersion MarketplaceVersion_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVersion"
    ADD CONSTRAINT "MarketplaceVersion_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PluginSetting PluginSetting_pluginId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."PluginSetting"
    ADD CONSTRAINT "PluginSetting_pluginId_fkey" FOREIGN KEY ("pluginId") REFERENCES public."Plugin"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResellerProfile ResellerProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ResellerProfile"
    ADD CONSTRAINT "ResellerProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermission RolePermission_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermission RolePermission_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Ticket Ticket_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TrustedDevice TrustedDevice_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."TrustedDevice"
    ADD CONSTRAINT "TrustedDevice_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserRole UserRole_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."UserRole"
    ADD CONSTRAINT "UserRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserRole UserRole_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."UserRole"
    ADD CONSTRAINT "UserRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WebhookLog WebhookLog_webhookId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WebhookLog"
    ADD CONSTRAINT "WebhookLog_webhookId_fkey" FOREIGN KEY ("webhookId") REFERENCES public."Webhook"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict 7IrbvJ9QhOYj2T6JMCSnXbQWaGJPm0bWowU256sZv2jKKUsBSZ6DmWmCoHzevoH

