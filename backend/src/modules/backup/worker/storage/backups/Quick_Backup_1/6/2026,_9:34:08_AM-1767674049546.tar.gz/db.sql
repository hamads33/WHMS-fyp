--
-- PostgreSQL database dump
--

\restrict mdkXEWykWsAcxeRV2sue4Ms7esUZcJ8PKu4sINsdOpyoEbnrGLE2kURyHzYAIna

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: whms
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO whms;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: whms
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AutomationRunStatus; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."AutomationRunStatus" AS ENUM (
    'pending',
    'running',
    'success',
    'failed'
);


ALTER TYPE public."AutomationRunStatus" OWNER TO whms;

--
-- Name: BillingCycle; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."BillingCycle" AS ENUM (
    'monthly',
    'quarterly',
    'semi_annually',
    'annually'
);


ALTER TYPE public."BillingCycle" OWNER TO whms;

--
-- Name: DomainContactType; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."DomainContactType" AS ENUM (
    'registrant',
    'admin',
    'tech',
    'billing'
);


ALTER TYPE public."DomainContactType" OWNER TO whms;

--
-- Name: DomainStatus; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."DomainStatus" AS ENUM (
    'pending_registration',
    'active',
    'expired',
    'grace',
    'redemption',
    'transfer_pending',
    'transfer_failed',
    'transferred_out',
    'cancelled'
);


ALTER TYPE public."DomainStatus" OWNER TO whms;

--
-- Name: DomainTransferStatus; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."DomainTransferStatus" AS ENUM (
    'pending',
    'approved',
    'rejected',
    'completed'
);


ALTER TYPE public."DomainTransferStatus" OWNER TO whms;

--
-- Name: IpRuleType; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."IpRuleType" AS ENUM (
    'ALLOW',
    'DENY'
);


ALTER TYPE public."IpRuleType" OWNER TO whms;

--
-- Name: MarketplaceSubmissionStatus; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."MarketplaceSubmissionStatus" AS ENUM (
    'pending_review',
    'pending_dependency_approval',
    'pending_resubmission',
    'rejected',
    'auto_rejected',
    'approved'
);


ALTER TYPE public."MarketplaceSubmissionStatus" OWNER TO whms;

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'pending',
    'active',
    'suspended',
    'terminated',
    'cancelled'
);


ALTER TYPE public."OrderStatus" OWNER TO whms;

--
-- Name: WorkflowRunStatus; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."WorkflowRunStatus" AS ENUM (
    'pending',
    'running',
    'success',
    'failed',
    'cancelled',
    'timeout'
);


ALTER TYPE public."WorkflowRunStatus" OWNER TO whms;

--
-- Name: WorkflowTaskStatus; Type: TYPE; Schema: public; Owner: whms
--

CREATE TYPE public."WorkflowTaskStatus" AS ENUM (
    'pending',
    'running',
    'success',
    'failed',
    'skipped',
    'timeout'
);


ALTER TYPE public."WorkflowTaskStatus" OWNER TO whms;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ActionMetric; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ActionMetric" (
    id integer NOT NULL,
    "actionType" character varying(100) NOT NULL,
    "executionCount" integer DEFAULT 0 NOT NULL,
    "successCount" integer DEFAULT 0 NOT NULL,
    "failureCount" integer DEFAULT 0 NOT NULL,
    "avgDuration" double precision DEFAULT 0 NOT NULL,
    "maxDuration" integer,
    "minDuration" integer,
    "p95Duration" integer,
    "p99Duration" integer,
    "lastExecutedAt" timestamp(3) without time zone,
    "lastError" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ActionMetric" OWNER TO whms;

--
-- Name: ActionMetric_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."ActionMetric_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ActionMetric_id_seq" OWNER TO whms;

--
-- Name: ActionMetric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."ActionMetric_id_seq" OWNED BY public."ActionMetric".id;


--
-- Name: ActionTemplate; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ActionTemplate" (
    id integer NOT NULL,
    "actionType" character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    "inputSchema" jsonb NOT NULL,
    "outputSchema" jsonb NOT NULL,
    category character varying(100) NOT NULL,
    "isBuiltin" boolean DEFAULT true NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    documentation text,
    examples jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ActionTemplate" OWNER TO whms;

--
-- Name: ActionTemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."ActionTemplate_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ActionTemplate_id_seq" OWNER TO whms;

--
-- Name: ActionTemplate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."ActionTemplate_id_seq" OWNED BY public."ActionTemplate".id;


--
-- Name: AdminProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AdminProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    department text,
    "staffTitle" text,
    "restrictionJson" jsonb
);


ALTER TABLE public."AdminProfile" OWNER TO whms;

--
-- Name: ApiKey; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ApiKey" (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    "keyHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."ApiKey" OWNER TO whms;

--
-- Name: ApiKeyScope; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ApiKeyScope" (
    id text NOT NULL,
    "apiKeyId" text NOT NULL,
    scope text NOT NULL
);


ALTER TABLE public."ApiKeyScope" OWNER TO whms;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AuditLog" (
    "userId" text,
    action text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    data jsonb,
    entity text,
    "entityId" text,
    ip text,
    "userAgent" text,
    actor text NOT NULL,
    level text DEFAULT 'INFO'::text NOT NULL,
    meta jsonb,
    source text NOT NULL,
    id integer NOT NULL,
    "profileId" integer
);


ALTER TABLE public."AuditLog" OWNER TO whms;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."AuditLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AuditLog_id_seq" OWNER TO whms;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."AuditLog_id_seq" OWNED BY public."AuditLog".id;


--
-- Name: AutomationProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AutomationProfile" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    cron character varying(100),
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AutomationProfile" OWNER TO whms;

--
-- Name: AutomationProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."AutomationProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationProfile_id_seq" OWNER TO whms;

--
-- Name: AutomationProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."AutomationProfile_id_seq" OWNED BY public."AutomationProfile".id;


--
-- Name: AutomationRun; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AutomationRun" (
    id integer NOT NULL,
    "profileId" integer NOT NULL,
    "taskId" integer,
    result jsonb,
    "errorMessage" text,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."AutomationRunStatus" NOT NULL
);


ALTER TABLE public."AutomationRun" OWNER TO whms;

--
-- Name: AutomationRun_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."AutomationRun_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationRun_id_seq" OWNER TO whms;

--
-- Name: AutomationRun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."AutomationRun_id_seq" OWNED BY public."AutomationRun".id;


--
-- Name: AutomationTask; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AutomationTask" (
    id integer NOT NULL,
    "profileId" integer NOT NULL,
    "actionType" character varying(100) NOT NULL,
    "actionMeta" jsonb,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AutomationTask" OWNER TO whms;

--
-- Name: AutomationTask_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."AutomationTask_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationTask_id_seq" OWNER TO whms;

--
-- Name: AutomationTask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."AutomationTask_id_seq" OWNED BY public."AutomationTask".id;


--
-- Name: AutomationWorkflow; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."AutomationWorkflow" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    definition jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "isDraft" boolean DEFAULT false NOT NULL,
    trigger text DEFAULT 'manual'::text NOT NULL,
    type text DEFAULT 'sequential'::text NOT NULL,
    "eventType" text,
    "eventFilter" jsonb,
    "webhookUrl" text,
    "webhookSecret" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."AutomationWorkflow" OWNER TO whms;

--
-- Name: AutomationWorkflow_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."AutomationWorkflow_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationWorkflow_id_seq" OWNER TO whms;

--
-- Name: AutomationWorkflow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."AutomationWorkflow_id_seq" OWNED BY public."AutomationWorkflow".id;


--
-- Name: Backup; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Backup" (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    "storageConfigId" integer,
    "filePath" text,
    "sizeBytes" bigint,
    status text NOT NULL,
    "retentionDays" integer,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    deleted boolean DEFAULT false NOT NULL,
    "errorMessage" text
);


ALTER TABLE public."Backup" OWNER TO whms;

--
-- Name: BackupStepLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."BackupStepLog" (
    id text NOT NULL,
    "backupId" text NOT NULL,
    step text NOT NULL,
    meta jsonb,
    status text DEFAULT 'started'::text NOT NULL,
    message text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."BackupStepLog" OWNER TO whms;

--
-- Name: BackupVersion; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."BackupVersion" (
    id text NOT NULL,
    "backupId" text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "filePath" text NOT NULL,
    "sizeBytes" bigint,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."BackupVersion" OWNER TO whms;

--
-- Name: ClientProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ClientProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    company text,
    phone text,
    address text,
    country text,
    city text,
    postal text
);


ALTER TABLE public."ClientProfile" OWNER TO whms;

--
-- Name: DNSRecord; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."DNSRecord" (
    id integer NOT NULL,
    "domainId" integer NOT NULL,
    type text NOT NULL,
    name text NOT NULL,
    value text NOT NULL,
    ttl integer DEFAULT 3600 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "providerRecordId" text
);


ALTER TABLE public."DNSRecord" OWNER TO whms;

--
-- Name: DNSRecord_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."DNSRecord_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DNSRecord_id_seq" OWNER TO whms;

--
-- Name: DNSRecord_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."DNSRecord_id_seq" OWNED BY public."DNSRecord".id;


--
-- Name: DeveloperProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."DeveloperProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "displayName" text,
    website text,
    github text,
    "payoutsEmail" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "marketplaceMeta" jsonb,
    "publicKeyPem" text,
    "storeName" text,
    "stripeAccountId" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DeveloperProfile" OWNER TO whms;

--
-- Name: Domain; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Domain" (
    id integer NOT NULL,
    name text NOT NULL,
    "expiryDate" timestamp(3) without time zone,
    nameservers text[] DEFAULT ARRAY[]::text[],
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "autoRenew" boolean DEFAULT true NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "ownerId" text NOT NULL,
    "providerConfigId" integer,
    registrar text,
    "registrationPrice" integer,
    "renewalPrice" integer,
    status public."DomainStatus" DEFAULT 'pending_registration'::public."DomainStatus" NOT NULL
);


ALTER TABLE public."Domain" OWNER TO whms;

--
-- Name: DomainContact; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."DomainContact" (
    id integer NOT NULL,
    "domainId" integer NOT NULL,
    type public."DomainContactType" NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    country text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DomainContact" OWNER TO whms;

--
-- Name: DomainContact_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."DomainContact_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DomainContact_id_seq" OWNER TO whms;

--
-- Name: DomainContact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."DomainContact_id_seq" OWNED BY public."DomainContact".id;


--
-- Name: DomainLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."DomainLog" (
    id integer NOT NULL,
    "domainId" integer NOT NULL,
    action text NOT NULL,
    message text,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DomainLog" OWNER TO whms;

--
-- Name: DomainLog_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."DomainLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DomainLog_id_seq" OWNER TO whms;

--
-- Name: DomainLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."DomainLog_id_seq" OWNED BY public."DomainLog".id;


--
-- Name: DomainRegistrarCommand; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."DomainRegistrarCommand" (
    id integer NOT NULL,
    "domainId" integer NOT NULL,
    action text NOT NULL,
    request jsonb,
    response jsonb,
    success boolean NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DomainRegistrarCommand" OWNER TO whms;

--
-- Name: DomainRegistrarCommand_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."DomainRegistrarCommand_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DomainRegistrarCommand_id_seq" OWNER TO whms;

--
-- Name: DomainRegistrarCommand_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."DomainRegistrarCommand_id_seq" OWNED BY public."DomainRegistrarCommand".id;


--
-- Name: DomainTransfer; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."DomainTransfer" (
    id integer NOT NULL,
    "domainId" integer NOT NULL,
    "authCode" text NOT NULL,
    status public."DomainTransferStatus" DEFAULT 'pending'::public."DomainTransferStatus" NOT NULL,
    "requestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "providerResponse" jsonb
);


ALTER TABLE public."DomainTransfer" OWNER TO whms;

--
-- Name: DomainTransfer_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."DomainTransfer_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DomainTransfer_id_seq" OWNER TO whms;

--
-- Name: DomainTransfer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."DomainTransfer_id_seq" OWNED BY public."DomainTransfer".id;


--
-- Name: Domain_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."Domain_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Domain_id_seq" OWNER TO whms;

--
-- Name: Domain_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."Domain_id_seq" OWNED BY public."Domain".id;


--
-- Name: EmailEvent; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."EmailEvent" (
    id integer NOT NULL,
    "jobId" text,
    "eventType" text NOT NULL,
    "providerId" text,
    payload jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."EmailEvent" OWNER TO whms;

--
-- Name: EmailEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."EmailEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailEvent_id_seq" OWNER TO whms;

--
-- Name: EmailEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."EmailEvent_id_seq" OWNED BY public."EmailEvent".id;


--
-- Name: EmailJob; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."EmailJob" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "templateId" integer,
    "templateName" text,
    "toEmail" text NOT NULL,
    "toName" text,
    payload jsonb,
    status text DEFAULT 'queued'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "lastError" text,
    priority text DEFAULT 'normal'::text NOT NULL,
    provider text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailJob" OWNER TO whms;

--
-- Name: EmailTemplate; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."EmailTemplate" (
    id integer NOT NULL,
    name text NOT NULL,
    subject text NOT NULL,
    "bodyHtml" text NOT NULL,
    "bodyText" text,
    language text DEFAULT 'en'::text NOT NULL,
    "isDefault" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailTemplate" OWNER TO whms;

--
-- Name: EmailTemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."EmailTemplate_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailTemplate_id_seq" OWNER TO whms;

--
-- Name: EmailTemplate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."EmailTemplate_id_seq" OWNED BY public."EmailTemplate".id;


--
-- Name: EmailToken; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."EmailToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    type text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL
);


ALTER TABLE public."EmailToken" OWNER TO whms;

--
-- Name: Impersonation; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Impersonation" (
    id text NOT NULL,
    "adminId" text NOT NULL,
    "impersonatedId" text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) without time zone,
    "sessionToken" text NOT NULL,
    reason text
);


ALTER TABLE public."Impersonation" OWNER TO whms;

--
-- Name: IncomingWebhook; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."IncomingWebhook" (
    id text NOT NULL,
    "workflowId" integer NOT NULL,
    url text NOT NULL,
    secret text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "totalReceived" integer DEFAULT 0 NOT NULL,
    "lastReceivedAt" timestamp(3) without time zone,
    "failureCount" integer DEFAULT 0 NOT NULL,
    "lastError" text,
    events text[],
    "retryPolicy" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."IncomingWebhook" OWNER TO whms;

--
-- Name: IpAccessRule; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."IpAccessRule" (
    id integer NOT NULL,
    pattern text NOT NULL,
    type public."IpRuleType" NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."IpAccessRule" OWNER TO whms;

--
-- Name: IpAccessRule_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."IpAccessRule_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."IpAccessRule_id_seq" OWNER TO whms;

--
-- Name: IpAccessRule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."IpAccessRule_id_seq" OWNED BY public."IpAccessRule".id;


--
-- Name: LoginLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."LoginLog" (
    id text NOT NULL,
    "userId" text,
    "userEmail" text,
    success boolean NOT NULL,
    ip text,
    "userAgent" text,
    reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoginLog" OWNER TO whms;

--
-- Name: MarketplaceActiveInstance; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceActiveInstance" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    "instanceId" text NOT NULL,
    "userId" text,
    "lastSeen" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceActiveInstance" OWNER TO whms;

--
-- Name: MarketplaceAnalytics; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceAnalytics" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    "eventType" text NOT NULL,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceAnalytics" OWNER TO whms;

--
-- Name: MarketplaceAnalyticsAggregate; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceAnalyticsAggregate" (
    id text NOT NULL,
    "productId" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    installs integer DEFAULT 0 NOT NULL,
    active integer DEFAULT 0 NOT NULL,
    crashes integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceAnalyticsAggregate" OWNER TO whms;

--
-- Name: MarketplaceBuildLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceBuildLog" (
    id text NOT NULL,
    "submissionId" text,
    "productId" text,
    "versionId" text,
    level text DEFAULT 'info'::text NOT NULL,
    message text NOT NULL,
    meta jsonb,
    step text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceBuildLog" OWNER TO whms;

--
-- Name: MarketplaceCategory; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceCategory" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    icon text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."MarketplaceCategory" OWNER TO whms;

--
-- Name: MarketplaceCrash; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceCrash" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    "userId" text,
    message text NOT NULL,
    "stackTrace" text,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceCrash" OWNER TO whms;

--
-- Name: MarketplaceDependency; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceDependency" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "dependencyId" text NOT NULL,
    "versionRange" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    approved boolean DEFAULT false NOT NULL
);


ALTER TABLE public."MarketplaceDependency" OWNER TO whms;

--
-- Name: MarketplaceLicenseActivation; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceLicenseActivation" (
    id text NOT NULL,
    "licenseId" text NOT NULL,
    "userAgent" text,
    host text,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceLicenseActivation" OWNER TO whms;

--
-- Name: MarketplacePerfMetric; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplacePerfMetric" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    metric text NOT NULL,
    value double precision NOT NULL,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplacePerfMetric" OWNER TO whms;

--
-- Name: MarketplaceProduct; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceProduct" (
    id text NOT NULL,
    "sellerId" text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    "shortDesc" text,
    "longDesc" text,
    "categoryId" text,
    tags text[] DEFAULT ARRAY[]::text[],
    status text DEFAULT 'draft'::text NOT NULL,
    "rejectReason" text,
    logo text,
    screenshots text[] DEFAULT ARRAY[]::text[],
    documentation text,
    "ratingAvg" double precision DEFAULT 0 NOT NULL,
    "ratingCount" integer DEFAULT 0 NOT NULL,
    "installCount" integer DEFAULT 0 NOT NULL,
    "downloadCount" integer DEFAULT 0 NOT NULL,
    "lastUpdatedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "approvedAt" timestamp(3) without time zone
);


ALTER TABLE public."MarketplaceProduct" OWNER TO whms;

--
-- Name: MarketplacePurchase; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplacePurchase" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text NOT NULL,
    "licenseKey" text NOT NULL,
    subscribed boolean DEFAULT false NOT NULL,
    "activationLimit" integer DEFAULT 1 NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    revoked boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplacePurchase" OWNER TO whms;

--
-- Name: MarketplaceReview; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceReview" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    rating integer NOT NULL,
    stability integer,
    review text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceReview" OWNER TO whms;

--
-- Name: MarketplaceSubmission; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceSubmission" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text,
    "reviewerId" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."MarketplaceSubmissionStatus" NOT NULL
);


ALTER TABLE public."MarketplaceSubmission" OWNER TO whms;

--
-- Name: MarketplaceVerification; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceVerification" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "versionId" text NOT NULL,
    passed boolean NOT NULL,
    issues jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceVerification" OWNER TO whms;

--
-- Name: MarketplaceVersion; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceVersion" (
    id text NOT NULL,
    "productId" text NOT NULL,
    version text NOT NULL,
    "manifestJson" jsonb NOT NULL,
    "archivePath" text NOT NULL,
    changelog text,
    "priceCents" integer NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "approvedAt" timestamp(3) without time zone
);


ALTER TABLE public."MarketplaceVersion" OWNER TO whms;

--
-- Name: MarketplaceWebhook; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceWebhook" (
    id text NOT NULL,
    event text NOT NULL,
    payload jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceWebhook" OWNER TO whms;

--
-- Name: MarketplaceWebhookEndpoint; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."MarketplaceWebhookEndpoint" (
    id text NOT NULL,
    "vendorId" text NOT NULL,
    url text NOT NULL,
    secret text,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketplaceWebhookEndpoint" OWNER TO whms;

--
-- Name: NotificationRule; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."NotificationRule" (
    id integer NOT NULL,
    trigger character varying(100) NOT NULL,
    "actionType" character varying(100),
    method character varying(50) NOT NULL,
    destination character varying(500) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."NotificationRule" OWNER TO whms;

--
-- Name: NotificationRule_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."NotificationRule_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."NotificationRule_id_seq" OWNER TO whms;

--
-- Name: NotificationRule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."NotificationRule_id_seq" OWNED BY public."NotificationRule".id;


--
-- Name: Order; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    "clientId" text NOT NULL,
    "snapshotId" integer NOT NULL,
    status public."OrderStatus" DEFAULT 'pending'::public."OrderStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "nextRenewalAt" timestamp(3) without time zone,
    "suspendedAt" timestamp(3) without time zone,
    "terminatedAt" timestamp(3) without time zone,
    "cancelledAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Order" OWNER TO whms;

--
-- Name: Permission; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Permission" (
    id text NOT NULL,
    key text NOT NULL,
    description text
);


ALTER TABLE public."Permission" OWNER TO whms;

--
-- Name: ProviderConfig; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ProviderConfig" (
    id integer NOT NULL,
    name text NOT NULL,
    key text,
    secret text,
    endpoint text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProviderConfig" OWNER TO whms;

--
-- Name: ProviderConfig_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."ProviderConfig_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProviderConfig_id_seq" OWNER TO whms;

--
-- Name: ProviderConfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."ProviderConfig_id_seq" OWNED BY public."ProviderConfig".id;


--
-- Name: RateLimitRule; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."RateLimitRule" (
    id integer NOT NULL,
    type character varying(50) NOT NULL,
    target character varying(255) NOT NULL,
    "limit" integer NOT NULL,
    "window" integer NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."RateLimitRule" OWNER TO whms;

--
-- Name: RateLimitRule_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."RateLimitRule_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RateLimitRule_id_seq" OWNER TO whms;

--
-- Name: RateLimitRule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."RateLimitRule_id_seq" OWNED BY public."RateLimitRule".id;


--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."RefreshToken" (
    id integer NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RefreshToken" OWNER TO whms;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."RefreshToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RefreshToken_id_seq" OWNER TO whms;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."RefreshToken_id_seq" OWNED BY public."RefreshToken".id;


--
-- Name: ResellerProfile; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ResellerProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "resellerCode" text NOT NULL,
    company text,
    phone text,
    address text
);


ALTER TABLE public."ResellerProfile" OWNER TO whms;

--
-- Name: Role; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public."Role" OWNER TO whms;

--
-- Name: RolePermission; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."RolePermission" (
    id text NOT NULL,
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL
);


ALTER TABLE public."RolePermission" OWNER TO whms;

--
-- Name: Service; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Service" (
    id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    code text NOT NULL
);


ALTER TABLE public."Service" OWNER TO whms;

--
-- Name: ServicePlan; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ServicePlan" (
    id integer NOT NULL,
    "serviceId" integer NOT NULL,
    name text NOT NULL,
    summary text,
    active boolean DEFAULT true NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServicePlan" OWNER TO whms;

--
-- Name: ServicePlan_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."ServicePlan_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ServicePlan_id_seq" OWNER TO whms;

--
-- Name: ServicePlan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."ServicePlan_id_seq" OWNED BY public."ServicePlan".id;


--
-- Name: ServicePolicy; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ServicePolicy" (
    id integer NOT NULL,
    "planId" integer NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    enforced boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ServicePolicy" OWNER TO whms;

--
-- Name: ServicePolicy_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."ServicePolicy_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ServicePolicy_id_seq" OWNER TO whms;

--
-- Name: ServicePolicy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."ServicePolicy_id_seq" OWNED BY public."ServicePolicy".id;


--
-- Name: ServicePricing; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ServicePricing" (
    id integer NOT NULL,
    "planId" integer NOT NULL,
    cycle public."BillingCycle" NOT NULL,
    price numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServicePricing" OWNER TO whms;

--
-- Name: ServicePricing_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."ServicePricing_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ServicePricing_id_seq" OWNER TO whms;

--
-- Name: ServicePricing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."ServicePricing_id_seq" OWNED BY public."ServicePricing".id;


--
-- Name: ServiceSnapshot; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."ServiceSnapshot" (
    id integer NOT NULL,
    "serviceId" integer NOT NULL,
    "planId" integer,
    snapshot jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ServiceSnapshot" OWNER TO whms;

--
-- Name: ServiceSnapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."ServiceSnapshot_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ServiceSnapshot_id_seq" OWNER TO whms;

--
-- Name: ServiceSnapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."ServiceSnapshot_id_seq" OWNED BY public."ServiceSnapshot".id;


--
-- Name: Service_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."Service_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Service_id_seq" OWNER TO whms;

--
-- Name: Service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."Service_id_seq" OWNED BY public."Service".id;


--
-- Name: Session; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "userAgent" text,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "isImpersonation" boolean DEFAULT false NOT NULL,
    "impersonatorId" text,
    "impersonationReason" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    country text,
    "deviceHash" text,
    "lastActivity" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Session" OWNER TO whms;

--
-- Name: StorageConfig; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."StorageConfig" (
    id integer NOT NULL,
    name text NOT NULL,
    provider text NOT NULL,
    config jsonb NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StorageConfig" OWNER TO whms;

--
-- Name: StorageConfig_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."StorageConfig_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StorageConfig_id_seq" OWNER TO whms;

--
-- Name: StorageConfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."StorageConfig_id_seq" OWNED BY public."StorageConfig".id;


--
-- Name: Ticket; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Ticket" (
    id integer NOT NULL,
    "clientId" text NOT NULL,
    subject text NOT NULL,
    message text NOT NULL,
    priority text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Ticket" OWNER TO whms;

--
-- Name: Ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."Ticket_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Ticket_id_seq" OWNER TO whms;

--
-- Name: Ticket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."Ticket_id_seq" OWNED BY public."Ticket".id;


--
-- Name: Tld; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Tld" (
    id integer NOT NULL,
    name text NOT NULL,
    "registerPrice" integer,
    "renewPrice" integer,
    "transferPrice" integer,
    "markupPercent" integer,
    "providerData" jsonb,
    "lastSynced" timestamp(3) without time zone,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Tld" OWNER TO whms;

--
-- Name: TldPricing; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."TldPricing" (
    id integer NOT NULL,
    tld text NOT NULL,
    registration numeric(10,2) NOT NULL,
    renewal numeric(10,2) NOT NULL,
    transfer numeric(10,2) NOT NULL,
    provider text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TldPricing" OWNER TO whms;

--
-- Name: TldPricing_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."TldPricing_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TldPricing_id_seq" OWNER TO whms;

--
-- Name: TldPricing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."TldPricing_id_seq" OWNED BY public."TldPricing".id;


--
-- Name: Tld_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."Tld_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Tld_id_seq" OWNER TO whms;

--
-- Name: Tld_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."Tld_id_seq" OWNED BY public."Tld".id;


--
-- Name: TrustedDevice; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."TrustedDevice" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "deviceId" text NOT NULL,
    "userAgent" text,
    ip text,
    name text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastUsedAt" timestamp(3) without time zone NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public."TrustedDevice" OWNER TO whms;

--
-- Name: User; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "mfaBackupCodes" text[] DEFAULT ARRAY[]::text[],
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaSecret" text,
    "passwordHash" text NOT NULL,
    disabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public."User" OWNER TO whms;

--
-- Name: UserRole; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."UserRole" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "roleId" text NOT NULL
);


ALTER TABLE public."UserRole" OWNER TO whms;

--
-- Name: Webhook; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."Webhook" (
    id text NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    secret text NOT NULL,
    events text[],
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Webhook" OWNER TO whms;

--
-- Name: WebhookLog; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."WebhookLog" (
    id text NOT NULL,
    "webhookId" text NOT NULL,
    event text NOT NULL,
    payload jsonb NOT NULL,
    status text NOT NULL,
    "httpStatus" integer,
    attempts integer DEFAULT 0 NOT NULL,
    "lastError" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WebhookLog" OWNER TO whms;

--
-- Name: WorkflowAlert; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."WorkflowAlert" (
    id text NOT NULL,
    "workflowId" integer NOT NULL,
    condition text NOT NULL,
    threshold double precision NOT NULL,
    "notifyTo" text[],
    "notifyMethod" text NOT NULL,
    "notifyWebhook" text,
    enabled boolean DEFAULT true NOT NULL,
    "lastAlertAt" timestamp(3) without time zone,
    "alertCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WorkflowAlert" OWNER TO whms;

--
-- Name: WorkflowEvent; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."WorkflowEvent" (
    id text NOT NULL,
    type text NOT NULL,
    source text NOT NULL,
    data jsonb NOT NULL,
    metadata jsonb,
    processed boolean DEFAULT false NOT NULL,
    "processedAt" timestamp(3) without time zone,
    error text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WorkflowEvent" OWNER TO whms;

--
-- Name: WorkflowRun; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."WorkflowRun" (
    id integer NOT NULL,
    "workflowId" integer NOT NULL,
    status public."WorkflowRunStatus" DEFAULT 'pending'::public."WorkflowRunStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    "totalDuration" integer,
    "taskCount" integer DEFAULT 0 NOT NULL,
    "successCount" integer DEFAULT 0 NOT NULL,
    "failureCount" integer DEFAULT 0 NOT NULL,
    "skippedCount" integer DEFAULT 0 NOT NULL,
    "failedTaskId" text,
    "errorMessage" text,
    "errorStack" text,
    "triggeredBy" text DEFAULT 'manual'::text NOT NULL,
    "triggerId" text,
    input jsonb,
    output jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WorkflowRun" OWNER TO whms;

--
-- Name: WorkflowRun_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."WorkflowRun_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."WorkflowRun_id_seq" OWNER TO whms;

--
-- Name: WorkflowRun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."WorkflowRun_id_seq" OWNED BY public."WorkflowRun".id;


--
-- Name: WorkflowSchedule; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."WorkflowSchedule" (
    id text NOT NULL,
    "workflowId" integer NOT NULL,
    "cronExpression" text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    input jsonb,
    "lastRunAt" timestamp(3) without time zone,
    "nextRunAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WorkflowSchedule" OWNER TO whms;

--
-- Name: WorkflowTaskRun; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."WorkflowTaskRun" (
    id integer NOT NULL,
    "runId" integer NOT NULL,
    "taskId" text NOT NULL,
    status public."WorkflowTaskStatus" DEFAULT 'pending'::public."WorkflowTaskStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    duration integer,
    output jsonb,
    "errorMessage" text,
    "errorStack" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 0 NOT NULL,
    "nextRetryAt" timestamp(3) without time zone,
    "conditionResult" boolean,
    "selectedPath" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WorkflowTaskRun" OWNER TO whms;

--
-- Name: WorkflowTaskRun_id_seq; Type: SEQUENCE; Schema: public; Owner: whms
--

CREATE SEQUENCE public."WorkflowTaskRun_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."WorkflowTaskRun_id_seq" OWNER TO whms;

--
-- Name: WorkflowTaskRun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whms
--

ALTER SEQUENCE public."WorkflowTaskRun_id_seq" OWNED BY public."WorkflowTaskRun".id;


--
-- Name: WorkflowTriggerRule; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public."WorkflowTriggerRule" (
    id text NOT NULL,
    "workflowId" integer NOT NULL,
    "eventType" text NOT NULL,
    conditions jsonb,
    "passEventAsInput" boolean DEFAULT true NOT NULL,
    "inputMapping" jsonb,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WorkflowTriggerRule" OWNER TO whms;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: whms
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO whms;

--
-- Name: ActionMetric id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ActionMetric" ALTER COLUMN id SET DEFAULT nextval('public."ActionMetric_id_seq"'::regclass);


--
-- Name: ActionTemplate id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ActionTemplate" ALTER COLUMN id SET DEFAULT nextval('public."ActionTemplate_id_seq"'::regclass);


--
-- Name: AuditLog id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AuditLog" ALTER COLUMN id SET DEFAULT nextval('public."AuditLog_id_seq"'::regclass);


--
-- Name: AutomationProfile id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationProfile" ALTER COLUMN id SET DEFAULT nextval('public."AutomationProfile_id_seq"'::regclass);


--
-- Name: AutomationRun id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationRun" ALTER COLUMN id SET DEFAULT nextval('public."AutomationRun_id_seq"'::regclass);


--
-- Name: AutomationTask id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationTask" ALTER COLUMN id SET DEFAULT nextval('public."AutomationTask_id_seq"'::regclass);


--
-- Name: AutomationWorkflow id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationWorkflow" ALTER COLUMN id SET DEFAULT nextval('public."AutomationWorkflow_id_seq"'::regclass);


--
-- Name: DNSRecord id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DNSRecord" ALTER COLUMN id SET DEFAULT nextval('public."DNSRecord_id_seq"'::regclass);


--
-- Name: Domain id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Domain" ALTER COLUMN id SET DEFAULT nextval('public."Domain_id_seq"'::regclass);


--
-- Name: DomainContact id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainContact" ALTER COLUMN id SET DEFAULT nextval('public."DomainContact_id_seq"'::regclass);


--
-- Name: DomainLog id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainLog" ALTER COLUMN id SET DEFAULT nextval('public."DomainLog_id_seq"'::regclass);


--
-- Name: DomainRegistrarCommand id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainRegistrarCommand" ALTER COLUMN id SET DEFAULT nextval('public."DomainRegistrarCommand_id_seq"'::regclass);


--
-- Name: DomainTransfer id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainTransfer" ALTER COLUMN id SET DEFAULT nextval('public."DomainTransfer_id_seq"'::regclass);


--
-- Name: EmailEvent id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailEvent" ALTER COLUMN id SET DEFAULT nextval('public."EmailEvent_id_seq"'::regclass);


--
-- Name: EmailTemplate id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailTemplate" ALTER COLUMN id SET DEFAULT nextval('public."EmailTemplate_id_seq"'::regclass);


--
-- Name: IpAccessRule id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."IpAccessRule" ALTER COLUMN id SET DEFAULT nextval('public."IpAccessRule_id_seq"'::regclass);


--
-- Name: NotificationRule id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."NotificationRule" ALTER COLUMN id SET DEFAULT nextval('public."NotificationRule_id_seq"'::regclass);


--
-- Name: ProviderConfig id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ProviderConfig" ALTER COLUMN id SET DEFAULT nextval('public."ProviderConfig_id_seq"'::regclass);


--
-- Name: RateLimitRule id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RateLimitRule" ALTER COLUMN id SET DEFAULT nextval('public."RateLimitRule_id_seq"'::regclass);


--
-- Name: RefreshToken id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RefreshToken" ALTER COLUMN id SET DEFAULT nextval('public."RefreshToken_id_seq"'::regclass);


--
-- Name: Service id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Service" ALTER COLUMN id SET DEFAULT nextval('public."Service_id_seq"'::regclass);


--
-- Name: ServicePlan id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServicePlan" ALTER COLUMN id SET DEFAULT nextval('public."ServicePlan_id_seq"'::regclass);


--
-- Name: ServicePolicy id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServicePolicy" ALTER COLUMN id SET DEFAULT nextval('public."ServicePolicy_id_seq"'::regclass);


--
-- Name: ServicePricing id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServicePricing" ALTER COLUMN id SET DEFAULT nextval('public."ServicePricing_id_seq"'::regclass);


--
-- Name: ServiceSnapshot id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServiceSnapshot" ALTER COLUMN id SET DEFAULT nextval('public."ServiceSnapshot_id_seq"'::regclass);


--
-- Name: StorageConfig id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."StorageConfig" ALTER COLUMN id SET DEFAULT nextval('public."StorageConfig_id_seq"'::regclass);


--
-- Name: Ticket id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Ticket" ALTER COLUMN id SET DEFAULT nextval('public."Ticket_id_seq"'::regclass);


--
-- Name: Tld id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Tld" ALTER COLUMN id SET DEFAULT nextval('public."Tld_id_seq"'::regclass);


--
-- Name: TldPricing id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."TldPricing" ALTER COLUMN id SET DEFAULT nextval('public."TldPricing_id_seq"'::regclass);


--
-- Name: WorkflowRun id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowRun" ALTER COLUMN id SET DEFAULT nextval('public."WorkflowRun_id_seq"'::regclass);


--
-- Name: WorkflowTaskRun id; Type: DEFAULT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowTaskRun" ALTER COLUMN id SET DEFAULT nextval('public."WorkflowTaskRun_id_seq"'::regclass);


--
-- Data for Name: ActionMetric; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ActionMetric" (id, "actionType", "executionCount", "successCount", "failureCount", "avgDuration", "maxDuration", "minDuration", "p95Duration", "p99Duration", "lastExecutedAt", "lastError", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ActionTemplate; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ActionTemplate" (id, "actionType", name, description, "inputSchema", "outputSchema", category, "isBuiltin", "isActive", documentation, examples, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AdminProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AdminProfile" (id, "userId", department, "staffTitle", "restrictionJson") FROM stdin;
73840da4-51e0-4e39-bb6f-f228ced54bb7	a423cb2f-8d0b-4165-879f-4eb12650242e	System	Super Administrator	\N
\.


--
-- Data for Name: ApiKey; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ApiKey" (id, "userId", name, "keyHash", "createdAt", revoked, "expiresAt") FROM stdin;
26d7f7d3-fc30-4e7b-ae6b-893dd15dd082	795dcab8-8188-4a25-9721-795d05e643d3	TestKey	$2b$12$cT//aiVJwgX1yfSk3VqcW.jcm.XpXPdqLpoQyInlgJzdJZYOX/zjq	2026-01-06 04:26:02.543	f	2026-01-13 04:26:02.542
\.


--
-- Data for Name: ApiKeyScope; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ApiKeyScope" (id, "apiKeyId", scope) FROM stdin;
1284a0a3-a23e-4db8-8707-ae7708711b69	26d7f7d3-fc30-4e7b-ae6b-893dd15dd082	read
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AuditLog" ("userId", action, "createdAt", data, entity, "entityId", ip, "userAgent", actor, level, meta, source, id, "profileId") FROM stdin;
a423cb2f-8d0b-4165-879f-4eb12650242e	login.success	2026-01-06 04:25:54.481	{"email": "superadmin@example.com", "reason": "login_success"}	auth	a423cb2f-8d0b-4165-879f-4eb12650242e	::1	curl/8.5.0	system	INFO	\N	system	1	\N
a423cb2f-8d0b-4165-879f-4eb12650242e	security.new_device	2026-01-06 04:25:54.496	{"ip": "::1", "country": "Unknown", "userAgent": "curl/8.5.0"}	session	a423cb2f-8d0b-4165-879f-4eb12650242e	::1	curl/8.5.0	system	INFO	\N	system	2	\N
795dcab8-8188-4a25-9721-795d05e643d3	login.success	2026-01-06 04:26:01.02	{"email": "test-1767673553@example.com", "reason": "login_success"}	auth	795dcab8-8188-4a25-9721-795d05e643d3	::1	curl/8.5.0	system	INFO	\N	system	3	\N
795dcab8-8188-4a25-9721-795d05e643d3	security.new_device	2026-01-06 04:26:01.034	{"ip": "::1", "country": "Unknown", "userAgent": "curl/8.5.0"}	session	795dcab8-8188-4a25-9721-795d05e643d3	::1	curl/8.5.0	system	INFO	\N	system	4	\N
795dcab8-8188-4a25-9721-795d05e643d3	login.failure	2026-01-06 04:26:01.462	{"email": "test-1767673553@example.com", "reason": "invalid_password"}	auth	795dcab8-8188-4a25-9721-795d05e643d3	::1	curl/8.5.0	system	INFO	\N	system	5	\N
\N	login.failure	2026-01-06 04:26:01.511	{"email": "ghost@example.com", "reason": "user_not_found"}	auth	\N	::1	curl/8.5.0	system	INFO	\N	system	6	\N
795dcab8-8188-4a25-9721-795d05e643d3	api_key.create	2026-01-06 04:26:02.559	{"scopes": ["read"]}	ApiKey	26d7f7d3-fc30-4e7b-ae6b-893dd15dd082	\N	\N	system	INFO	\N	system	7	\N
a423cb2f-8d0b-4165-879f-4eb12650242e	login.success	2026-01-06 04:28:06.162	{"email": "superadmin@example.com", "reason": "login_success"}	auth	a423cb2f-8d0b-4165-879f-4eb12650242e	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	8	\N
a423cb2f-8d0b-4165-879f-4eb12650242e	security.new_device	2026-01-06 04:28:06.177	{"ip": "::1", "country": "Unknown", "userAgent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"}	session	a423cb2f-8d0b-4165-879f-4eb12650242e	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	system	INFO	\N	system	9	\N
\N	backup.queued	2026-01-06 04:34:08.647	null	Backup	cmk23hl6b00001ct3qa7jt4k4	\N	\N	a423cb2f-8d0b-4165-879f-4eb12650242e	INFO	null	backup	10	\N
\.


--
-- Data for Name: AutomationProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AutomationProfile" (id, name, description, cron, enabled, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AutomationRun; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AutomationRun" (id, "profileId", "taskId", result, "errorMessage", "startedAt", "finishedAt", "createdAt", status) FROM stdin;
\.


--
-- Data for Name: AutomationTask; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AutomationTask" (id, "profileId", "actionType", "actionMeta", "order", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AutomationWorkflow; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."AutomationWorkflow" (id, name, slug, description, definition, enabled, version, "isDraft", trigger, type, "eventType", "eventFilter", "webhookUrl", "webhookSecret", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: Backup; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Backup" (id, name, type, "storageConfigId", "filePath", "sizeBytes", status, "retentionDays", "createdById", "createdAt", "startedAt", "finishedAt", deleted, "errorMessage") FROM stdin;
cmk23hl6b00001ct3qa7jt4k4	Quick Backup 1/6/2026, 9:34:08 AM	full	\N	\N	\N	running	30	a423cb2f-8d0b-4165-879f-4eb12650242e	2026-01-06 04:34:08.627	2026-01-06 04:34:08.83	\N	f	\N
\.


--
-- Data for Name: BackupStepLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."BackupStepLog" (id, "backupId", step, meta, status, message, "createdAt") FROM stdin;
bd9e4586-62ff-4a54-a4ea-a9227f20242c	cmk23hl6b00001ct3qa7jt4k4	job_started	{}	success	\N	2026-01-06 04:34:08.85
9997e2c7-c27d-44fb-963c-e12c32c4adf4	cmk23hl6b00001ct3qa7jt4k4	provider_ready	{"provider": "local"}	success	\N	2026-01-06 04:34:08.874
d407ef56-0640-4687-b2f0-121837bd2e1f	cmk23hl6b00001ct3qa7jt4k4	db_dump_started	{}	started	\N	2026-01-06 04:34:08.899
\.


--
-- Data for Name: BackupVersion; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."BackupVersion" (id, "backupId", version, "filePath", "sizeBytes", "createdAt") FROM stdin;
\.


--
-- Data for Name: ClientProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ClientProfile" (id, "userId", company, phone, address, country, city, postal) FROM stdin;
65eef14b-d986-4568-8e4c-82037e227f22	437159a9-ccd3-4806-ad9d-b0c105f1fca4	Test Client Company	\N	\N	\N	\N	\N
b36e69ba-44dc-43b9-8b0d-0f15912a65ae	795dcab8-8188-4a25-9721-795d05e643d3	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: DNSRecord; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."DNSRecord" (id, "domainId", type, name, value, ttl, "createdAt", "updatedAt", "providerRecordId") FROM stdin;
\.


--
-- Data for Name: DeveloperProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."DeveloperProfile" (id, "userId", "displayName", website, github, "payoutsEmail", "createdAt", "marketplaceMeta", "publicKeyPem", "storeName", "stripeAccountId", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Domain; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Domain" (id, name, "expiryDate", nameservers, metadata, "createdAt", "updatedAt", "autoRenew", currency, "ownerId", "providerConfigId", registrar, "registrationPrice", "renewalPrice", status) FROM stdin;
\.


--
-- Data for Name: DomainContact; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."DomainContact" (id, "domainId", type, name, email, phone, country, "createdAt") FROM stdin;
\.


--
-- Data for Name: DomainLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."DomainLog" (id, "domainId", action, message, meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: DomainRegistrarCommand; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."DomainRegistrarCommand" (id, "domainId", action, request, response, success, "createdAt") FROM stdin;
\.


--
-- Data for Name: DomainTransfer; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."DomainTransfer" (id, "domainId", "authCode", status, "requestedAt", "completedAt", "providerResponse") FROM stdin;
\.


--
-- Data for Name: EmailEvent; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."EmailEvent" (id, "jobId", "eventType", "providerId", payload, "createdAt") FROM stdin;
\.


--
-- Data for Name: EmailJob; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."EmailJob" (id, "templateId", "templateName", "toEmail", "toName", payload, status, attempts, "lastError", priority, provider, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: EmailTemplate; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."EmailTemplate" (id, name, subject, "bodyHtml", "bodyText", language, "isDefault", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: EmailToken; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."EmailToken" (id, "userId", "tokenHash", type, "createdAt", "expiresAt", used) FROM stdin;
6ca8d661-47b9-4e3b-b81c-5f52e1ea5bed	795dcab8-8188-4a25-9721-795d05e643d3	e3189392f7007bed6e51cb96f55b62599b538b8389b0f7c5d904fda92b2d990b	verify	2026-01-06 04:25:54.928	2026-01-06 04:40:54.926	f
\.


--
-- Data for Name: Impersonation; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Impersonation" (id, "adminId", "impersonatedId", "startedAt", "endedAt", "sessionToken", reason) FROM stdin;
\.


--
-- Data for Name: IncomingWebhook; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."IncomingWebhook" (id, "workflowId", url, secret, enabled, "totalReceived", "lastReceivedAt", "failureCount", "lastError", events, "retryPolicy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: IpAccessRule; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."IpAccessRule" (id, pattern, type, description, active, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: LoginLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."LoginLog" (id, "userId", "userEmail", success, ip, "userAgent", reason, "createdAt") FROM stdin;
c811f805-9e83-4e56-9e14-9f526d34f953	a423cb2f-8d0b-4165-879f-4eb12650242e	superadmin@example.com	t	::1	curl/8.5.0	login_success	2026-01-06 04:25:54.466
e9d6e786-42a9-4417-a2b3-113048da9992	795dcab8-8188-4a25-9721-795d05e643d3	test-1767673553@example.com	t	::1	curl/8.5.0	login_success	2026-01-06 04:26:01.007
8e2ad081-dd4e-4ac7-9531-f1e276701aae	795dcab8-8188-4a25-9721-795d05e643d3	test-1767673553@example.com	f	::1	curl/8.5.0	invalid_password	2026-01-06 04:26:01.448
34b0cf99-dd65-40f6-b22f-14bd4d199bd2	\N	ghost@example.com	f	::1	curl/8.5.0	user_not_found	2026-01-06 04:26:01.495
28cf1971-457f-47d6-a3bd-544600c64150	a423cb2f-8d0b-4165-879f-4eb12650242e	superadmin@example.com	t	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	login_success	2026-01-06 04:28:06.147
\.


--
-- Data for Name: MarketplaceActiveInstance; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceActiveInstance" (id, "productId", "versionId", "instanceId", "userId", "lastSeen", meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceAnalytics; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceAnalytics" (id, "productId", "versionId", "eventType", meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceAnalyticsAggregate; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceAnalyticsAggregate" (id, "productId", date, installs, active, crashes, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceBuildLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceBuildLog" (id, "submissionId", "productId", "versionId", level, message, meta, step, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceCategory; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceCategory" (id, name, slug, icon, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceCrash; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceCrash" (id, "productId", "versionId", "userId", message, "stackTrace", meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceDependency; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceDependency" (id, "productId", "dependencyId", "versionRange", "createdAt", approved) FROM stdin;
\.


--
-- Data for Name: MarketplaceLicenseActivation; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceLicenseActivation" (id, "licenseId", "userAgent", host, ip, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplacePerfMetric; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplacePerfMetric" (id, "productId", "versionId", metric, value, meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceProduct; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceProduct" (id, "sellerId", title, slug, "shortDesc", "longDesc", "categoryId", tags, status, "rejectReason", logo, screenshots, documentation, "ratingAvg", "ratingCount", "installCount", "downloadCount", "lastUpdatedAt", "createdAt", "updatedAt", "approvedAt") FROM stdin;
\.


--
-- Data for Name: MarketplacePurchase; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplacePurchase" (id, "userId", "productId", "versionId", "licenseKey", subscribed, "activationLimit", "expiresAt", revoked, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceReview; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceReview" (id, "productId", "userId", rating, stability, review, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceSubmission; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceSubmission" (id, "productId", "versionId", "reviewerId", notes, "createdAt", status) FROM stdin;
\.


--
-- Data for Name: MarketplaceVerification; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceVerification" (id, "productId", "versionId", passed, issues, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceVersion; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceVersion" (id, "productId", version, "manifestJson", "archivePath", changelog, "priceCents", currency, "createdAt", "approvedAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceWebhook; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceWebhook" (id, event, payload, "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceWebhookEndpoint; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."MarketplaceWebhookEndpoint" (id, "vendorId", url, secret, enabled, "createdAt") FROM stdin;
\.


--
-- Data for Name: NotificationRule; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."NotificationRule" (id, trigger, "actionType", method, destination, enabled, "createdAt") FROM stdin;
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Order" (id, "clientId", "snapshotId", status, "startedAt", "nextRenewalAt", "suspendedAt", "terminatedAt", "cancelledAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Permission" (id, key, description) FROM stdin;
bea27bf4-74e0-4aa2-b1f3-5f7c87dc2277	admin.access	Access admin portal
a53510cd-c233-447d-90f3-22588c778f68	admin.manage.staff	Manage admin staff accounts
9512f2e3-2b4b-4f27-a118-25361e254205	admin.settings.update	Update system settings
1abe2791-2ba7-442e-ab16-c0604bc8c469	client.area.access	Access client dashboard
e83c5e52-75da-423d-8a53-6cc96ed0cf82	billing.invoices.view	View invoices
1fe22277-b054-4f4a-9f2c-16aba0a7efc4	billing.invoices.pay	Pay invoices
336081fe-3274-4459-840d-1118e3059872	reseller.dashboard.access	Access reseller dashboard
5e2254b4-ed96-4ce0-bb1b-cfed3f7d24b7	developer.console.access	Access developer console
e4402a09-7756-4864-ac1c-4f19d9e16c55	plugins.upload	Upload new plugin to marketplace
b275b794-69b6-4168-8c9c-478570c86d95	plugins.update	Update existing plugin versions
87b69723-073b-4349-9468-760cfd83cbb6	orders.create	Create a new order
38a11802-d53c-4679-aac2-627843d93835	orders.read	View own orders
2313e85b-3ebb-4652-b6a7-09a218c5e3a7	orders.cancel	Cancel pending orders
a2727490-a5b0-44f7-9a86-2918779668fc	orders.renew	Renew active orders
\.


--
-- Data for Name: ProviderConfig; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ProviderConfig" (id, name, key, secret, endpoint, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: RateLimitRule; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."RateLimitRule" (id, type, target, "limit", "window", enabled, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."RefreshToken" (id, token, "userId", revoked, "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: ResellerProfile; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ResellerProfile" (id, "userId", "resellerCode", company, phone, address) FROM stdin;
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Role" (id, name, description) FROM stdin;
6c14d86b-cee4-4ccd-887d-e218553392b5	superadmin	Full unrestricted access
9a859891-80c2-4dff-bfc8-5cfdcdf22492	admin	Admin access with limited control
51fc596f-5c8e-4db6-88c1-4f1cf45ad992	staff	Support/billing agent
4f185528-3c89-418d-983d-98eb3b0e30be	client	Regular client account
8355a70d-f67a-4ace-8168-a6d886989e6d	reseller	Reseller portal access
c2a255c0-ec71-41ca-9d6d-815f0163e0ff	developer	Marketplace developer
\.


--
-- Data for Name: RolePermission; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."RolePermission" (id, "roleId", "permissionId") FROM stdin;
2a2142f1-118f-468b-91ca-def4a25fed6e	4f185528-3c89-418d-983d-98eb3b0e30be	1abe2791-2ba7-442e-ab16-c0604bc8c469
1eceac5d-1bd0-4b88-abbb-c7107633b2a3	4f185528-3c89-418d-983d-98eb3b0e30be	e83c5e52-75da-423d-8a53-6cc96ed0cf82
4b373612-a9d5-4fdb-b3fa-104d3ff01d42	4f185528-3c89-418d-983d-98eb3b0e30be	1fe22277-b054-4f4a-9f2c-16aba0a7efc4
5a9735c8-bfad-4490-97aa-334ef0ecf8c3	6c14d86b-cee4-4ccd-887d-e218553392b5	1abe2791-2ba7-442e-ab16-c0604bc8c469
6884d2dc-ee2d-4ccf-b814-d75d550572bb	6c14d86b-cee4-4ccd-887d-e218553392b5	e83c5e52-75da-423d-8a53-6cc96ed0cf82
72683e7f-7c15-451c-b39e-327dcc8441f4	6c14d86b-cee4-4ccd-887d-e218553392b5	1fe22277-b054-4f4a-9f2c-16aba0a7efc4
182cbde8-e6b7-4491-b268-03868c71714f	6c14d86b-cee4-4ccd-887d-e218553392b5	bea27bf4-74e0-4aa2-b1f3-5f7c87dc2277
9c624881-aefb-43c2-80ce-e2e93443819d	6c14d86b-cee4-4ccd-887d-e218553392b5	a53510cd-c233-447d-90f3-22588c778f68
43a54685-c4e6-4742-91c1-7ccb3753b05d	6c14d86b-cee4-4ccd-887d-e218553392b5	9512f2e3-2b4b-4f27-a118-25361e254205
6b6bdc34-1abd-42c7-a894-da26867e046b	6c14d86b-cee4-4ccd-887d-e218553392b5	336081fe-3274-4459-840d-1118e3059872
3ec6e83d-11d4-4abc-bfe8-f9e2d18e9dac	6c14d86b-cee4-4ccd-887d-e218553392b5	5e2254b4-ed96-4ce0-bb1b-cfed3f7d24b7
d3ce5ee0-f688-4ea0-839c-4375562fc808	6c14d86b-cee4-4ccd-887d-e218553392b5	e4402a09-7756-4864-ac1c-4f19d9e16c55
82d73af2-1685-4a08-91d1-2c8120152207	6c14d86b-cee4-4ccd-887d-e218553392b5	b275b794-69b6-4168-8c9c-478570c86d95
f1ce6a10-5a0b-4aee-a0d8-63a836090867	9a859891-80c2-4dff-bfc8-5cfdcdf22492	bea27bf4-74e0-4aa2-b1f3-5f7c87dc2277
2c56a318-b564-43f2-a3c0-2d0ce5c87420	9a859891-80c2-4dff-bfc8-5cfdcdf22492	e83c5e52-75da-423d-8a53-6cc96ed0cf82
7e44a98c-9eb1-4792-8454-a072bd2bd269	9a859891-80c2-4dff-bfc8-5cfdcdf22492	1fe22277-b054-4f4a-9f2c-16aba0a7efc4
166d462f-9ab2-4865-8b73-e21b9056347b	9a859891-80c2-4dff-bfc8-5cfdcdf22492	1abe2791-2ba7-442e-ab16-c0604bc8c469
5ea1959c-b420-4730-a5a4-97e1eb19ec80	51fc596f-5c8e-4db6-88c1-4f1cf45ad992	bea27bf4-74e0-4aa2-b1f3-5f7c87dc2277
f5addf14-c6e3-4794-aba3-6e36e47053c0	51fc596f-5c8e-4db6-88c1-4f1cf45ad992	e83c5e52-75da-423d-8a53-6cc96ed0cf82
cffaba53-4c8d-4cec-b118-a7ac2477a67b	4f185528-3c89-418d-983d-98eb3b0e30be	87b69723-073b-4349-9468-760cfd83cbb6
a6ac835d-67d3-409c-9d59-df131f2b017a	4f185528-3c89-418d-983d-98eb3b0e30be	38a11802-d53c-4679-aac2-627843d93835
22ef22a2-7a9d-48ee-bc8f-0cb4d26b1a18	4f185528-3c89-418d-983d-98eb3b0e30be	2313e85b-3ebb-4652-b6a7-09a218c5e3a7
b96571ce-e098-4618-b4a3-610cd4b5f9b3	4f185528-3c89-418d-983d-98eb3b0e30be	a2727490-a5b0-44f7-9a86-2918779668fc
0035ecd2-d372-4cf4-83b3-9bf749ec6f00	8355a70d-f67a-4ace-8168-a6d886989e6d	336081fe-3274-4459-840d-1118e3059872
26edf235-49ba-4da3-81e3-1a6800715a9e	8355a70d-f67a-4ace-8168-a6d886989e6d	e83c5e52-75da-423d-8a53-6cc96ed0cf82
9d2527e9-8ea5-4b9e-903f-e60e6b0ae085	8355a70d-f67a-4ace-8168-a6d886989e6d	1fe22277-b054-4f4a-9f2c-16aba0a7efc4
29c7575e-bcf8-42bb-9867-1c152a9deb33	c2a255c0-ec71-41ca-9d6d-815f0163e0ff	5e2254b4-ed96-4ce0-bb1b-cfed3f7d24b7
9cebb414-98f4-40ec-95a6-0876cc0b684f	c2a255c0-ec71-41ca-9d6d-815f0163e0ff	e4402a09-7756-4864-ac1c-4f19d9e16c55
3c337ada-cf71-46e4-8f27-23a6f5d3399f	c2a255c0-ec71-41ca-9d6d-815f0163e0ff	b275b794-69b6-4168-8c9c-478570c86d95
\.


--
-- Data for Name: Service; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Service" (id, name, description, active, "createdAt", "updatedAt", code) FROM stdin;
\.


--
-- Data for Name: ServicePlan; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ServicePlan" (id, "serviceId", name, summary, active, "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServicePolicy; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ServicePolicy" (id, "planId", key, value, enforced, "createdAt") FROM stdin;
\.


--
-- Data for Name: ServicePricing; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ServicePricing" (id, "planId", cycle, price, currency, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceSnapshot; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."ServiceSnapshot" (id, "serviceId", "planId", snapshot, "createdAt") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Session" (id, "userId", token, "userAgent", ip, "createdAt", "expiresAt", "isImpersonation", "impersonatorId", "impersonationReason", "updatedAt", country, "deviceHash", "lastActivity") FROM stdin;
bec6df52-9ecc-4d05-8c6e-4c9d06031ee2	437159a9-ccd3-4806-ad9d-b0c105f1fca4	2e71e27ca7a626ee1a218679cbf43b754e5ae50b1c5ffec99faf2a415cd931c7d6fddffefcc7385346fb938c04cc81ef	seed.client.js	127.0.0.1	2026-01-06 04:19:50.742	2026-01-07 04:19:50.74	f	\N	\N	2026-01-06 04:19:50.742	\N	\N	2026-01-06 04:19:50.742
f184f6e1-d103-4d16-adf4-c9b864f91ad5	a423cb2f-8d0b-4165-879f-4eb12650242e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJhNDIzY2IyZi04ZDBiLTQxNjUtODc5Zi00ZWIxMjY1MDI0MmUiLCJpYXQiOjE3Njc2NzM1NTQsImV4cCI6MTc2NzY3NDQ1NH0.jjTmPGwQ2YEHdgRXdJiIS_coibyqbK_7x9jlTFPVQag	curl/8.5.0	::1	2026-01-06 04:25:54.451	2026-01-07 04:25:54.451	f	\N	\N	2026-01-06 04:26:02.807	Unknown	a5f8a0759cab09873b4d361c6434b5ec3ba3036ae022c2681626f834f924934f	2026-01-06 04:26:02.806
0c63bbb8-2995-49fb-8610-b9beebac4e54	795dcab8-8188-4a25-9721-795d05e643d3	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3OTVkY2FiOC04MTg4LTRhMjUtOTcyMS03OTVkMDVlNjQzZDMiLCJpYXQiOjE3Njc2NzM1NjAsImV4cCI6MTc2NzY3NDQ2MH0.O8idXoORqYhFGUiBKEb2EJTlGXJXU3OqsaWPPe9vtfQ	curl/8.5.0	::1	2026-01-06 04:26:00.993	2026-01-07 04:26:00.992	f	\N	\N	2026-01-06 04:26:03.014	Unknown	a5f8a0759cab09873b4d361c6434b5ec3ba3036ae022c2681626f834f924934f	2026-01-06 04:26:03.012
3fbaf445-55fc-4086-b1f1-982fe346bea7	a423cb2f-8d0b-4165-879f-4eb12650242e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJhNDIzY2IyZi04ZDBiLTQxNjUtODc5Zi00ZWIxMjY1MDI0MmUiLCJpYXQiOjE3Njc2NzM2ODYsImV4cCI6MTc2NzY3NDU4Nn0.030TLXi9DFxloRZiwpnYMgWMAs_HwvCGnTZZC2soM_4	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	::1	2026-01-06 04:28:06.133	2026-01-07 04:28:06.132	f	\N	\N	2026-01-06 04:34:08.894	Unknown	d882a3cfb5d2acf9a477cece54f35af2a28aca4e9aa78269b1345ce0122eca8a	2026-01-06 04:34:08.893
\.


--
-- Data for Name: StorageConfig; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."StorageConfig" (id, name, provider, config, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Ticket; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Ticket" (id, "clientId", subject, message, priority, status, "createdAt") FROM stdin;
\.


--
-- Data for Name: Tld; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Tld" (id, name, "registerPrice", "renewPrice", "transferPrice", "markupPercent", "providerData", "lastSynced", active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TldPricing; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."TldPricing" (id, tld, registration, renewal, transfer, provider, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TrustedDevice; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."TrustedDevice" (id, "userId", "deviceId", "userAgent", ip, name, "createdAt", "lastUsedAt", "expiresAt", revoked) FROM stdin;
c4065188-1ea6-472d-ae63-a89034ee9c8d	795dcab8-8188-4a25-9721-795d05e643d3	449718c734ec299346a5a3623b0e3cc5c4c9450822bb5d28d30d9d2fb1e3bae1	curl/8.5.0	::1	Test Device	2026-01-06 04:26:02.103	2026-01-06 04:26:02.103	2026-02-05 04:26:02.101	f
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."User" (id, email, "createdAt", "updatedAt", "emailVerified", "mfaBackupCodes", "mfaEnabled", "mfaSecret", "passwordHash", disabled) FROM stdin;
437159a9-ccd3-4806-ad9d-b0c105f1fca4	client.test@example.com	2026-01-06 04:19:50.693	2026-01-06 04:19:50.693	t	{}	f	\N	$2b$12$izGqIMj9cp1pZKOclCPAh.Y/wDBcoj1Jdbdx8PoyfEuBubPACtgC6	f
a423cb2f-8d0b-4165-879f-4eb12650242e	superadmin@example.com	2026-01-06 04:20:03.526	2026-01-06 04:20:03.526	t	{}	f	\N	$2b$12$ihE0OsOUQYw.GAsdrFRqyO2e5u1OVSKUza9wLUQ6jOvDwiYCojrxu	f
795dcab8-8188-4a25-9721-795d05e643d3	test-1767673553@example.com	2026-01-06 04:25:54.878	2026-01-06 04:26:01.982	f	{}	f	BY7CCCKPPR7VYS3L	$2b$12$p0ah6ueg1IAgFKlpRz8Ng.56fLPGbUtD5bIUdLNEAGcYB0D94H39O	f
\.


--
-- Data for Name: UserRole; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."UserRole" (id, "userId", "roleId") FROM stdin;
928d05df-2c5c-42e1-97f1-669efc3dfd18	437159a9-ccd3-4806-ad9d-b0c105f1fca4	4f185528-3c89-418d-983d-98eb3b0e30be
3231fb4b-80e2-46f6-8768-b814e454dee2	a423cb2f-8d0b-4165-879f-4eb12650242e	6c14d86b-cee4-4ccd-887d-e218553392b5
bf58d2c7-aa85-4a69-ba42-7609bff21217	795dcab8-8188-4a25-9721-795d05e643d3	4f185528-3c89-418d-983d-98eb3b0e30be
\.


--
-- Data for Name: Webhook; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."Webhook" (id, name, url, secret, events, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WebhookLog; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."WebhookLog" (id, "webhookId", event, payload, status, "httpStatus", attempts, "lastError", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WorkflowAlert; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."WorkflowAlert" (id, "workflowId", condition, threshold, "notifyTo", "notifyMethod", "notifyWebhook", enabled, "lastAlertAt", "alertCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WorkflowEvent; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."WorkflowEvent" (id, type, source, data, metadata, processed, "processedAt", error, "createdAt") FROM stdin;
\.


--
-- Data for Name: WorkflowRun; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."WorkflowRun" (id, "workflowId", status, "startedAt", "finishedAt", "totalDuration", "taskCount", "successCount", "failureCount", "skippedCount", "failedTaskId", "errorMessage", "errorStack", "triggeredBy", "triggerId", input, output, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WorkflowSchedule; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."WorkflowSchedule" (id, "workflowId", "cronExpression", enabled, timezone, input, "lastRunAt", "nextRunAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WorkflowTaskRun; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."WorkflowTaskRun" (id, "runId", "taskId", status, "startedAt", "finishedAt", duration, output, "errorMessage", "errorStack", "retryCount", "maxRetries", "nextRetryAt", "conditionResult", "selectedPath", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WorkflowTriggerRule; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public."WorkflowTriggerRule" (id, "workflowId", "eventType", conditions, "passEventAsInput", "inputMapping", enabled, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: whms
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
08daab30-2a15-4bdf-bee6-3c7a89fc0d7c	0b22e8da0114278e0a2478a3b422ea4aa0eaf78a482d94bd1ec28efbb36de0a8	2026-01-06 09:19:02.697274+05	20251102133357_1	\N	\N	2026-01-06 09:19:01.855089+05	1
495b10b1-3a13-4d57-bacc-e988710ae9ba	f778d00637262317531b181af9f7bb00afabf0039ce49d9e0eaeccda529301bd	2026-01-06 09:19:03.168352+05	20251113125544_fix_clientservice	\N	\N	2026-01-06 09:19:02.711961+05	1
8dcea4e2-cb7b-4159-9024-5cea9e787f52	539261c0e62b19c7e760b8a3431cdf98f2e1bbb3ff7d265ebdf3ed48f5056c45	2026-01-06 09:19:03.863266+05	20251117130838_a1	\N	\N	2026-01-06 09:19:03.183102+05	1
5fb3a65b-4beb-4cc2-a2af-3393926cd09e	a41269562fd5cb363ff2ebc64fe821eb80c9f83c1711e36d906dc8704163a8ab	2026-01-06 09:19:03.930604+05	20251117151539_fix_task_run_cascade	\N	\N	2026-01-06 09:19:03.878389+05	1
1b517739-1887-4337-a972-0c170e58e9c0	6d877e84b2cc9feb7982a52dedb6d9676f5f5f4cab147356956d40b82ce4cc48	2026-01-06 09:19:04.118715+05	20251118110922_plugin_system_upgrade	\N	\N	2026-01-06 09:19:03.94602+05	1
5ee6c9bf-26d1-42b5-82bf-40f91715cde0	ed04d033c454d6dfb945872035964c182a89c02d4146787e9401f654eb8baa8e	2026-01-06 09:19:04.182639+05	20251118211942_fix_cascade_delete	\N	\N	2026-01-06 09:19:04.133703+05	1
610f48a1-90d7-4e3e-9a3e-0e561c1b40c8	87bbe3502a0427c1d07e41850f64efddc6ba1c7d612e94e51d8327079bd28114	2026-01-06 09:19:04.243512+05	20251118225417_plugin_marketplace_support	\N	\N	2026-01-06 09:19:04.19783+05	1
82cbcc69-c3f4-4140-a982-4569c144243e	7591952ba249f31243627ecc679176016d14efd15577677a82617d176d8ee040	2026-01-06 09:19:04.423533+05	20251119164909_backup	\N	\N	2026-01-06 09:19:04.258599+05	1
d9278dc8-4adc-46fa-9ea7-efd2388101fa	6a62ea7df3090b1d6d99220905e373a9f2a4bafec809a7de7ec8bf60e2dfea0b	2026-01-06 09:19:08.494141+05	20251203181037_init_auth_rbac	\N	\N	2026-01-06 09:19:04.440845+05	1
2a861ecb-22dd-4e62-903d-23c65ba23c98	dde6116df9de1d7a1272c0e8a5efff805dbab35f7c8d236002af337998652692	2026-01-06 09:19:09.192196+05	20251218175242_linux_init	\N	\N	2026-01-06 09:19:08.521726+05	1
6ba993e9-db3b-4aae-94d4-c3f712f51021	80e9e8fcc6632497bc5fb5c629d323e7332ee488bfb5cb6ecaaf726967b17922	2026-01-06 09:19:09.817461+05	20251226184151_domain	\N	\N	2026-01-06 09:19:09.207591+05	1
5a0ab4da-5f8c-4f2d-9308-a8c3388fe7f5	a6469d378454762a3030ba77409ef2473ebc442b9513cc649c60076243857386	2026-01-06 09:19:09.972739+05	20251227191553_add_services	\N	\N	2026-01-06 09:19:09.832538+05	1
e66f46c1-9c68-4ecc-a212-0f78b8b65f9a	34835f49b37b64d3f4f224060f53cc6123800eb6bba61effdf8559155a99731f	2026-01-06 09:19:12.936391+05	20260105181101_final_demo	\N	\N	2026-01-06 09:19:09.98902+05	1
\.


--
-- Name: ActionMetric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."ActionMetric_id_seq"', 1, false);


--
-- Name: ActionTemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."ActionTemplate_id_seq"', 1, false);


--
-- Name: AuditLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."AuditLog_id_seq"', 10, true);


--
-- Name: AutomationProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."AutomationProfile_id_seq"', 1, false);


--
-- Name: AutomationRun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."AutomationRun_id_seq"', 1, false);


--
-- Name: AutomationTask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."AutomationTask_id_seq"', 1, false);


--
-- Name: AutomationWorkflow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."AutomationWorkflow_id_seq"', 1, false);


--
-- Name: DNSRecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."DNSRecord_id_seq"', 1, false);


--
-- Name: DomainContact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."DomainContact_id_seq"', 1, false);


--
-- Name: DomainLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."DomainLog_id_seq"', 1, false);


--
-- Name: DomainRegistrarCommand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."DomainRegistrarCommand_id_seq"', 1, false);


--
-- Name: DomainTransfer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."DomainTransfer_id_seq"', 1, false);


--
-- Name: Domain_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."Domain_id_seq"', 1, false);


--
-- Name: EmailEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."EmailEvent_id_seq"', 1, false);


--
-- Name: EmailTemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."EmailTemplate_id_seq"', 1, false);


--
-- Name: IpAccessRule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."IpAccessRule_id_seq"', 1, false);


--
-- Name: NotificationRule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."NotificationRule_id_seq"', 1, false);


--
-- Name: ProviderConfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."ProviderConfig_id_seq"', 1, false);


--
-- Name: RateLimitRule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."RateLimitRule_id_seq"', 1, false);


--
-- Name: RefreshToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."RefreshToken_id_seq"', 1, false);


--
-- Name: ServicePlan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."ServicePlan_id_seq"', 1, false);


--
-- Name: ServicePolicy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."ServicePolicy_id_seq"', 1, false);


--
-- Name: ServicePricing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."ServicePricing_id_seq"', 1, false);


--
-- Name: ServiceSnapshot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."ServiceSnapshot_id_seq"', 1, false);


--
-- Name: Service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."Service_id_seq"', 1, false);


--
-- Name: StorageConfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."StorageConfig_id_seq"', 1, false);


--
-- Name: Ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."Ticket_id_seq"', 1, false);


--
-- Name: TldPricing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."TldPricing_id_seq"', 1, false);


--
-- Name: Tld_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."Tld_id_seq"', 1, false);


--
-- Name: WorkflowRun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."WorkflowRun_id_seq"', 1, false);


--
-- Name: WorkflowTaskRun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whms
--

SELECT pg_catalog.setval('public."WorkflowTaskRun_id_seq"', 1, false);


--
-- Name: ActionMetric ActionMetric_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ActionMetric"
    ADD CONSTRAINT "ActionMetric_pkey" PRIMARY KEY (id);


--
-- Name: ActionTemplate ActionTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ActionTemplate"
    ADD CONSTRAINT "ActionTemplate_pkey" PRIMARY KEY (id);


--
-- Name: AdminProfile AdminProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AdminProfile"
    ADD CONSTRAINT "AdminProfile_pkey" PRIMARY KEY (id);


--
-- Name: ApiKeyScope ApiKeyScope_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ApiKeyScope"
    ADD CONSTRAINT "ApiKeyScope_pkey" PRIMARY KEY (id);


--
-- Name: ApiKey ApiKey_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: AutomationProfile AutomationProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationProfile"
    ADD CONSTRAINT "AutomationProfile_pkey" PRIMARY KEY (id);


--
-- Name: AutomationRun AutomationRun_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationRun"
    ADD CONSTRAINT "AutomationRun_pkey" PRIMARY KEY (id);


--
-- Name: AutomationTask AutomationTask_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationTask"
    ADD CONSTRAINT "AutomationTask_pkey" PRIMARY KEY (id);


--
-- Name: AutomationWorkflow AutomationWorkflow_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationWorkflow"
    ADD CONSTRAINT "AutomationWorkflow_pkey" PRIMARY KEY (id);


--
-- Name: BackupStepLog BackupStepLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."BackupStepLog"
    ADD CONSTRAINT "BackupStepLog_pkey" PRIMARY KEY (id);


--
-- Name: BackupVersion BackupVersion_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."BackupVersion"
    ADD CONSTRAINT "BackupVersion_pkey" PRIMARY KEY (id);


--
-- Name: Backup Backup_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Backup"
    ADD CONSTRAINT "Backup_pkey" PRIMARY KEY (id);


--
-- Name: ClientProfile ClientProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_pkey" PRIMARY KEY (id);


--
-- Name: DNSRecord DNSRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DNSRecord"
    ADD CONSTRAINT "DNSRecord_pkey" PRIMARY KEY (id);


--
-- Name: DeveloperProfile DeveloperProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DeveloperProfile"
    ADD CONSTRAINT "DeveloperProfile_pkey" PRIMARY KEY (id);


--
-- Name: DomainContact DomainContact_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainContact"
    ADD CONSTRAINT "DomainContact_pkey" PRIMARY KEY (id);


--
-- Name: DomainLog DomainLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainLog"
    ADD CONSTRAINT "DomainLog_pkey" PRIMARY KEY (id);


--
-- Name: DomainRegistrarCommand DomainRegistrarCommand_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainRegistrarCommand"
    ADD CONSTRAINT "DomainRegistrarCommand_pkey" PRIMARY KEY (id);


--
-- Name: DomainTransfer DomainTransfer_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainTransfer"
    ADD CONSTRAINT "DomainTransfer_pkey" PRIMARY KEY (id);


--
-- Name: Domain Domain_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_pkey" PRIMARY KEY (id);


--
-- Name: EmailEvent EmailEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailEvent"
    ADD CONSTRAINT "EmailEvent_pkey" PRIMARY KEY (id);


--
-- Name: EmailJob EmailJob_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailJob"
    ADD CONSTRAINT "EmailJob_pkey" PRIMARY KEY (id);


--
-- Name: EmailTemplate EmailTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailTemplate"
    ADD CONSTRAINT "EmailTemplate_pkey" PRIMARY KEY (id);


--
-- Name: EmailToken EmailToken_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailToken"
    ADD CONSTRAINT "EmailToken_pkey" PRIMARY KEY (id);


--
-- Name: Impersonation Impersonation_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Impersonation"
    ADD CONSTRAINT "Impersonation_pkey" PRIMARY KEY (id);


--
-- Name: IncomingWebhook IncomingWebhook_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."IncomingWebhook"
    ADD CONSTRAINT "IncomingWebhook_pkey" PRIMARY KEY (id);


--
-- Name: IpAccessRule IpAccessRule_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."IpAccessRule"
    ADD CONSTRAINT "IpAccessRule_pkey" PRIMARY KEY (id);


--
-- Name: LoginLog LoginLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceActiveInstance MarketplaceActiveInstance_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceActiveInstance"
    ADD CONSTRAINT "MarketplaceActiveInstance_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceAnalyticsAggregate MarketplaceAnalyticsAggregate_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceAnalyticsAggregate"
    ADD CONSTRAINT "MarketplaceAnalyticsAggregate_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceAnalytics MarketplaceAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceAnalytics"
    ADD CONSTRAINT "MarketplaceAnalytics_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceBuildLog MarketplaceBuildLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceBuildLog"
    ADD CONSTRAINT "MarketplaceBuildLog_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceCategory MarketplaceCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceCategory"
    ADD CONSTRAINT "MarketplaceCategory_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceCrash MarketplaceCrash_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceCrash"
    ADD CONSTRAINT "MarketplaceCrash_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceDependency MarketplaceDependency_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceDependency"
    ADD CONSTRAINT "MarketplaceDependency_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceLicenseActivation MarketplaceLicenseActivation_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceLicenseActivation"
    ADD CONSTRAINT "MarketplaceLicenseActivation_pkey" PRIMARY KEY (id);


--
-- Name: MarketplacePerfMetric MarketplacePerfMetric_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePerfMetric"
    ADD CONSTRAINT "MarketplacePerfMetric_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceProduct MarketplaceProduct_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceProduct"
    ADD CONSTRAINT "MarketplaceProduct_pkey" PRIMARY KEY (id);


--
-- Name: MarketplacePurchase MarketplacePurchase_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceReview MarketplaceReview_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceReview"
    ADD CONSTRAINT "MarketplaceReview_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceSubmission MarketplaceSubmission_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceVerification MarketplaceVerification_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVerification"
    ADD CONSTRAINT "MarketplaceVerification_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceVersion MarketplaceVersion_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVersion"
    ADD CONSTRAINT "MarketplaceVersion_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceWebhookEndpoint MarketplaceWebhookEndpoint_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceWebhookEndpoint"
    ADD CONSTRAINT "MarketplaceWebhookEndpoint_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceWebhook MarketplaceWebhook_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceWebhook"
    ADD CONSTRAINT "MarketplaceWebhook_pkey" PRIMARY KEY (id);


--
-- Name: NotificationRule NotificationRule_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."NotificationRule"
    ADD CONSTRAINT "NotificationRule_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: ProviderConfig ProviderConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ProviderConfig"
    ADD CONSTRAINT "ProviderConfig_pkey" PRIMARY KEY (id);


--
-- Name: RateLimitRule RateLimitRule_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RateLimitRule"
    ADD CONSTRAINT "RateLimitRule_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: ResellerProfile ResellerProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ResellerProfile"
    ADD CONSTRAINT "ResellerProfile_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: ServicePlan ServicePlan_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServicePlan"
    ADD CONSTRAINT "ServicePlan_pkey" PRIMARY KEY (id);


--
-- Name: ServicePolicy ServicePolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServicePolicy"
    ADD CONSTRAINT "ServicePolicy_pkey" PRIMARY KEY (id);


--
-- Name: ServicePricing ServicePricing_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServicePricing"
    ADD CONSTRAINT "ServicePricing_pkey" PRIMARY KEY (id);


--
-- Name: ServiceSnapshot ServiceSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServiceSnapshot"
    ADD CONSTRAINT "ServiceSnapshot_pkey" PRIMARY KEY (id);


--
-- Name: Service Service_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: StorageConfig StorageConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."StorageConfig"
    ADD CONSTRAINT "StorageConfig_pkey" PRIMARY KEY (id);


--
-- Name: Ticket Ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_pkey" PRIMARY KEY (id);


--
-- Name: TldPricing TldPricing_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."TldPricing"
    ADD CONSTRAINT "TldPricing_pkey" PRIMARY KEY (id);


--
-- Name: Tld Tld_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Tld"
    ADD CONSTRAINT "Tld_pkey" PRIMARY KEY (id);


--
-- Name: TrustedDevice TrustedDevice_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."TrustedDevice"
    ADD CONSTRAINT "TrustedDevice_pkey" PRIMARY KEY (id);


--
-- Name: UserRole UserRole_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."UserRole"
    ADD CONSTRAINT "UserRole_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WebhookLog WebhookLog_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WebhookLog"
    ADD CONSTRAINT "WebhookLog_pkey" PRIMARY KEY (id);


--
-- Name: Webhook Webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Webhook"
    ADD CONSTRAINT "Webhook_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowAlert WorkflowAlert_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowAlert"
    ADD CONSTRAINT "WorkflowAlert_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowEvent WorkflowEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowEvent"
    ADD CONSTRAINT "WorkflowEvent_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowRun WorkflowRun_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowRun"
    ADD CONSTRAINT "WorkflowRun_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowSchedule WorkflowSchedule_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowSchedule"
    ADD CONSTRAINT "WorkflowSchedule_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowTaskRun WorkflowTaskRun_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowTaskRun"
    ADD CONSTRAINT "WorkflowTaskRun_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowTriggerRule WorkflowTriggerRule_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowTriggerRule"
    ADD CONSTRAINT "WorkflowTriggerRule_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: ActionMetric_actionType_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ActionMetric_actionType_key" ON public."ActionMetric" USING btree ("actionType");


--
-- Name: ActionTemplate_actionType_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ActionTemplate_actionType_key" ON public."ActionTemplate" USING btree ("actionType");


--
-- Name: ActionTemplate_category_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "ActionTemplate_category_idx" ON public."ActionTemplate" USING btree (category);


--
-- Name: ActionTemplate_isActive_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "ActionTemplate_isActive_idx" ON public."ActionTemplate" USING btree ("isActive");


--
-- Name: AdminProfile_userId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "AdminProfile_userId_key" ON public."AdminProfile" USING btree ("userId");


--
-- Name: AuditLog_profileId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AuditLog_profileId_idx" ON public."AuditLog" USING btree ("profileId");


--
-- Name: AutomationProfile_cron_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationProfile_cron_idx" ON public."AutomationProfile" USING btree (cron);


--
-- Name: AutomationProfile_enabled_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationProfile_enabled_idx" ON public."AutomationProfile" USING btree (enabled);


--
-- Name: AutomationProfile_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "AutomationProfile_name_key" ON public."AutomationProfile" USING btree (name);


--
-- Name: AutomationRun_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationRun_createdAt_idx" ON public."AutomationRun" USING btree ("createdAt");


--
-- Name: AutomationRun_profileId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationRun_profileId_idx" ON public."AutomationRun" USING btree ("profileId");


--
-- Name: AutomationRun_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationRun_status_idx" ON public."AutomationRun" USING btree (status);


--
-- Name: AutomationRun_taskId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationRun_taskId_idx" ON public."AutomationRun" USING btree ("taskId");


--
-- Name: AutomationTask_order_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationTask_order_idx" ON public."AutomationTask" USING btree ("order");


--
-- Name: AutomationTask_profileId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationTask_profileId_idx" ON public."AutomationTask" USING btree ("profileId");


--
-- Name: AutomationWorkflow_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationWorkflow_createdAt_idx" ON public."AutomationWorkflow" USING btree ("createdAt");


--
-- Name: AutomationWorkflow_enabled_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationWorkflow_enabled_idx" ON public."AutomationWorkflow" USING btree (enabled);


--
-- Name: AutomationWorkflow_eventType_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationWorkflow_eventType_idx" ON public."AutomationWorkflow" USING btree ("eventType");


--
-- Name: AutomationWorkflow_slug_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "AutomationWorkflow_slug_key" ON public."AutomationWorkflow" USING btree (slug);


--
-- Name: AutomationWorkflow_trigger_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "AutomationWorkflow_trigger_idx" ON public."AutomationWorkflow" USING btree (trigger);


--
-- Name: AutomationWorkflow_webhookUrl_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "AutomationWorkflow_webhookUrl_key" ON public."AutomationWorkflow" USING btree ("webhookUrl");


--
-- Name: BackupStepLog_backupId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "BackupStepLog_backupId_idx" ON public."BackupStepLog" USING btree ("backupId");


--
-- Name: BackupStepLog_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "BackupStepLog_createdAt_idx" ON public."BackupStepLog" USING btree ("createdAt");


--
-- Name: BackupStepLog_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "BackupStepLog_status_idx" ON public."BackupStepLog" USING btree (status);


--
-- Name: BackupVersion_backupId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "BackupVersion_backupId_idx" ON public."BackupVersion" USING btree ("backupId");


--
-- Name: BackupVersion_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "BackupVersion_createdAt_idx" ON public."BackupVersion" USING btree ("createdAt");


--
-- Name: Backup_createdById_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Backup_createdById_idx" ON public."Backup" USING btree ("createdById");


--
-- Name: Backup_deleted_status_finishedAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Backup_deleted_status_finishedAt_idx" ON public."Backup" USING btree (deleted, status, "finishedAt");


--
-- Name: Backup_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Backup_status_idx" ON public."Backup" USING btree (status);


--
-- Name: ClientProfile_userId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ClientProfile_userId_key" ON public."ClientProfile" USING btree ("userId");


--
-- Name: DNSRecord_domainId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "DNSRecord_domainId_idx" ON public."DNSRecord" USING btree ("domainId");


--
-- Name: DeveloperProfile_userId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "DeveloperProfile_userId_key" ON public."DeveloperProfile" USING btree ("userId");


--
-- Name: DomainContact_domainId_type_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "DomainContact_domainId_type_key" ON public."DomainContact" USING btree ("domainId", type);


--
-- Name: DomainLog_domainId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "DomainLog_domainId_idx" ON public."DomainLog" USING btree ("domainId");


--
-- Name: DomainRegistrarCommand_action_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "DomainRegistrarCommand_action_idx" ON public."DomainRegistrarCommand" USING btree (action);


--
-- Name: DomainRegistrarCommand_domainId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "DomainRegistrarCommand_domainId_idx" ON public."DomainRegistrarCommand" USING btree ("domainId");


--
-- Name: DomainTransfer_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "DomainTransfer_status_idx" ON public."DomainTransfer" USING btree (status);


--
-- Name: Domain_expiryDate_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Domain_expiryDate_idx" ON public."Domain" USING btree ("expiryDate");


--
-- Name: Domain_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Domain_name_key" ON public."Domain" USING btree (name);


--
-- Name: Domain_ownerId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Domain_ownerId_idx" ON public."Domain" USING btree ("ownerId");


--
-- Name: Domain_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Domain_status_idx" ON public."Domain" USING btree (status);


--
-- Name: EmailEvent_jobId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "EmailEvent_jobId_idx" ON public."EmailEvent" USING btree ("jobId");


--
-- Name: EmailJob_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "EmailJob_status_idx" ON public."EmailJob" USING btree (status);


--
-- Name: EmailJob_templateId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "EmailJob_templateId_idx" ON public."EmailJob" USING btree ("templateId");


--
-- Name: EmailTemplate_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "EmailTemplate_name_key" ON public."EmailTemplate" USING btree (name);


--
-- Name: Impersonation_sessionToken_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Impersonation_sessionToken_key" ON public."Impersonation" USING btree ("sessionToken");


--
-- Name: IncomingWebhook_enabled_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "IncomingWebhook_enabled_idx" ON public."IncomingWebhook" USING btree (enabled);


--
-- Name: IncomingWebhook_url_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "IncomingWebhook_url_key" ON public."IncomingWebhook" USING btree (url);


--
-- Name: IncomingWebhook_workflowId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "IncomingWebhook_workflowId_idx" ON public."IncomingWebhook" USING btree ("workflowId");


--
-- Name: IpAccessRule_pattern_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "IpAccessRule_pattern_idx" ON public."IpAccessRule" USING btree (pattern);


--
-- Name: MarketplaceActiveInstance_instanceId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceActiveInstance_instanceId_idx" ON public."MarketplaceActiveInstance" USING btree ("instanceId");


--
-- Name: MarketplaceActiveInstance_lastSeen_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceActiveInstance_lastSeen_idx" ON public."MarketplaceActiveInstance" USING btree ("lastSeen");


--
-- Name: MarketplaceActiveInstance_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceActiveInstance_productId_idx" ON public."MarketplaceActiveInstance" USING btree ("productId");


--
-- Name: MarketplaceAnalyticsAggregate_productId_date_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalyticsAggregate_productId_date_idx" ON public."MarketplaceAnalyticsAggregate" USING btree ("productId", date);


--
-- Name: MarketplaceAnalyticsAggregate_productId_date_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplaceAnalyticsAggregate_productId_date_key" ON public."MarketplaceAnalyticsAggregate" USING btree ("productId", date);


--
-- Name: MarketplaceAnalytics_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalytics_createdAt_idx" ON public."MarketplaceAnalytics" USING btree ("createdAt");


--
-- Name: MarketplaceAnalytics_eventType_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalytics_eventType_idx" ON public."MarketplaceAnalytics" USING btree ("eventType");


--
-- Name: MarketplaceAnalytics_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalytics_productId_idx" ON public."MarketplaceAnalytics" USING btree ("productId");


--
-- Name: MarketplaceAnalytics_versionId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceAnalytics_versionId_idx" ON public."MarketplaceAnalytics" USING btree ("versionId");


--
-- Name: MarketplaceBuildLog_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceBuildLog_createdAt_idx" ON public."MarketplaceBuildLog" USING btree ("createdAt");


--
-- Name: MarketplaceBuildLog_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceBuildLog_productId_idx" ON public."MarketplaceBuildLog" USING btree ("productId");


--
-- Name: MarketplaceBuildLog_submissionId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceBuildLog_submissionId_idx" ON public."MarketplaceBuildLog" USING btree ("submissionId");


--
-- Name: MarketplaceBuildLog_versionId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceBuildLog_versionId_idx" ON public."MarketplaceBuildLog" USING btree ("versionId");


--
-- Name: MarketplaceCategory_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplaceCategory_name_key" ON public."MarketplaceCategory" USING btree (name);


--
-- Name: MarketplaceCategory_slug_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplaceCategory_slug_key" ON public."MarketplaceCategory" USING btree (slug);


--
-- Name: MarketplaceCrash_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceCrash_createdAt_idx" ON public."MarketplaceCrash" USING btree ("createdAt");


--
-- Name: MarketplaceCrash_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceCrash_productId_idx" ON public."MarketplaceCrash" USING btree ("productId");


--
-- Name: MarketplaceCrash_versionId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceCrash_versionId_idx" ON public."MarketplaceCrash" USING btree ("versionId");


--
-- Name: MarketplacePerfMetric_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplacePerfMetric_createdAt_idx" ON public."MarketplacePerfMetric" USING btree ("createdAt");


--
-- Name: MarketplacePerfMetric_metric_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplacePerfMetric_metric_idx" ON public."MarketplacePerfMetric" USING btree (metric);


--
-- Name: MarketplacePerfMetric_productId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplacePerfMetric_productId_idx" ON public."MarketplacePerfMetric" USING btree ("productId");


--
-- Name: MarketplaceProduct_slug_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplaceProduct_slug_key" ON public."MarketplaceProduct" USING btree (slug);


--
-- Name: MarketplacePurchase_licenseKey_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "MarketplacePurchase_licenseKey_key" ON public."MarketplacePurchase" USING btree ("licenseKey");


--
-- Name: MarketplaceWebhookEndpoint_vendorId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "MarketplaceWebhookEndpoint_vendorId_idx" ON public."MarketplaceWebhookEndpoint" USING btree ("vendorId");


--
-- Name: NotificationRule_enabled_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "NotificationRule_enabled_idx" ON public."NotificationRule" USING btree (enabled);


--
-- Name: NotificationRule_trigger_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "NotificationRule_trigger_idx" ON public."NotificationRule" USING btree (trigger);


--
-- Name: Order_clientId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Order_clientId_idx" ON public."Order" USING btree ("clientId");


--
-- Name: Order_nextRenewalAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Order_nextRenewalAt_idx" ON public."Order" USING btree ("nextRenewalAt");


--
-- Name: Order_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Order_status_idx" ON public."Order" USING btree (status);


--
-- Name: Permission_key_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Permission_key_key" ON public."Permission" USING btree (key);


--
-- Name: ProviderConfig_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ProviderConfig_name_key" ON public."ProviderConfig" USING btree (name);


--
-- Name: RateLimitRule_enabled_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "RateLimitRule_enabled_idx" ON public."RateLimitRule" USING btree (enabled);


--
-- Name: RateLimitRule_type_target_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "RateLimitRule_type_target_key" ON public."RateLimitRule" USING btree (type, target);


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: RefreshToken_userId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "RefreshToken_userId_idx" ON public."RefreshToken" USING btree ("userId");


--
-- Name: ResellerProfile_resellerCode_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ResellerProfile_resellerCode_key" ON public."ResellerProfile" USING btree ("resellerCode");


--
-- Name: ResellerProfile_userId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ResellerProfile_userId_key" ON public."ResellerProfile" USING btree ("userId");


--
-- Name: RolePermission_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "RolePermission_roleId_permissionId_key" ON public."RolePermission" USING btree ("roleId", "permissionId");


--
-- Name: Role_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Role_name_key" ON public."Role" USING btree (name);


--
-- Name: ServicePlan_serviceId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "ServicePlan_serviceId_idx" ON public."ServicePlan" USING btree ("serviceId");


--
-- Name: ServicePlan_serviceId_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ServicePlan_serviceId_name_key" ON public."ServicePlan" USING btree ("serviceId", name);


--
-- Name: ServicePolicy_planId_key_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ServicePolicy_planId_key_key" ON public."ServicePolicy" USING btree ("planId", key);


--
-- Name: ServicePricing_planId_cycle_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "ServicePricing_planId_cycle_key" ON public."ServicePricing" USING btree ("planId", cycle);


--
-- Name: ServicePricing_planId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "ServicePricing_planId_idx" ON public."ServicePricing" USING btree ("planId");


--
-- Name: ServiceSnapshot_serviceId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "ServiceSnapshot_serviceId_idx" ON public."ServiceSnapshot" USING btree ("serviceId");


--
-- Name: Service_active_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Service_active_idx" ON public."Service" USING btree (active);


--
-- Name: Service_code_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Service_code_key" ON public."Service" USING btree (code);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: StorageConfig_createdById_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "StorageConfig_createdById_idx" ON public."StorageConfig" USING btree ("createdById");


--
-- Name: StorageConfig_provider_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "StorageConfig_provider_idx" ON public."StorageConfig" USING btree (provider);


--
-- Name: Ticket_clientId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "Ticket_clientId_idx" ON public."Ticket" USING btree ("clientId");


--
-- Name: TldPricing_tld_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "TldPricing_tld_key" ON public."TldPricing" USING btree (tld);


--
-- Name: Tld_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Tld_name_key" ON public."Tld" USING btree (name);


--
-- Name: TrustedDevice_deviceId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "TrustedDevice_deviceId_key" ON public."TrustedDevice" USING btree ("deviceId");


--
-- Name: UserRole_userId_roleId_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "UserRole_userId_roleId_key" ON public."UserRole" USING btree ("userId", "roleId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Webhook_name_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "Webhook_name_key" ON public."Webhook" USING btree (name);


--
-- Name: WorkflowAlert_condition_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowAlert_condition_idx" ON public."WorkflowAlert" USING btree (condition);


--
-- Name: WorkflowAlert_workflowId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowAlert_workflowId_idx" ON public."WorkflowAlert" USING btree ("workflowId");


--
-- Name: WorkflowEvent_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowEvent_createdAt_idx" ON public."WorkflowEvent" USING btree ("createdAt");


--
-- Name: WorkflowEvent_processed_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowEvent_processed_idx" ON public."WorkflowEvent" USING btree (processed);


--
-- Name: WorkflowEvent_source_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowEvent_source_idx" ON public."WorkflowEvent" USING btree (source);


--
-- Name: WorkflowEvent_type_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowEvent_type_idx" ON public."WorkflowEvent" USING btree (type);


--
-- Name: WorkflowRun_createdAt_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowRun_createdAt_idx" ON public."WorkflowRun" USING btree ("createdAt");


--
-- Name: WorkflowRun_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowRun_status_idx" ON public."WorkflowRun" USING btree (status);


--
-- Name: WorkflowRun_triggeredBy_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowRun_triggeredBy_idx" ON public."WorkflowRun" USING btree ("triggeredBy");


--
-- Name: WorkflowRun_workflowId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowRun_workflowId_idx" ON public."WorkflowRun" USING btree ("workflowId");


--
-- Name: WorkflowSchedule_enabled_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowSchedule_enabled_idx" ON public."WorkflowSchedule" USING btree (enabled);


--
-- Name: WorkflowSchedule_workflowId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowSchedule_workflowId_idx" ON public."WorkflowSchedule" USING btree ("workflowId");


--
-- Name: WorkflowTaskRun_runId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowTaskRun_runId_idx" ON public."WorkflowTaskRun" USING btree ("runId");


--
-- Name: WorkflowTaskRun_status_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowTaskRun_status_idx" ON public."WorkflowTaskRun" USING btree (status);


--
-- Name: WorkflowTaskRun_taskId_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowTaskRun_taskId_idx" ON public."WorkflowTaskRun" USING btree ("taskId");


--
-- Name: WorkflowTriggerRule_eventType_idx; Type: INDEX; Schema: public; Owner: whms
--

CREATE INDEX "WorkflowTriggerRule_eventType_idx" ON public."WorkflowTriggerRule" USING btree ("eventType");


--
-- Name: WorkflowTriggerRule_workflowId_eventType_key; Type: INDEX; Schema: public; Owner: whms
--

CREATE UNIQUE INDEX "WorkflowTriggerRule_workflowId_eventType_key" ON public."WorkflowTriggerRule" USING btree ("workflowId", "eventType");


--
-- Name: AdminProfile AdminProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AdminProfile"
    ADD CONSTRAINT "AdminProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ApiKeyScope ApiKeyScope_apiKeyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ApiKeyScope"
    ADD CONSTRAINT "ApiKeyScope_apiKeyId_fkey" FOREIGN KEY ("apiKeyId") REFERENCES public."ApiKey"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ApiKey ApiKey_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public."AutomationProfile"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AutomationRun AutomationRun_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationRun"
    ADD CONSTRAINT "AutomationRun_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public."AutomationProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationRun AutomationRun_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationRun"
    ADD CONSTRAINT "AutomationRun_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."AutomationTask"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AutomationTask AutomationTask_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."AutomationTask"
    ADD CONSTRAINT "AutomationTask_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public."AutomationProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BackupStepLog BackupStepLog_backupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."BackupStepLog"
    ADD CONSTRAINT "BackupStepLog_backupId_fkey" FOREIGN KEY ("backupId") REFERENCES public."Backup"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: BackupVersion BackupVersion_backupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."BackupVersion"
    ADD CONSTRAINT "BackupVersion_backupId_fkey" FOREIGN KEY ("backupId") REFERENCES public."Backup"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ClientProfile ClientProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DNSRecord DNSRecord_domainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DNSRecord"
    ADD CONSTRAINT "DNSRecord_domainId_fkey" FOREIGN KEY ("domainId") REFERENCES public."Domain"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DeveloperProfile DeveloperProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DeveloperProfile"
    ADD CONSTRAINT "DeveloperProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DomainContact DomainContact_domainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainContact"
    ADD CONSTRAINT "DomainContact_domainId_fkey" FOREIGN KEY ("domainId") REFERENCES public."Domain"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DomainLog DomainLog_domainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainLog"
    ADD CONSTRAINT "DomainLog_domainId_fkey" FOREIGN KEY ("domainId") REFERENCES public."Domain"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DomainRegistrarCommand DomainRegistrarCommand_domainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainRegistrarCommand"
    ADD CONSTRAINT "DomainRegistrarCommand_domainId_fkey" FOREIGN KEY ("domainId") REFERENCES public."Domain"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DomainTransfer DomainTransfer_domainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."DomainTransfer"
    ADD CONSTRAINT "DomainTransfer_domainId_fkey" FOREIGN KEY ("domainId") REFERENCES public."Domain"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Domain Domain_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Domain Domain_providerConfigId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_providerConfigId_fkey" FOREIGN KEY ("providerConfigId") REFERENCES public."ProviderConfig"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EmailJob EmailJob_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailJob"
    ADD CONSTRAINT "EmailJob_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."EmailTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EmailToken EmailToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."EmailToken"
    ADD CONSTRAINT "EmailToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Impersonation Impersonation_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Impersonation"
    ADD CONSTRAINT "Impersonation_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Impersonation Impersonation_impersonatedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Impersonation"
    ADD CONSTRAINT "Impersonation_impersonatedId_fkey" FOREIGN KEY ("impersonatedId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IncomingWebhook IncomingWebhook_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."IncomingWebhook"
    ADD CONSTRAINT "IncomingWebhook_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public."AutomationWorkflow"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LoginLog LoginLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceAnalytics MarketplaceAnalytics_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceAnalytics"
    ADD CONSTRAINT "MarketplaceAnalytics_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceAnalytics MarketplaceAnalytics_versionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceAnalytics"
    ADD CONSTRAINT "MarketplaceAnalytics_versionId_fkey" FOREIGN KEY ("versionId") REFERENCES public."MarketplaceVersion"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceDependency MarketplaceDependency_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceDependency"
    ADD CONSTRAINT "MarketplaceDependency_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceLicenseActivation MarketplaceLicenseActivation_licenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceLicenseActivation"
    ADD CONSTRAINT "MarketplaceLicenseActivation_licenseId_fkey" FOREIGN KEY ("licenseId") REFERENCES public."MarketplacePurchase"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceProduct MarketplaceProduct_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceProduct"
    ADD CONSTRAINT "MarketplaceProduct_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."MarketplaceCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceProduct MarketplaceProduct_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceProduct"
    ADD CONSTRAINT "MarketplaceProduct_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."DeveloperProfile"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplacePurchase MarketplacePurchase_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplacePurchase MarketplacePurchase_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplacePurchase MarketplacePurchase_versionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplacePurchase"
    ADD CONSTRAINT "MarketplacePurchase_versionId_fkey" FOREIGN KEY ("versionId") REFERENCES public."MarketplaceVersion"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceReview MarketplaceReview_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceReview"
    ADD CONSTRAINT "MarketplaceReview_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceReview MarketplaceReview_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceReview"
    ADD CONSTRAINT "MarketplaceReview_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceSubmission MarketplaceSubmission_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceSubmission MarketplaceSubmission_reviewerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_reviewerId_fkey" FOREIGN KEY ("reviewerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceSubmission MarketplaceSubmission_versionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceSubmission"
    ADD CONSTRAINT "MarketplaceSubmission_versionId_fkey" FOREIGN KEY ("versionId") REFERENCES public."MarketplaceVersion"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MarketplaceVerification MarketplaceVerification_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVerification"
    ADD CONSTRAINT "MarketplaceVerification_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceVerification MarketplaceVerification_versionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVerification"
    ADD CONSTRAINT "MarketplaceVerification_versionId_fkey" FOREIGN KEY ("versionId") REFERENCES public."MarketplaceVersion"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MarketplaceVersion MarketplaceVersion_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."MarketplaceVersion"
    ADD CONSTRAINT "MarketplaceVersion_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."MarketplaceProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_snapshotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_snapshotId_fkey" FOREIGN KEY ("snapshotId") REFERENCES public."ServiceSnapshot"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResellerProfile ResellerProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ResellerProfile"
    ADD CONSTRAINT "ResellerProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermission RolePermission_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermission RolePermission_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServicePlan ServicePlan_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServicePlan"
    ADD CONSTRAINT "ServicePlan_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServicePolicy ServicePolicy_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServicePolicy"
    ADD CONSTRAINT "ServicePolicy_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServicePricing ServicePricing_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."ServicePricing"
    ADD CONSTRAINT "ServicePricing_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."ServicePlan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Ticket Ticket_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TrustedDevice TrustedDevice_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."TrustedDevice"
    ADD CONSTRAINT "TrustedDevice_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserRole UserRole_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."UserRole"
    ADD CONSTRAINT "UserRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserRole UserRole_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."UserRole"
    ADD CONSTRAINT "UserRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WebhookLog WebhookLog_webhookId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WebhookLog"
    ADD CONSTRAINT "WebhookLog_webhookId_fkey" FOREIGN KEY ("webhookId") REFERENCES public."Webhook"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WorkflowAlert WorkflowAlert_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowAlert"
    ADD CONSTRAINT "WorkflowAlert_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public."AutomationWorkflow"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkflowRun WorkflowRun_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowRun"
    ADD CONSTRAINT "WorkflowRun_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public."AutomationWorkflow"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkflowSchedule WorkflowSchedule_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowSchedule"
    ADD CONSTRAINT "WorkflowSchedule_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public."AutomationWorkflow"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkflowTaskRun WorkflowTaskRun_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowTaskRun"
    ADD CONSTRAINT "WorkflowTaskRun_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."WorkflowRun"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkflowTriggerRule WorkflowTriggerRule_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whms
--

ALTER TABLE ONLY public."WorkflowTriggerRule"
    ADD CONSTRAINT "WorkflowTriggerRule_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public."AutomationWorkflow"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: whms
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict mdkXEWykWsAcxeRV2sue4Ms7esUZcJ8PKu4sINsdOpyoEbnrGLE2kURyHzYAIna

