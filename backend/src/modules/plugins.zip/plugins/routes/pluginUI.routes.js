// src/modules/plugins/routes/pluginUI.routes.js
const express = require("express");
const path = require("path");
const fs = require("fs");

module.exports = function pluginUIRoutes({ logger }) {
  const router = express.Router();

  // GET /plugins/ui/:pluginId/frame
  router.get("/ui/:pluginId/frame", (req, res) => {
    const pluginId = req.params.pluginId;
    const pluginDir = path.join(process.cwd(), "plugins", pluginId, "ui");

    const indexHtml = path.join(pluginDir, "index.html");

    if (!fs.existsSync(indexHtml)) {
      return res.status(404).send(`<h2>UI not found for plugin: ${pluginId}</h2>`);
    }

    // Set strict CSP sandbox
    res.setHeader(
      "Content-Security-Policy",
      `sandbox allow-scripts allow-forms;`
    );

    res.sendFile(indexHtml);
  });

  // Serve static UI files
  router.use("/ui/:pluginId", (req, res, next) => {
    const pluginDir = path.join(process.cwd(), "plugins", req.params.pluginId, "ui");

    if (!fs.existsSync(pluginDir)) {
      return res.status(404).json({ error: "Plugin UI folder not found" });
    }

    express.static(pluginDir)(req, res, next);
  });

  return router;
};
